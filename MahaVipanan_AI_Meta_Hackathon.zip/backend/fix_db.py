import sqlite3
conn = sqlite3.connect('mahavipanan.db')
cur = conn.cursor()

# List all tables
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
print("Tables:", cur.fetchall())

# Check crop table
try:
    cur.execute("SELECT * FROM crop")
    print("Crops:", cur.fetchall())
except Exception as e:
    print("Crop error:", e)

# Fix any crops with unit='q'
try:
    cur.execute("UPDATE crop SET unit='quintal' WHERE unit='q'")
    conn.commit()
    print("Fixed crops with unit='q'")
except Exception as e:
    print("Fix error:", e)

# Check produce_lot columns
try:
    cur.execute("PRAGMA table_info(produce_lot)")
    cols = cur.fetchall()
    print("produce_lot columns:", [c[1] for c in cols])
except Exception as e:
    print("produce_lot error:", e)

conn.close()
