from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from ..database import get_db
from ..models.core import Order, Delivery, DeliveryHistory, User
from ..schemas.core import DeliveryResponse, DeliveryHistoryResponse, DeliveryStatusUpdate
from ..auth_utils import get_current_user

router = APIRouter(prefix="/api/delivery", tags=["delivery"])

@router.get("/track/{tracking_id}", response_model=dict)
def track_delivery(
    tracking_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    delivery = db.query(Delivery).filter(Delivery.tracking_id == tracking_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found.")

    user_id = current_user.get("sub")
    role = current_user.get("role")

    # Access Control: Only seller, receiver, or admin can access
    if role != "admin" and user_id != delivery.seller_id and user_id != delivery.receiver_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to view this delivery tracking."
        )

    # Fetch History
    history = db.query(DeliveryHistory).filter(
        DeliveryHistory.delivery_id == delivery.id
    ).order_by(desc(DeliveryHistory.timestamp)).all()

    # Fetch related Order and User names for context
    order = db.query(Order).filter(Order.id == delivery.order_id).first()
    seller = db.query(User).filter(User.id == delivery.seller_id).first()
    receiver = db.query(User).filter(User.id == delivery.receiver_id).first()

    delivery_data = DeliveryResponse.model_validate(delivery).model_dump()
    delivery_data["history"] = [DeliveryHistoryResponse.model_validate(h).model_dump() for h in history]

    return {
        "success": True,
        "data": {
            "delivery": delivery_data,
            "order_details": {
                "lot_id": order.lot_id,
                "agreed_price_per_q": order.agreed_price_per_q,
                "quantity_q": order.quantity_q,
                "created_at": order.created_at.isoformat()
            },
            "participants": {
                "seller_name": seller.name if seller else "Unknown",
                "receiver_name": receiver.name if receiver else "Unknown"
            }
        }
    }

@router.post("/{tracking_id}/status", response_model=dict)
def update_delivery_status(
    tracking_id: str,
    payload: DeliveryStatusUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    delivery = db.query(Delivery).filter(Delivery.tracking_id == tracking_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found.")

    user_id = current_user.get("sub")
    role = current_user.get("role")

    # Access Control: Allow receiver or admin to update status. 
    # Or seller can dispatch it.
    if role != "admin" and user_id != delivery.seller_id and user_id != delivery.receiver_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to update this delivery."
        )

    previous_status = delivery.status
    delivery.status = payload.status
    
    # Check if we should update Order status too
    order = db.query(Order).filter(Order.id == delivery.order_id).first()
    if payload.status == "DELIVERED":
        order.status = "delivered"
    elif payload.status in ["IN_TRANSIT", "OUT_FOR_DELIVERY"]:
        order.status = "in_transit"
    elif payload.status == "CANCELLED":
        order.status = "cancelled"
    
    db.commit()

    # Record History
    history = DeliveryHistory(
        delivery_id=delivery.id,
        previous_status=previous_status,
        new_status=payload.status,
        actor_id=user_id,
        note=payload.note
    )
    db.add(history)
    db.commit()

    return {"success": True, "message": f"Delivery status updated to {payload.status}."}
