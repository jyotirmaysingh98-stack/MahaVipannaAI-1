from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from ..database import get_db
from ..deps import get_current_user, get_current_user_optional, require_roles
from ..models.core import Order, OrderTracking, User, OrderStatus, generate_uuid
from ..schemas.core import OrderTrackingPointResponse, OrderTrackingCreate
from ..services.geocode import demo_route_for

orders_router = APIRouter(prefix="/api/orders", tags=["orders"])

ROLE_FIELD = {"farmer": "farmer_user_id", "buyer": "buyer_user_id", "fpo": "fpo_user_id"}

class UpdateInstructionsPayload(BaseModel):
    special_instructions: str

class UpdateOrderStatusPayload(BaseModel):
    status: str  # pickup, in_transit, delivered
    location_name: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    notes: Optional[str] = None

def _serialize_order(o: Order, farmer: Optional[User] = None, buyer: Optional[User] = None, points: Optional[list] = None) -> dict:
    data = {
        "id": o.id,
        "crop_name": o.crop_name or "Agricultural Produce",
        "status": o.status.value if hasattr(o.status, 'value') else str(o.status),
        "agreed_price_per_q": o.agreed_price_per_q,
        "quantity_q": o.quantity_q,
        "total_value": (o.agreed_price_per_q or 0) * (o.quantity_q or 0),
        "tracking_number": o.tracking_number or f"MH-TRK-2026-{abs(hash(o.id)) % 9000 + 1000}",
        "special_instructions": o.special_instructions,
        "pickup_location": o.pickup_location or "Nashik Agri Hub, Maharashtra",
        "delivery_location": o.delivery_location or "Vashi APMC Terminal, Navi Mumbai",
        "pickup_lat": o.pickup_lat or 20.0063,
        "pickup_lng": o.pickup_lng or 73.7902,
        "delivery_lat": o.delivery_lat or 19.0760,
        "delivery_lng": o.delivery_lng or 72.9984,
        "recipient_name": o.recipient_name or (buyer.name if buyer else "Buyer Lead"),
        "recipient_phone": o.recipient_phone or "+91 98200 44552",
        "verification_tier": o.verification_tier or "preliminary",
        "verification_status": o.verification_status or "verified",
        "farmer_name": farmer.name if farmer else "Demo Farmer",
        "buyer_name": buyer.name if buyer else "Demo Buyer",
        "created_at": o.created_at.isoformat() if o.created_at else None,
        "updated_at": o.updated_at.isoformat() if o.updated_at else None,
    }
    if points is not None:
        data["tracking_points"] = [
            {
                "id": p.id,
                "status": p.status.value if hasattr(p.status, 'value') else str(p.status),
                "location": p.location,
                "latitude": p.latitude,
                "longitude": p.longitude,
                "notes": p.notes,
                "timestamp": p.timestamp.isoformat() if p.timestamp else None,
            }
            for p in points
        ]
    return data

@orders_router.get("")
@orders_router.get("/")
def get_orders(db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    if not user or user.role.value in ("delivery", "admin"):
        orders = db.query(Order).filter(Order.status != OrderStatus.negotiation).order_by(Order.updated_at.desc()).all()
    else:
        field = ROLE_FIELD.get(user.role.value)
        if not field:
            orders = db.query(Order).order_by(Order.updated_at.desc()).all()
        else:
            orders = db.query(Order).filter(getattr(Order, field) == user.id).order_by(Order.updated_at.desc()).all()
            if not orders:
                orders = db.query(Order).filter(Order.status != OrderStatus.negotiation).order_by(Order.updated_at.desc()).all()

    uids = {uid for o in orders for uid in (o.farmer_user_id, o.buyer_user_id) if uid}
    user_map = {u.id: u for u in db.query(User).filter(User.id.in_(uids)).all()} if uids else {}
    results = [_serialize_order(o, user_map.get(o.farmer_user_id), user_map.get(o.buyer_user_id)) for o in orders]
    return {"success": True, "data": results}


@orders_router.get("/{order_id}")
def get_order_by_id(order_id: str, db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    farmer = db.query(User).filter(User.id == order.farmer_user_id).first() if order.farmer_user_id else None
    buyer = db.query(User).filter(User.id == order.buyer_user_id).first() if order.buyer_user_id else None
    points = db.query(OrderTracking).filter(OrderTracking.order_id == order_id).order_by(OrderTracking.timestamp.asc()).all()

    return {"success": True, "data": _serialize_order(order, farmer, buyer, points)}


@orders_router.put("/{order_id}/instructions")
def update_special_instructions(order_id: str, payload: UpdateInstructionsPayload, db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    order.special_instructions = payload.special_instructions
    db.commit()
    return {"success": True, "message": "Special delivery instructions saved", "special_instructions": order.special_instructions}


@orders_router.post("/{order_id}/status")
def update_order_status(order_id: str, payload: UpdateOrderStatusPayload, db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    status_map = {
        "pickup": OrderStatus.pickup,
        "in_transit": OrderStatus.in_transit,
        "delivered": OrderStatus.delivered
    }

    new_status = status_map.get(payload.status, OrderStatus.in_transit)
    order.status = new_status

    # Add a tracking point record
    lat = payload.latitude or (order.pickup_lat if new_status == OrderStatus.pickup else (order.delivery_lat if new_status == OrderStatus.delivered else 19.6967))
    lng = payload.longitude or (order.pickup_lng if new_status == OrderStatus.pickup else (order.delivery_lng if new_status == OrderStatus.delivered else 73.5604))
    loc = payload.location_name or ("Farm Gate / Hub" if new_status == OrderStatus.pickup else ("Delivery Destination" if new_status == OrderStatus.delivered else "En Route Corridor"))

    point = OrderTracking(
        id=generate_uuid(),
        order_id=order_id,
        status=new_status,
        location=loc,
        latitude=lat,
        longitude=lng,
        notes=payload.notes or f"Status updated to {new_status.value}",
        is_demo=False
    )
    db.add(point)
    db.commit()

    return {"success": True, "status": new_status.value, "location": loc, "latitude": lat, "longitude": lng}


@orders_router.get("/{order_id}/tracking")
def get_order_tracking(order_id: str, db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    points = db.query(OrderTracking).filter(OrderTracking.order_id == order_id).order_by(OrderTracking.timestamp.asc()).all()
    return {"success": True, "data": [OrderTrackingPointResponse.model_validate(p) for p in points]}
