from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..models.core import User, Feedback, Warehouse, OrderTracking, Order, UserTransaction
from ..deps import get_current_user, require_roles, require_admin_or_demo
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

admin_router = APIRouter(prefix="/api/admin", tags=["admin"])

# Mode in memory flag (demo vs real)
_SYSTEM_MODE = {"mode": "demo"}

class RespondFeedbackPayload(BaseModel):
    response: str

class UpdateVerificationPayload(BaseModel):
    verification_tier: str  # preliminary, professional, expert
    verification_status: str  # verified, in_review, pending, flagged
    verification_notes: Optional[str] = None
    verified_by: Optional[str] = None

class ModeTogglePayload(BaseModel):
    mode: str  # demo | real

@admin_router.get("/mode")
def get_system_mode():
    return {"success": True, "mode": _SYSTEM_MODE["mode"]}

@admin_router.post("/mode")
def set_system_mode(payload: ModeTogglePayload, admin: User = Depends(require_admin_or_demo)):
    if payload.mode not in ["demo", "real"]:
        raise HTTPException(status_code=400, detail="Mode must be 'demo' or 'real'")
    _SYSTEM_MODE["mode"] = payload.mode
    return {"success": True, "mode": _SYSTEM_MODE["mode"], "message": f"Switched to {payload.mode.upper()} mode database"}

@admin_router.get("/users")
def get_users(db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    users = db.query(User).all()
    tx_counts = dict(db.query(UserTransaction.user_id, func.count(UserTransaction.id)).group_by(UserTransaction.user_id).all())
    results = [
        {
            "id": u.id,
            "name": u.name,
            "email": u.email,
            "phone": u.phone,
            "role": u.role.value if hasattr(u.role, 'value') else str(u.role),
            "status": "Suspended" if u.name and u.name.startswith("[BANNED]") else "Active",
            "transaction_count": tx_counts.get(u.id, 0),
            "created_at": u.created_at.isoformat() if u.created_at else None
        }
        for u in users
    ]
    return {"success": True, "data": results}

@admin_router.get("/users/{user_id}/transactions")
def get_user_transactions(user_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    txns = db.query(UserTransaction).filter(UserTransaction.user_id == user_id).order_by(UserTransaction.created_at.desc()).all()
    results = [
        {
            "id": t.id,
            "reference_no": t.reference_no,
            "type": t.type,
            "title": t.title,
            "amount": t.amount,
            "direction": t.direction,
            "status": t.status,
            "counterparty_name": t.counterparty_name,
            "crop_name": t.crop_name,
            "quantity_q": t.quantity_q,
            "payment_method": t.payment_method,
            "created_at": t.created_at.isoformat() if t.created_at else None
        }
        for t in txns
    ]

    return {
        "success": True,
        "user": {
            "id": user.id,
            "name": user.name,
            "role": user.role.value if hasattr(user.role, 'value') else str(user.role),
            "email": user.email
        },
        "data": results
    }

@admin_router.post("/users/{user_id}/suspend")
def suspend_user(user_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user: raise HTTPException(status_code=404, detail="User not found")
    if not user.name.startswith("[BANNED]"):
        user.name = f"[BANNED] {user.name}"
        db.commit()
    return {"success": True}

@admin_router.post("/users/{user_id}/activate")
def activate_user(user_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user: raise HTTPException(status_code=404, detail="User not found")
    if user.name.startswith("[BANNED] "):
        user.name = user.name.replace("[BANNED] ", "")
        db.commit()
    return {"success": True}

def _serialize_feedback(f: Feedback, user: Optional[User] = None) -> dict:
    return {
        "id": f.id,
        "user_id": f.from_user_id,
        "user_name": f.user_name or (user.name if user else "Verified User"),
        "user_role": f.user_role or (user.role.value if user and hasattr(user.role, 'value') else "user"),
        "subject": f.subject or "Platform & Trading Feedback",
        "category": f.category or "feedback",
        "order_id": f.order_id,
        "rating": f.rating,
        "comments": f.comments,
        "admin_response": f.admin_response,
        "admin_responded_at": f.admin_responded_at.isoformat() if f.admin_responded_at else None,
        "status": f.status or "open",
        "created_at": f.created_at.isoformat() if f.created_at else None
    }

@admin_router.get("/verifications")
def get_order_verifications(tier: Optional[str] = None, db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    query = db.query(Order)
    if tier and tier != "all":
        query = query.filter(Order.verification_tier == tier)
    orders = query.order_by(Order.created_at.desc()).all()

    uids = {uid for o in orders for uid in (o.farmer_user_id, o.buyer_user_id) if uid}
    user_map = {u.id: u for u in db.query(User).filter(User.id.in_(uids)).all()} if uids else {}

    results = [
        {
            "order_id": o.id,
            "crop_name": o.crop_name or "Agricultural Produce",
            "quantity_q": o.quantity_q,
            "agreed_price_per_q": o.agreed_price_per_q,
            "total_value": (o.agreed_price_per_q or 0) * (o.quantity_q or 0),
            "verification_tier": o.verification_tier or "preliminary",
            "verification_status": o.verification_status or "verified",
            "verification_notes": o.verification_notes or "Quality check completed according to FPO grade standard.",
            "verified_by": o.verified_by or "District Agri Inspection Cell",
            "tracking_number": o.tracking_number,
            "farmer_name": user_map[o.farmer_user_id].name if o.farmer_user_id in user_map else "Demo Farmer",
            "buyer_name": user_map[o.buyer_user_id].name if o.buyer_user_id in user_map else "Demo Buyer",
            "pickup_location": o.pickup_location or "Nashik Hub",
            "delivery_location": o.delivery_location or "Vashi Terminal",
            "created_at": o.created_at.isoformat() if o.created_at else None
        }
        for o in orders
    ]
    return {"success": True, "data": results}

@admin_router.post("/verifications/{order_id}")
def update_order_verification(order_id: str, payload: UpdateVerificationPayload, db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    order.verification_tier = payload.verification_tier
    order.verification_status = payload.verification_status
    if payload.verification_notes:
        order.verification_notes = payload.verification_notes
    tier_names = {
        "preliminary": "Preliminary Quality Assessment Team",
        "professional": "Professional Agricultural Verification Wing",
        "expert": "MahaAgri Expert A+ Quality Council"
    }
    order.verified_by = payload.verified_by or tier_names.get(payload.verification_tier, "Agri Inspection Wing")
    db.commit()
    return {"success": True, "message": f"Verification updated to {payload.verification_tier} tier"}

@admin_router.get("/feedbacks")
def get_admin_feedbacks(db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    feedbacks = db.query(Feedback).order_by(Feedback.created_at.desc()).all()
    uids = {f.from_user_id for f in feedbacks if f.from_user_id}
    user_map = {u.id: u for u in db.query(User).filter(User.id.in_(uids)).all()} if uids else {}
    results = [_serialize_feedback(f, user_map.get(f.from_user_id)) for f in feedbacks]
    return {"success": True, "data": results}

@admin_router.post("/feedbacks/{feedback_id}/respond")
def respond_to_feedback(feedback_id: str, payload: RespondFeedbackPayload, db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if not feedback:
        raise HTTPException(status_code=404, detail="Feedback entry not found")

    feedback.admin_response = payload.response
    feedback.admin_responded_at = datetime.utcnow()
    feedback.status = "resolved"
    db.commit()
    return {"success": True, "message": "Response submitted to user"}

@admin_router.get("/complaints")
def get_complaints(db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    feedbacks = db.query(Feedback).filter(Feedback.rating <= 2).all()
    uids = {f.from_user_id for f in feedbacks if f.from_user_id}
    user_map = {u.id: u for u in db.query(User).filter(User.id.in_(uids)).all()} if uids else {}
    results = [_serialize_feedback(f, user_map.get(f.from_user_id)) for f in feedbacks]
    return {"success": True, "data": results}

@admin_router.get("/warehouses")
def get_warehouses(db: Session = Depends(get_db), admin: User = Depends(require_admin_or_demo)):
    warehouses = db.query(Warehouse).all()
    results = [
        {"id": w.id, "name": w.name, "location": w.location, "capacity": w.capacity_q, "storage_type": w.storage_type, "condition": "Optimal"}
        for w in warehouses
    ]
    return {"success": True, "data": results}
