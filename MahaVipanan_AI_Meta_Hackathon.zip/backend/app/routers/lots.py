from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from typing import List
from ..database import get_db
from ..deps import get_current_user
from ..models.core import ProduceLot, LotMember, FPO, Crop, QualityGrade, LotStatus, User, UserRole
from ..schemas.core import ProduceLotCreate, ProduceLotResponse, ProduceLotUpdate

router = APIRouter(prefix="/api/lots", tags=["Lots"])

def lot_to_response(lot: ProduceLot, db: Session) -> ProduceLotResponse:
    """Convert a ProduceLot ORM object to ProduceLotResponse, resolving crop_name."""
    crop = db.query(Crop).filter(Crop.id == lot.crop_id).first()
    resp = ProduceLotResponse.model_validate(lot)
    resp.crop_name = crop.name if crop else "Unknown"
    resp.original_farmer_name = lot.original_farmer.name if lot.original_farmer else None
    return resp

@router.post("/", response_model=dict)
def create_lot(lot_data: ProduceLotCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    fpo_id = current_user.fpo_id
    if not fpo_id:
        # Fallback for demo if farmer has no fpo assigned
        fpo = db.query(FPO).first()
        fpo_id = fpo.id if fpo else None
        
    crop = db.query(Crop).filter(Crop.name == lot_data.crop_name).first()
    if not crop:
        # Dynamically add the crop to support demo/hackathon usage without manual seeding
        crop = Crop(name=lot_data.crop_name, unit="quintal")
        db.add(crop)
        db.commit()
        db.refresh(crop)

    total_kg = sum(m.quantity_kg for m in lot_data.members)
    
    # Very simple grade summary logic
    grades = [m.grade for m in lot_data.members if m.grade]
    dominant_grade = max(set(grades), key=grades.count) if grades else "FAQ"
    
    new_lot = ProduceLot(
        fpo_id=fpo_id,
        crop_id=crop.id,
        total_quantity_kg=total_kg,
        total_quantity_q=total_kg / 100.0,
        harvest_date=lot_data.harvest_date,
        grade_summary=dominant_grade,
        status=LotStatus.draft,
        original_farmer_id=current_user.id,
        current_owner_id=current_user.id,
        expected_price_per_q=lot_data.expected_price_per_q,
        baseline_transport_cost_per_q=lot_data.baseline_transport_cost_per_q,
        miscellaneous_cost_per_q=lot_data.miscellaneous_cost_per_q
    )
    db.add(new_lot)
    db.commit()
    db.refresh(new_lot)
    
    for m in lot_data.members:
        # Assuming grade exists in DB for this demo
        q_grade = db.query(QualityGrade).filter(
            QualityGrade.crop_id == crop.id, 
            QualityGrade.grade_label == m.grade
        ).first()
        
        lm = LotMember(
            lot_id=new_lot.id,
            member_name=m.member_name,
            quantity_kg=m.quantity_kg,
            grade=m.grade,
            grade_id=q_grade.id if q_grade else None
        )
        db.add(lm)
    
    db.commit()
    db.refresh(new_lot)
    
    return {
        "success": True,
        "data": lot_to_response(new_lot, db),
        "data_label": "DEMO_DATA"
    }

@router.get("/", response_model=dict)
def get_lots(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    fpo_id = current_user.fpo_id or current_user.id
    lots = db.query(ProduceLot).options(joinedload(ProduceLot.original_farmer)).filter(ProduceLot.fpo_id == fpo_id).all()
    
    return {
        "success": True,
        "data": [lot_to_response(l, db) for l in lots],
        "data_label": "DEMO_DATA"
    }

@router.get("/fpo/inventory", response_model=dict)
def get_fpo_inventory(db: Session = Depends(get_db), current_fpo: User = Depends(get_current_user)):
    if current_fpo.role != UserRole.fpo:
        raise HTTPException(status_code=403, detail="Only FPOs can view FPO inventory")
        
    lots = db.query(ProduceLot).filter(
        ProduceLot.current_owner_id == current_fpo.id,
        ProduceLot.status != LotStatus.sold
    ).options(joinedload(ProduceLot.original_farmer)).all()
    
    return {
        "success": True,
        "data": [lot_to_response(l, db) for l in lots],
        "data_label": "DEMO_DATA"
    }

@router.get("/fpo/offers", response_model=dict)
def get_fpo_offers(db: Session = Depends(get_db), current_fpo: User = Depends(get_current_user)):
    from ..models.core import Order, OrderStatus
    
    if current_fpo.role != UserRole.fpo:
        raise HTTPException(status_code=403, detail="Only FPOs can view FPO offers")
        
    # Get lots where an active offer exists directed to this FPO, and FPO does not already own it
    orders = db.query(Order).filter(
        Order.fpo_user_id == current_fpo.id,
        Order.status == OrderStatus.negotiation  # or offer
    ).all()
    
    lot_ids = [o.lot_id for o in orders if o.lot_id]
    
    lots = db.query(ProduceLot).options(joinedload(ProduceLot.original_farmer)).filter(
        ProduceLot.id.in_(lot_ids),
        ProduceLot.current_owner_id != current_fpo.id
    ).all()
    
    return {
        "success": True,
        "data": [lot_to_response(l, db) for l in lots],
        "data_label": "DEMO_DATA"
    }

@router.get("/{lot_id}", response_model=dict)
def get_lot(lot_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    return {
        "success": True,
        "data": lot_to_response(lot, db),
        "data_label": "DEMO_DATA"
    }

@router.put("/{lot_id}", response_model=dict)
def update_lot(lot_id: str, updates: ProduceLotUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    if lot.current_owner_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to edit this lot")
        
    if lot.status == LotStatus.sold:
        raise HTTPException(status_code=403, detail="Cannot edit a sold lot")
        
    for field, val in updates.model_dump(exclude_unset=True).items():
        if val is not None:
            setattr(lot, field, val)

    db.commit()
    db.refresh(lot)
    return {
        "success": True,
        "data": lot_to_response(lot, db),
        "data_label": "DEMO_DATA"
    }

@router.delete("/{lot_id}", response_model=dict)
def delete_lot(lot_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    # Check ownership
    if lot.current_owner_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this lot")
        
    db.delete(lot)
    db.commit()
    return {"success": True, "message": "Lot deleted successfully"}
