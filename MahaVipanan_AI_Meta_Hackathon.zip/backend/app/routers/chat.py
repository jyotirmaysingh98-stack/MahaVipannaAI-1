from typing import Optional, List, Dict, Any
import re
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_

from ..database import get_db
from ..deps import get_current_user_optional, get_current_user
from ..models.core import (
    GovernmentScheme, User, ChatMessage, UserRole, ProduceLot, LotStatus,
    Crop, Negotiation, NegotiationStatus, Order, FPO, generate_uuid
)
from ..services import ai_provider

chat_router = APIRouter(prefix="/api/chat", tags=["chat"])

class ChatMessageItem(BaseModel):
    role: str  # user | assistant | bot
    text: str

class ChatRequest(BaseModel):
    message: str
    lang: Optional[str] = "en"
    history: Optional[List[ChatMessageItem]] = None
    context: Optional[dict] = None

class DirectMessageRequest(BaseModel):
    recipient_id: str
    message: str
    message_type: Optional[str] = "text"  # "text" | "call_invite" | "discord_invite"
    order_id: Optional[str] = None

# Multilingual greetings and assistants
GREETING_RESPONSES = {
    "en": "Namaste! I am your MahaVipanan AI Assistant & Personal Agri-CA. I can create produce lots, adjust negotiation prices, calculate your net realization and mandi tax savings, or advise on government subsidies.",
    "hi": "नमस्ते! मैं आपका महाविपणन AI सहायक और व्यक्तिगत कृषि-सीए (CA) हूं। मैं आपकी उपज का नया लॉट बना सकता हूं, बातचीत में भाव बदल सकता हूं, मंडी टैक्स की बचत और शुद्ध मुनाफे की गणना कर सकता हूं।",
    "mr": "नमस्कार! मी आपला महाविपणन AI सहाय्यक आणि वैयक्तिक कृषी-सीए (CA) आहे. मी नवीन मालाचा लॉट तयार करू शकतो, वाटाघाटीतील किंमत बदलू शकतो, मंडी कर बचत आणि निव्वळ नफ्याची मोजणी करू शकतो.",
    "te": "నమస్కారం! నేను మీ మహావిపణన్ AI సహాయకుడిని మరియు అగ్రి-CA. నేను కొత్త పంట లాట్‌లను సృష్టించగలను, చర్చల ధరలను మార్చగలను, మీ నికర రాబడి మరియు మార్కెట్ పన్ను పొదుపులను లెక్కించగలను."
}

def detect_lot_creation(text: str) -> Optional[Dict[str, Any]]:
    """Detect if user is asking the agent to create a lot/plot on their behalf."""
    t = text.lower()
    create_verbs = ["create", "add", "make", "list", "publish", "बनाओ", "जोड़ो", "तयार करा", "सृష్టించు"]
    noun_keywords = ["lot", "plot", "batch", "crop", "produce", "लॉट", "प्लॉट", "माल", "లాట్"]

    has_create = any(v in t for v in create_verbs)
    has_lot = any(n in t for n in noun_keywords)

    if not (has_create and has_lot):
        return None

    # Extract crop
    crop_keywords = [
        ("Wheat", ("wheat", "गेहूं", "गहू")),
        ("Tomato", ("tomato", "टमाटर", "टोमॅटो")),
        ("Soybean", ("soybean", "सोयाबीन")),
        ("Cotton", ("cotton", "कपास")),
    ]
    crop_name = next((name for name, kws in crop_keywords if any(k in t for k in kws)), "Onion")

    # Extract quantity (e.g. 50 quintals or 50q or 5000kg or 50)
    qty_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:quintals?|quintal|q|क्विंटल|కువింటాళ్లు|kg)?', t)
    qty = float(qty_match.group(1)) if (qty_match and float(qty_match.group(1)) > 0) else 50.0

    # Extract price if mentioned
    price_match = re.search(r'(?:rs|inr|₹|price|rate|at|भाव|दर|ధర)\s*[:=]?\s*(\d{3,5})', t)
    price = float(price_match.group(1)) if price_match else 1850.0

    # Extract grade
    grade = "Grade B" if any(b in t for b in ("grade b", "बी ग्रेड", "b grade")) else "Grade A"

    return {
        "crop_name": crop_name,
        "quantity_q": qty,
        "expected_price_per_q": price,
        "grade_summary": f"{grade} (Clean & Graded)",
    }

def detect_negotiation_update(text: str) -> Optional[Dict[str, Any]]:
    """Detect if user is asking the agent to update or counter an offer price."""
    t = text.lower()
    action_words = ["counter", "negotiate", "offer", "change price", "set price", "update price", "भाव बदलो", "ऑफर", "दर बदला", "ధర మార్చు"]
    if not any(w in t for w in action_words):
        return None

    price_match = re.search(r'(\d{3,5})', t)
    if price_match:
        try:
            new_price = float(price_match.group(1))
            if 500 <= new_price <= 10000:
                return {"new_price": new_price}
        except ValueError:
            pass
    return None

def detect_ca_calculation(text: str) -> Optional[Dict[str, Any]]:
    """Detect Chartered Accountant / Financial Assistant calculation requests."""
    t = text.lower()
    ca_keywords = ["calculate", "tax", "mandi fee", "nrp", "net price", "profit", "commission", "savings", "ca", "subsidy", "हिसाब", "मुनाफा", "बचत", "मंडी टैक्स", "हिशोब", "नफा", "పన్ను", "లాభం"]
    if not any(w in t for w in ca_keywords):
        return None

    p_match = re.search(r'(\d{3,5})', t)
    price = float(p_match.group(1)) if p_match else 1850.0

    q_match = re.search(r'(\d+)\s*(?:q|quintals?)', t)
    qty = float(q_match.group(1)) if q_match else 50.0

    gross_val = price * qty
    apmc_comm = gross_val * 0.06  # 6% APMC fee
    transport = 50.0 * qty
    loading = 20.0 * qty
    direct_net = gross_val - transport - loading
    apmc_net = gross_val - apmc_comm - transport - loading
    direct_savings = apmc_comm
    subsidy_30pct = 2775.0  # 30% platform fee subsidy

    return {
        "price_per_q": price,
        "quantity_q": qty,
        "gross_value": gross_val,
        "apmc_commission_saved": direct_savings,
        "transport_cost": transport,
        "loading_cost": loading,
        "direct_marketing_net_realization": direct_net,
        "apmc_mandi_net_realization": apmc_net,
        "platform_subsidy_benefit": subsidy_30pct,
    }


@chat_router.post("/message")
async def send_message(payload: ChatRequest, db: Session = Depends(get_db), user: Optional[User] = Depends(get_current_user_optional)):
    lang = payload.lang or "en"
    role = user.role.value if user and hasattr(user.role, 'value') else "farmer"
    msg_text = payload.message.strip()

    # 1. Agentic Action: Create Lot
    lot_data = detect_lot_creation(msg_text)
    if lot_data:
        # Resolve crop
        crop = db.query(Crop).filter(Crop.name == lot_data["crop_name"]).first()
        if not crop:
            crop = Crop(name=lot_data["crop_name"], perishability_window_days=30)
            db.add(crop)
            db.flush()

        # Resolve FPO ID
        fpo_id = user.fpo_id if user else None
        if not fpo_id:
            first_fpo = db.query(FPO).first()
            fpo_id = first_fpo.id if first_fpo else None

        demo_user_id = user.id if user else "demo-farmer-1"
        new_lot = ProduceLot(
            id=generate_uuid(),
            fpo_id=fpo_id,
            crop_id=crop.id,
            total_quantity_q=lot_data["quantity_q"],
            total_quantity_kg=lot_data["quantity_q"] * 100.0,
            grade_summary=lot_data["grade_summary"],
            status=LotStatus.ready,
            harvest_date=date.today(),
            original_farmer_id=demo_user_id,
            current_owner_id=demo_user_id,
            expected_price_per_q=lot_data["expected_price_per_q"],
            baseline_transport_cost_per_q=50.0,
            loading_cost_per_q=20.0,
            miscellaneous_cost_per_q=10.0
        )
        db.add(new_lot)
        db.commit()
        db.refresh(new_lot)

        replies = {
            "en": f"✅ Done! I have created a new lot on your behalf:\n• Crop: {lot_data['crop_name']}\n• Quantity: {lot_data['quantity_q']} Quintals\n• Grade: {lot_data['grade_summary']}\n• Expected Price: ₹{lot_data['expected_price_per_q']:,.0f}/q\n• Lot ID: {new_lot.id[:8]}...\nThis lot is now live in your Produce Lots and available for buyer opportunities.",
            "hi": f"✅ हो गया! मैंने आपके लिए नया लॉट बना दिया है:\n• फसल: {lot_data['crop_name']}\n• मात्रा: {lot_data['quantity_q']} क्विंटल\n• ग्रेड: {lot_data['grade_summary']}\n• अपेक्षित भाव: ₹{lot_data['expected_price_per_q']:,.0f}/क्विंटल\nयह लॉट अब आपकी लॉट सूची में सक्रिय है।",
            "mr": f"✅ पूर्ण झाले! मी आपल्यासाठी नवीन लॉट तयार केला आहे:\n• पीक: {lot_data['crop_name']}\n• प्रमाण: {lot_data['quantity_q']} क्विंटल\n• प्रत: {lot_data['grade_summary']}\n• अपेक्षित दर: ₹{lot_data['expected_price_per_q']:,.0f}/क्विंटल\nहा लॉट आता आपल्या यादीत थेट सक्रिय झाला आहे.",
            "te": f"✅ పూర్తయింది! నేను మీ తరపున కొత్త లాట్‌ను సృష్టించాను:\n• పంట: {lot_data['crop_name']}\n• పరిమాణం: {lot_data['quantity_q']} క్వింటాళ్లు\n• గ్రేడ్: {lot_data['grade_summary']}\n• ఆశించిన ధర: ₹{lot_data['expected_price_per_q']:,.0f}/క్వింటాల్."
        }

        return {
            "success": True,
            "data": {
                "reply": replies.get(lang, replies["en"]),
                "source": "agent_action",
                "action": {
                    "type": "lot_created",
                    "lot_id": new_lot.id,
                    "crop_name": lot_data["crop_name"],
                    "quantity_q": lot_data["quantity_q"],
                    "expected_price_per_q": lot_data["expected_price_per_q"]
                }
            }
        }

    # 2. Agentic Action: Negotiation Price Update
    neg_data = detect_negotiation_update(msg_text)
    if neg_data:
        pending_neg = db.query(Negotiation).filter(Negotiation.status == NegotiationStatus.pending).first()
        if pending_neg:
            new_round = Negotiation(
                id=generate_uuid(),
                order_id=pending_neg.order_id,
                offered_price_per_q=neg_data["new_price"],
                status=NegotiationStatus.pending,
                created_by_user_id=user.id if user else pending_neg.created_by_user_id,
                created_by_role=user.role.value if user else "buyer",
                message=f"AI Assistant updated counter-offer to ₹{neg_data['new_price']:,.0f}/q"
            )
            db.add(new_round)
            db.commit()

            replies = {
                "en": f"🤝 Negotiation Updated! I have updated your counter-offer to ₹{neg_data['new_price']:,.0f}/quintal in the active trade session. The buyer has been notified.",
                "hi": f"🤝 बातचीत अपडेट हो गई! मैंने सक्रिय ट्रेड में आपका काउंटर ऑफर ₹{neg_data['new_price']:,.0f}/क्विंटल सेट कर दिया है। खरीदार को सूचना भेज दी गई है।",
                "mr": f"🤝 वाटाघाटी अपडेट झाली! मी सक्रिय ट्रेडमध्ये आपली किंमत ₹{neg_data['new_price']:,.0f}/क्विंटल नोंदवली आहे.",
                "te": f"🤝 చర్చల ధర అప్‌డేట్ చేయబడింది! నేను మీ ఆఫర్ ధరను ₹{neg_data['new_price']:,.0f}/క్వింటాల్‌గా నవీకరించాను."
            }

            return {
                "success": True,
                "data": {
                    "reply": replies.get(lang, replies["en"]),
                    "source": "agent_action",
                    "action": {
                        "type": "negotiation_updated",
                        "new_price": neg_data["new_price"]
                    }
                }
            }

    # 3. Agentic Action: Personal CA / Financial Calculation
    ca_calc = detect_ca_calculation(msg_text)
    if ca_calc:
        replies = {
            "en": (
                f"📊 **Personal Agri-CA Financial Breakdown**:\n"
                f"• Gross Produce Value ({ca_calc['quantity_q']}q @ ₹{ca_calc['price_per_q']:,.0f}/q): **₹{ca_calc['gross_value']:,.0f}**\n"
                f"• Direct Marketing Exemption: **₹{ca_calc['apmc_commission_saved']:,.0f} saved** (Zero 6% APMC Mandi Tax)\n"
                f"• Estimated Transport & Loading: ₹{ca_calc['transport_cost'] + ca_calc['loading_cost']:,.0f}\n"
                f"• **Net Realized Revenue (Direct)**: **₹{ca_calc['direct_marketing_net_realization']:,.0f}**\n"
                f"• *Traditional Mandi Net would be only*: ₹{ca_calc['apmc_mandi_net_realization']:,.0f}\n"
                f"💡 **Extra Profit with MahaVipanan Direct Marketing**: **+₹{ca_calc['apmc_commission_saved']:,.0f}**!"
            ),
            "hi": (
                f"📊 **व्यक्तिगत कृषि-सीए (CA) वित्तीय विवरण**:\n"
                f"• कुल फसल मूल्य ({ca_calc['quantity_q']} क्विंटल @ ₹{ca_calc['price_per_q']:,.0f}): **₹{ca_calc['gross_value']:,.0f}**\n"
                f"• डायरेक्ट मार्केटिंग बचत: **₹{ca_calc['apmc_commission_saved']:,.0f} की बचत** (6% मंडी आढ़त शुल्क शून्य)\n"
                f"• परिवहन व लोडिंग खर्च: ₹{ca_calc['transport_cost'] + ca_calc['loading_cost']:,.0f}\n"
                f"• **शुद्ध प्राप्त राशि (Direct Sale)**: **₹{ca_calc['direct_marketing_net_realization']:,.0f}**\n"
                f"💡 **महाविपणन के माध्यम से अतिरिक्त मुनाफा**: **+₹{ca_calc['apmc_commission_saved']:,.0f}**!"
            ),
            "mr": (
                f"📊 **वैयक्तिक कृषी-सीए (CA) हिशोब**:\n"
                f"• एकूण माल मूल्य ({ca_calc['quantity_q']} क्विंटल @ ₹{ca_calc['price_per_q']:,.0f}): **₹{ca_calc['gross_value']:,.0f}**\n"
                f"• थेट विपणन कर बचत: **₹{ca_calc['apmc_commission_saved']:,.0f} बचत** (६% एपीएमसी मंडी शुल्क नाही)\n"
                f"• **थेट विक्रीतून मिळणारा निव्वळ नफा**: **₹{ca_calc['direct_marketing_net_realization']:,.0f}**\n"
                f"💡 **महाविपणन थेट विक्रीतून अतिरिक्त फायदा**: **+₹{ca_calc['apmc_commission_saved']:,.0f}**!"
            ),
            "te": (
                f"📊 **వ్యక్తిగత అగ్రి-CA ఆర్థిక విశ్లేషణ**:\n"
                f"• మొత్తం పంట విలువ ({ca_calc['quantity_q']} క్వింటాళ్లు @ ₹{ca_calc['price_per_q']:,.0f}): **₹{ca_calc['gross_value']:,.0f}**\n"
                f"• డైరెక్ట్ మార్కెటింగ్ పన్ను పొదుపు: **₹{ca_calc['apmc_commission_saved']:,.0f} ఆదా**\n"
                f"• **నికర రాబడి**: **₹{ca_calc['direct_marketing_net_realization']:,.0f}**"
            )
        }

        return {
            "success": True,
            "data": {
                "reply": replies.get(lang, replies["en"]),
                "source": "ca_advisor",
                "action": {
                    "type": "ca_calculation",
                    "details": ca_calc
                }
            }
        }

    # 4. Multi-turn AI Response via AI Provider or deterministic scheme search
    lowered = msg_text.lower()
    scheme_hint = ""
    if any(w in lowered for w in ["scheme", "subsidy", "yojana", "सब्सिडी", "योजना", "పథకం", "pmfby", "soil", "enam"]):
        top = db.query(GovernmentScheme).filter(GovernmentScheme.status == "published").order_by(GovernmentScheme.created_at.desc()).limit(4).all()
        if top:
            scheme_hint = " Available Government Schemes: " + "; ".join(f"{s.title} - Benefits: {s.benefits} (Official Portal: {s.official_url})" for s in top)

    # Build conversation context from history
    history_context = ""
    if payload.history:
        recent = payload.history[-6:]
        history_context = " Previous conversation:\n" + "\n".join(f"{h.role}: {h.text}" for h in recent)

    prompt = f"User role: {role}. Current request: {msg_text}.{scheme_hint}{history_context}"
    if payload.context:
        prompt += f" App Context: {payload.context}"

    system = (
        "You are MahaVipanan AI, an intelligent Personal Accountant, Platform Guide, and Comprehensive Agricultural & General Knowledge Advisor powered by state-of-the-art AI. "
        "You assist users with general queries, website navigation, financial and tax calculations, crop valuation, Net Realized Price optimization, APMC mandi tax exemptions, warehouse logistics, and verified government subsidies. "
        "You can answer any general query politely and accurately while also providing specialized guidance on the MahaVipanan platform. "
        "Always be helpful, warm, actionable, mathematically sound, and clear. "
        + ai_provider.lang_instruction(lang)
    )

    result = await ai_provider.get_ai_text(prompt, system=system, fallback=GREETING_RESPONSES.get(lang, GREETING_RESPONSES["en"]))
    return {"success": True, "data": {"reply": result["text"], "source": result["source"]}}
