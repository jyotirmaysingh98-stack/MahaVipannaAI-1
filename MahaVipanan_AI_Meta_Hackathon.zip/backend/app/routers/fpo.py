from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models.core import FPO, ProduceLot, LotStatus, User, UserRole, Order, OrderStatus
from ..schemas.core import FPOResponse
from ..deps import get_current_user

router = APIRouter(prefix="/api/fpo", tags=["FPO"])

@router.get("/dashboard", response_model=dict)
def get_dashboard(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.fpo:
        raise HTTPException(status_code=403, detail="Only FPO users can access this dashboard")
        
    fpo = db.query(FPO).filter(FPO.id == current_user.fpo_id).first()
    if not fpo:
        raise HTTPException(status_code=404, detail="FPO profile not found.")
        
    # Active lots are lots OWNED by the FPO (not just associated by farmer)
    active_lots_count = db.query(ProduceLot).filter(
        ProduceLot.current_owner_id == current_user.id, 
        ProduceLot.status != LotStatus.sold
    ).count()
    
    total_inventory = db.query(ProduceLot.total_quantity_q).filter(
        ProduceLot.current_owner_id == current_user.id, 
        ProduceLot.status != LotStatus.sold
    ).all()
    
    total_q = sum([t[0] for t in total_inventory])
    
    # Pending offers are active negotiations where FPO is the buyer
    pending_offers_count = db.query(Order).filter(
        Order.fpo_user_id == current_user.id,
        Order.status == OrderStatus.negotiation
    ).count()
    
    return {
        "success": True,
        "data": {
            "fpo": FPOResponse.model_validate(fpo),
            "active_lots": active_lots_count,
            "total_inventory_q": total_q,
            "pending_offers": pending_offers_count
        },
        "data_label": "DEMO_DATA"
    }
