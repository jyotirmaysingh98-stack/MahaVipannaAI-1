from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from ..database import get_db
from ..models.core import FPO, ProduceLot, LotStatus, LotMember, User, UserRole, Order, Crop, OrderStatus

router = APIRouter(prefix="/api/farmer", tags=["Farmer"])

from ..deps import get_current_user

class LotCreateRequest(BaseModel):
    crop_name: str
    total_quantity_q: float
    grade_summary: Optional[str] = None
    expected_price_per_q: Optional[float] = None
    baseline_transport_cost_per_q: Optional[float] = None

class LotUpdateRequest(BaseModel):
    expected_price_per_q: Optional[float] = None
    baseline_transport_cost_per_q: Optional[float] = None


@router.get("/lots", response_model=dict)
def get_farmer_lots(db: Session = Depends(get_db), farmer: User = Depends(get_current_user)):
    lots = db.query(ProduceLot).filter(ProduceLot.original_farmer_id == farmer.id).all()
    crop_ids = {lot.crop_id for lot in lots if lot.crop_id}
    crop_map = {c.id: c.name for c in db.query(Crop).filter(Crop.id.in_(crop_ids)).all()} if crop_ids else {}

    results = [
        {
            "id": lot.id,
            "crop": crop_map.get(lot.crop_id, "Unknown"),
            "quantity_q": lot.total_quantity_q,
            "status": lot.status,
            "harvest_date": lot.harvest_date,
            "created_at": lot.created_at,
            "is_owner": (lot.current_owner_id == farmer.id),
            "is_active": (lot.current_owner_id == farmer.id and lot.status != LotStatus.sold),
            "current_owner_id": lot.current_owner_id,
            "expected_price_per_q": lot.expected_price_per_q,
            "baseline_transport_cost_per_q": lot.baseline_transport_cost_per_q
        }
        for lot in lots
    ]
    return {"success": True, "data": results, "data_label": "DEMO_DATA"}

@router.post("/lots", response_model=dict)
def create_farmer_lot(payload: LotCreateRequest, db: Session = Depends(get_db), farmer: User = Depends(get_current_user)):
    crop = db.query(Crop).filter(func.lower(Crop.name) == payload.crop_name.lower()).first()
    if not crop:
        crop = Crop(name=payload.crop_name, unit="quintal", perishability_window_days=7)
        db.add(crop)
        db.commit()
        db.refresh(crop)

    lot = ProduceLot(
        crop_id=crop.id,
        total_quantity_q=payload.total_quantity_q,
        total_quantity_kg=payload.total_quantity_q * 100,
        grade_summary=payload.grade_summary,
        original_farmer_id=farmer.id,
        current_owner_id=farmer.id,
        status=LotStatus.ready,
        expected_price_per_q=payload.expected_price_per_q,
        baseline_transport_cost_per_q=payload.baseline_transport_cost_per_q,
        fpo_id=farmer.fpo_id
    )
    db.add(lot)
    db.commit()
    return {"success": True, "id": lot.id}

@router.put("/lots/{lot_id}", response_model=dict)
def update_farmer_lot(lot_id: str, payload: LotUpdateRequest, db: Session = Depends(get_db), farmer: User = Depends(get_current_user)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id, ProduceLot.original_farmer_id == farmer.id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")

    if lot.current_owner_id != farmer.id or lot.status == LotStatus.sold:
        raise HTTPException(status_code=403, detail="Cannot edit a lot that has been sold or transferred")

    for field, val in payload.model_dump(exclude_unset=True).items():
        if val is not None:
            setattr(lot, field, val)

    db.commit()
    return {"success": True}

@router.delete("/lots/{lot_id}", response_model=dict)
def delete_farmer_lot(lot_id: str, db: Session = Depends(get_db), farmer: User = Depends(get_current_user)):
    lot = db.query(ProduceLot).filter(ProduceLot.id == lot_id, ProduceLot.original_farmer_id == farmer.id).first()
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
        
    if lot.current_owner_id != farmer.id or lot.status == LotStatus.sold:
        raise HTTPException(status_code=403, detail="Cannot delete a lot that has been sold or transferred")
        
    db.delete(lot)
    db.commit()
    return {"success": True}


@router.get("/analytics", response_model=dict)
def get_farmer_analytics(db: Session = Depends(get_db), farmer: User = Depends(get_current_user)):
    
    # Only lots CREATED by this farmer
    active_lots = db.query(ProduceLot).filter(
        ProduceLot.original_farmer_id == farmer.id,
        ProduceLot.status != LotStatus.sold,
        ProduceLot.current_owner_id == farmer.id
    ).count()
    
    sold_lots = db.query(ProduceLot).filter(
        ProduceLot.original_farmer_id == farmer.id,
        (ProduceLot.current_owner_id != farmer.id) | (ProduceLot.status == LotStatus.sold)
    ).count()
    
    # Revenue is from orders where farmer is the seller
    orders = db.query(Order).filter(
        Order.farmer_user_id == farmer.id,
        Order.status.in_([OrderStatus.accepted, OrderStatus.delivered, OrderStatus.payment])
    ).all()
    
    revenue = sum((o.agreed_price_per_q * o.quantity_q) for o in orders if o.agreed_price_per_q and o.quantity_q)
    
    return {
        "success": True,
        "data": {
            "active_lots": active_lots,
            "sold_lots": sold_lots,
            "total_revenue": revenue,
            "chart_data": [
                {"month": "Jan", "revenue": revenue * 0.1 if revenue else 0},
                {"month": "Feb", "revenue": revenue * 0.4 if revenue else 0},
                {"month": "Mar", "revenue": revenue * 0.5 if revenue else 0},
            ]
        },
        "data_label": "DEMO_DATA"
    }

@router.get("/history", response_model=dict)
def get_farmer_history(db: Session = Depends(get_db), farmer: User = Depends(get_current_user)):
    
    # Get all orders that involve lots originally created by this farmer
    # This satisfies the requirement: "Farmer History should show important lifecycle events involving their former lots... even when the farmer did not directly perform the action."
    
    # First get farmer's lots
    farmer_lot_ids = [lot.id for lot in db.query(ProduceLot.id).filter(ProduceLot.original_farmer_id == farmer.id).all()]
    
    if not farmer_lot_ids:
        return {"success": True, "data": []}
        
    orders = db.query(Order).filter(Order.lot_id.in_(farmer_lot_ids)).order_by(desc(Order.updated_at)).limit(20).all()
    
    history = []
    for o in orders:
        is_direct_actor = (o.farmer_user_id == farmer.id)
        history.append({
            "id": o.id,
            "type": "ORDER",
            "status": o.status,
            "quantity_q": o.quantity_q,
            "price_per_q": o.agreed_price_per_q,
            "date": o.updated_at,
            "is_direct_actor": is_direct_actor,
            "notes": f"Order {o.status} for lot {o.lot_id[:8]}"
        })
        
    return {
        "success": True,
        "data": history,
        "data_label": "DEMO_DATA"
    }
