from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List

from ..database import get_db
from ..models.core import Feedback, User, generate_uuid
from ..deps import get_current_user_optional, get_current_user

feedback_router = APIRouter(prefix="/api/feedback", tags=["Feedback"])

class FeedbackCreate(BaseModel):
    from_user_id: Optional[str] = None
    user_name: Optional[str] = None
    user_role: Optional[str] = None
    to_user_id: Optional[str] = None
    to_buyer_id: Optional[str] = None
    order_id: Optional[str] = None
    rating: int = 5
    subject: Optional[str] = "Platform & Trading Feedback"
    category: Optional[str] = "feedback"  # feedback, complaint, fraud_report, suggestion
    comments: str

class FeedbackResponse(BaseModel):
    success: bool
    data: Optional[dict] = None
    error: Optional[str] = None

@feedback_router.post("", response_model=FeedbackResponse)
def submit_feedback(payload: FeedbackCreate, db: Session = Depends(get_db), current_user: Optional[User] = Depends(get_current_user_optional)):
    """Submit feedback, complaint, or suggestion for admin review."""
    if payload.rating < 1 or payload.rating > 5:
        return FeedbackResponse(success=False, error="Rating must be between 1 and 5")

    user_id = current_user.id if current_user else payload.from_user_id
    user_name = payload.user_name or (current_user.name if current_user else "User")
    user_role = payload.user_role or (current_user.role.value if current_user and hasattr(current_user.role, 'value') else "farmer")

    fb = Feedback(
        id=generate_uuid(),
        from_user_id=user_id,
        user_name=user_name,
        user_role=user_role,
        to_user_id=payload.to_user_id,
        to_buyer_id=payload.to_buyer_id,
        order_id=payload.order_id,
        rating=payload.rating,
        subject=payload.subject,
        category=payload.category or "feedback",
        comments=payload.comments,
        status="open"
    )
    db.add(fb)
    db.commit()
    db.refresh(fb)

    return FeedbackResponse(success=True, data={
        "id": fb.id,
        "rating": fb.rating,
        "subject": fb.subject,
        "category": fb.category,
        "comments": fb.comments,
        "status": fb.status,
        "created_at": str(fb.created_at)
    })

@feedback_router.get("")
def get_feedback(user_id: Optional[str] = None, order_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Get feedback entries, optionally filtered by user or order."""
    query = db.query(Feedback)
    if user_id:
        query = query.filter(Feedback.from_user_id == user_id)
    if order_id:
        query = query.filter(Feedback.order_id == order_id)

    results = query.order_by(Feedback.created_at.desc()).all()
    return {
        "success": True,
        "data": [
            {
                "id": fb.id,
                "from_user_id": fb.from_user_id,
                "user_name": fb.user_name,
                "user_role": fb.user_role,
                "order_id": fb.order_id,
                "rating": fb.rating,
                "subject": fb.subject,
                "category": fb.category,
                "comments": fb.comments,
                "admin_response": fb.admin_response,
                "admin_responded_at": fb.admin_responded_at.isoformat() if fb.admin_responded_at else None,
                "status": fb.status,
                "created_at": str(fb.created_at)
            }
            for fb in results
        ]
    }
