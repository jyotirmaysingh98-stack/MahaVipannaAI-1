from sqlalchemy.orm import Session
from datetime import date, timedelta, datetime
from ..models.core import (
    FPO, Crop, QualityGrade, Market, Buyer,
    BuyerType, MarketType, DataSource, GovernmentScheme,
    User, UserRole, Warehouse, ProduceLot, LotStatus,
    Order, OrderStatus, OrderTracking, UserTransaction, Feedback, Negotiation, NegotiationStatus
)
from ..auth_utils import hash_password

def create_demo_data(db: Session):
    # 1. Create FPO
    fpo = FPO(name="Nashik Onion Producers FPO", district="Nashik", direct_marketing_license_no="MH-DML-998877")
    db.add(fpo)
    db.flush()

    # Create Default Users (both @example.com and @mahavipanan.in supported)
    user_admin = User(name="Admin User", email="admin@example.com", phone="1234567890", password_hash=hash_password("admin"), role=UserRole.admin)
    user_fpo = User(name="Demo FPO", email="fpo@example.com", phone="1234567891", password_hash=hash_password("fpo"), role=UserRole.fpo, fpo_id=fpo.id)
    user_farmer = User(name="Demo Farmer", email="farmer@example.com", phone="1234567892", password_hash=hash_password("farmer"), role=UserRole.farmer, fpo_id=fpo.id)
    user_buyer = User(name="Demo Buyer", email="buyer@example.com", phone="1234567893", password_hash=hash_password("buyer"), role=UserRole.buyer)
    user_govt = User(name="Govt Official", email="govt@example.com", phone="1234567894", password_hash=hash_password("govt"), role=UserRole.government)
    user_delivery = User(name="Delivery Agent", email="delivery@example.com", phone="1234567895", password_hash=hash_password("delivery"), role=UserRole.delivery)

    # Aliases with @mahavipanan.in
    user_admin_mv = User(name="Admin User", email="admin@mahavipanan.in", phone="9934567890", password_hash=hash_password("admin"), role=UserRole.admin)
    user_fpo_mv = User(name="Demo FPO", email="fpo@mahavipanan.in", phone="9934567891", password_hash=hash_password("fpo"), role=UserRole.fpo, fpo_id=fpo.id)
    user_farmer_mv = User(name="Demo Farmer", email="farmer@mahavipanan.in", phone="9934567892", password_hash=hash_password("farmer"), role=UserRole.farmer, fpo_id=fpo.id)
    user_buyer_mv = User(name="Demo Buyer", email="buyer@mahavipanan.in", phone="9934567893", password_hash=hash_password("buyer"), role=UserRole.buyer)
    user_govt_mv = User(name="Govt Official", email="official@mahavipanan.in", phone="9934567894", password_hash=hash_password("govt"), role=UserRole.government)
    user_delivery_mv = User(name="Delivery Agent", email="delivery@mahavipanan.in", phone="9934567895", password_hash=hash_password("delivery"), role=UserRole.delivery)

    db.add_all([
        user_admin, user_fpo, user_farmer, user_buyer, user_govt, user_delivery,
        user_admin_mv, user_fpo_mv, user_farmer_mv, user_buyer_mv, user_govt_mv, user_delivery_mv
    ])
    db.flush()

    # 2. Create Crop & Grades
    crop = Crop(name="Onion", perishability_window_days=30)
    crop_wheat = Crop(name="Wheat", perishability_window_days=180)
    crop_tomato = Crop(name="Tomato", perishability_window_days=14)
    db.add_all([crop, crop_wheat, crop_tomato])
    db.flush()

    grade_a = QualityGrade(crop_id=crop.id, grade_label="A", default_quality_deduction_per_q=0.0)
    grade_b = QualityGrade(crop_id=crop.id, grade_label="B", default_quality_deduction_per_q=50.0)
    db.add_all([grade_a, grade_b])

    # 3. Create Markets
    apmc_nashik = Market(name="Nashik APMC", type=MarketType.apmc, district="Nashik", distance_km_from_fpo=15.0)
    db.add(apmc_nashik)
    db.flush()

    # 4. Create Buyers
    buyer1 = Buyer(
        market_id=apmc_nashik.id,
        name="Local APMC Trader (Nashik)",
        type=BuyerType.trader,
        data_source=DataSource.demo,
        location="Nashik APMC",
        distance_km=15.0,
        gross_price_per_qt=1800.0,
        transport_cost_per_qt=50.0,
        loading_cost_per_qt=20.0,
        commission_rate=0.06, # 6%
        quality_deduction_per_qt=30.0,
        misc_cost_per_qt=10.0,
        payment_days=2,
        min_quantity_qt=10.0,
        max_quantity_qt=100.0,
        reliability_score=85.0
    )

    buyer2 = Buyer(
        name="Direct Processor (Mumbai)",
        type=BuyerType.processor,
        data_source=DataSource.demo,
        location="Vashi, Mumbai",
        distance_km=165.0,
        gross_price_per_qt=1850.0,
        transport_cost_per_qt=180.0,
        loading_cost_per_qt=25.0,
        commission_rate=0.01, # 1% or direct flat
        quality_deduction_per_qt=10.0,
        misc_cost_per_qt=0.0,
        payment_days=7,
        min_quantity_qt=30.0,
        max_quantity_qt=500.0,
        reliability_score=95.0
    )

    buyer3 = Buyer(
        name="Institutional Buyer (Pune)",
        type=BuyerType.institutional,
        data_source=DataSource.demo,
        location="Pune",
        distance_km=210.0,
        gross_price_per_qt=1750.0,
        transport_cost_per_qt=200.0,
        loading_cost_per_qt=20.0,
        commission_rate=0.0, # 0% commission
        quality_deduction_per_qt=50.0, # strict quality
        misc_cost_per_qt=0.0,
        payment_days=15,
        min_quantity_qt=50.0,
        max_quantity_qt=1000.0,
        reliability_score=98.0
    )

    db.add_all([buyer1, buyer2, buyer3])
    db.flush()

    # 5. Create Produce Lots
    lot1 = ProduceLot(
        fpo_id=fpo.id,
        crop_id=crop.id,
        total_quantity_q=50.0,
        total_quantity_kg=5000.0,
        grade_summary="Grade A (Clean & Cured)",
        status=LotStatus.ready,
        harvest_date=date.today() - timedelta(days=3),
        original_farmer_id=user_farmer.id,
        current_owner_id=user_farmer.id,
        expected_price_per_q=1850.0,
        baseline_transport_cost_per_q=50.0,
        loading_cost_per_q=20.0,
        miscellaneous_cost_per_q=10.0
    )
    db.add(lot1)
    db.flush()

    # 6. Create Real Orders with Tracking & Verification Tiers
    order1 = Order(
        lot_id=lot1.id,
        fpo_id=fpo.id,
        buyer_id=buyer2.id,
        status=OrderStatus.in_transit,
        agreed_price_per_q=1850.0,
        quantity_q=50.0,
        crop_name="Red Onion (Grade A)",
        farmer_user_id=user_farmer.id,
        buyer_user_id=user_buyer.id,
        fpo_user_id=user_fpo.id,
        initiated_by_user_id=user_buyer.id,
        special_instructions="Keep crates ventilated and moisture-free. Call unloading bay at Gate 4 upon arrival. Delivery window 8:00 AM - 11:30 AM.",
        pickup_location="Nashik Agri FPO Hub, Lasalgaon Road, Maharashtra",
        delivery_location="Vashi APMC Agri Terminal, Sector 19, Navi Mumbai",
        pickup_lat=20.0063,
        pickup_lng=73.7902,
        delivery_lat=19.0760,
        delivery_lng=72.9984,
        recipient_name="Vikram Mehta (Procurement Lead)",
        recipient_phone="+91 98200 44552",
        tracking_number="MH-TRK-2026-8942",
        verification_tier="expert",
        verification_status="verified",
        verification_notes="NIR spectral analysis: Moisture 12.8%, Grade A+ certified, Zero rot, Blockchain verified.",
        verified_by="MahaAgri Expert Quality Council"
    )

    order2 = Order(
        lot_id=lot1.id,
        fpo_id=fpo.id,
        buyer_id=buyer1.id,
        status=OrderStatus.pickup,
        agreed_price_per_q=1800.0,
        quantity_q=30.0,
        crop_name="Garva Onion (Grade A)",
        farmer_user_id=user_farmer.id,
        buyer_user_id=user_buyer.id,
        fpo_user_id=user_fpo.id,
        initiated_by_user_id=user_buyer.id,
        special_instructions="Weigh at weighing bridge #2 before unloading. Maintain gunny bag dryness.",
        pickup_location="Pimpalgaon Farm Gate, Nashik",
        delivery_location="Nashik APMC Mandi Yard 4",
        pickup_lat=20.1700,
        pickup_lng=73.9800,
        delivery_lat=19.9975,
        delivery_lng=73.7898,
        recipient_name="Rajesh Patil (Trader)",
        recipient_phone="+91 98221 33445",
        tracking_number="MH-TRK-2026-1024",
        verification_tier="professional",
        verification_status="verified",
        verification_notes="Commercial grade check passed. Weight calibrated at certified mandi scale.",
        verified_by="District Agri Inspection Team"
    )

    order3 = Order(
        lot_id=lot1.id,
        fpo_id=fpo.id,
        buyer_id=buyer3.id,
        status=OrderStatus.delivered,
        agreed_price_per_q=1750.0,
        quantity_q=40.0,
        crop_name="White Onion (Grade B)",
        farmer_user_id=user_farmer.id,
        buyer_user_id=user_buyer.id,
        fpo_user_id=user_fpo.id,
        initiated_by_user_id=user_buyer.id,
        special_instructions="Cold storage delivery room #3.",
        pickup_location="Nashik Central Warehouse",
        delivery_location="Pune Agri Logistics Terminal",
        pickup_lat=19.9975,
        pickup_lng=73.7898,
        delivery_lat=18.5204,
        delivery_lng=73.8567,
        recipient_name="Sanjay Kulkarni (Institutional Buyer)",
        recipient_phone="+91 98234 55667",
        tracking_number="MH-TRK-2026-5531",
        verification_tier="preliminary",
        verification_status="verified",
        verification_notes="Baseline physical inspection completed at farm dispatch.",
        verified_by="FPO Quality Cell"
    )

    db.add_all([order1, order2, order3])
    db.flush()

    # Tracking points for Order 1 (Live Route)
    tp1 = OrderTracking(order_id=order1.id, status=OrderStatus.pickup, location="Nashik Agri Hub (Picked Up)", latitude=20.0063, longitude=73.7902, notes="Loaded 50q into ventilated refrigerated container MH-15-EG-4412", is_demo=False)
    tp2 = OrderTracking(order_id=order1.id, status=OrderStatus.in_transit, location="Igatpuri Ghat Section (En Route)", latitude=19.6967, longitude=73.5604, notes="Passing expressway checkpoint on schedule", is_demo=False)
    tp3 = OrderTracking(order_id=order1.id, status=OrderStatus.in_transit, location="Thane Agri Bypass (Approaching Vashi)", latitude=19.2183, longitude=72.9781, notes="Current ETA: 45 minutes", is_demo=False)
    db.add_all([tp1, tp2, tp3])

    # Negotiation for Farmer/Buyer
    neg = Negotiation(
        order_id=order1.id,
        offered_price_per_q=1800.0,
        counter_price_per_q=1850.0,
        status=NegotiationStatus.pending,
        created_by_user_id=user_farmer.id,
        created_by_role="farmer",
        message="Grade A export cured onion batch. Counter-offer ₹1,850/q reflects zero sorting loss."
    )
    db.add(neg)

    # 7. User Transactions (Ledgers for Admin view)
    txns = [
        UserTransaction(
            user_id=user_farmer.id,
            reference_no="TXN-2026-9041",
            type="lot_sale",
            title="Produce Sale Settlement — Red Onion 50q",
            amount=92500.0,
            direction="credit",
            status="completed",
            counterparty_name="Direct Processor (Mumbai)",
            crop_name="Onion",
            quantity_q=50.0,
            created_at=datetime.utcnow() - timedelta(days=2)
        ),
        UserTransaction(
            user_id=user_farmer.id,
            reference_no="TXN-2026-8812",
            type="subsidy_credit",
            title="Government Platform Fee 30% Subsidy Disbursal",
            amount=2775.0,
            direction="credit",
            status="completed",
            counterparty_name="MahaAgri Welfare Fund",
            created_at=datetime.utcnow() - timedelta(days=5)
        ),
        UserTransaction(
            user_id=user_fpo.id,
            reference_no="TXN-2026-7734",
            type="mandi_settlement",
            title="Collective FPO Onion Batch Clearance (120q)",
            amount=216000.0,
            direction="credit",
            status="completed",
            counterparty_name="Vashi Terminal Consortium",
            crop_name="Onion",
            quantity_q=120.0,
            created_at=datetime.utcnow() - timedelta(days=1)
        ),
        UserTransaction(
            user_id=user_buyer.id,
            reference_no="TXN-2026-6621",
            type="direct_purchase",
            title="Direct Purchase Escrow Lock — Red Onion Lot",
            amount=92500.0,
            direction="debit",
            status="completed",
            counterparty_name="Demo Farmer",
            crop_name="Onion",
            quantity_q=50.0,
            created_at=datetime.utcnow() - timedelta(days=2)
        ),
        UserTransaction(
            user_id=user_delivery.id,
            reference_no="TXN-2026-5519",
            type="logistics_payout",
            title="Freight Payout — Nashik to Mumbai Corridor",
            amount=9000.0,
            direction="credit",
            status="completed",
            counterparty_name="MahaVipanan Logistics",
            created_at=datetime.utcnow() - timedelta(days=1)
        )
    ]
    db.add_all(txns)

    # 8. User Feedbacks for Admin
    feedbacks = [
        Feedback(
            from_user_id=user_farmer.id,
            user_name="Demo Farmer (Nashik)",
            user_role="farmer",
            subject="Direct Marketing Saved 6% APMC Commission",
            category="feedback",
            rating=5,
            comments="The direct marketing license allowed us to sell directly to Mumbai processors without APMC mandi deduction. Net realization is ₹120/q higher!",
            admin_response="Thank you for your feedback! MahaVipanan AI directly connects verified FPOs under the Maharashtra Direct Marketing license framework.",
            admin_responded_at=datetime.utcnow() - timedelta(hours=6),
            status="resolved"
        ),
        Feedback(
            from_user_id=user_buyer.id,
            user_name="Demo Buyer (Vashi)",
            user_role="buyer",
            subject="Quality verification report was extremely accurate",
            category="feedback",
            rating=5,
            comments="Expert team NIR spectral analysis gave exact moisture and curing metrics. Seamless delivery.",
            status="open"
        ),
        Feedback(
            from_user_id=user_fpo.id,
            user_name="Nashik Onion Producers FPO",
            user_role="fpo",
            subject="Requesting additional cold storage tie-up in Lasalgaon",
            category="suggestion",
            rating=4,
            comments="We have 12,000 quintals harvest coming up. Adding more cold storage hubs will help avoid distress sales.",
            admin_response="Acknowledged. 3 new cold storage warehouses are being onboarded under the Agri Infrastructure Fund.",
            admin_responded_at=datetime.utcnow() - timedelta(hours=2),
            status="resolved"
        )
    ]
    db.add_all(feedbacks)

    # 9. Government schemes with official URLs
    schemes = [
        GovernmentScheme(
            title="Pradhan Mantri Fasal Bima Yojana (PMFBY)",
            description="Comprehensive crop insurance scheme providing financial support to farmers suffering crop loss/damage arising out of unforeseen natural events.",
            benefits="Comprehensive risk coverage; 1.5% - 2% low premium; direct digital claim settlement to bank account.",
            eligibility="All farmers including sharecroppers and tenant farmers growing notified crops in notified areas.",
            official_url="https://pmfby.gov.in/",
            state="Maharashtra", district="All", crops="Onion,Wheat,Tomato,Soybean,Cotton",
            target_role="farmer", status="published",
            source_key="pmfby", source_type="synced",
        ),
        GovernmentScheme(
            title="Soil Health Card Scheme",
            description="Government of India scheme to promote soil testing and balanced use of fertilizers across Indian farms.",
            benefits="Free soil testing with 12 nutrient parameters and customized crop-specific fertilizer recommendations.",
            eligibility="All landholding farmers across Maharashtra and India.",
            official_url="https://soilhealth.dac.gov.in/",
            state="All", district="All", crops="All Crops",
            target_role="farmer", status="published",
            source_key="soil_health", source_type="synced",
        ),
        GovernmentScheme(
            title="e-NAM — National Agriculture Market",
            description="Pan-India electronic trading portal networking the existing APMC mandis to create a unified national market.",
            benefits="Transparent electronic bidding, single license for trading across state, direct online payment.",
            eligibility="Registered Farmers, FPOs, Commission Agents, and Processors.",
            official_url="https://enam.gov.in/",
            state="All", district="All", crops="All Crops",
            target_role="fpo", status="published",
            source_key="enam", source_type="synced",
        ),
        GovernmentScheme(
            title="PM Kisan Samman Nidhi (PM-KISAN)",
            description="Central sector income support scheme providing ₹6,000 per year in three equal 4-monthly installments.",
            benefits="Direct Benefit Transfer (DBT) of ₹6,000 per year directly into Aadhaar-seeded bank accounts.",
            eligibility="All small and marginal landholder farmer families having cultivable landholding.",
            official_url="https://pmkisan.gov.in/",
            state="All", district="All", crops="All Crops",
            target_role="farmer", status="published",
            source_key="pm_kisan", source_type="synced",
        ),
        GovernmentScheme(
            title="Agriculture Infrastructure Fund (AIF)",
            description="Medium-long term debt financing facility for investment in viable projects for post-harvest management infrastructure and community farming assets.",
            benefits="3% interest subvention per annum up to ₹2 Crore for a maximum period of 7 years; credit guarantee coverage.",
            eligibility="FPOs, Primary Agricultural Credit Societies (PACS), Agri-entrepreneurs, Startups.",
            official_url="https://agriinfra.dac.gov.in/",
            state="All", district="All", crops="All Crops",
            target_role="fpo", status="published",
            source_key="aif", source_type="synced",
        ),
        GovernmentScheme(
            title="MahaDBT Farmer Welfare Schemes",
            description="Maharashtra State direct benefit transfer portal for agricultural machinery, drip irrigation, and warehouse subsidies.",
            benefits="Up to 50% subsidy on farm mechanization, micro-irrigation, shade nets, and pack houses.",
            eligibility="Farmers of Maharashtra registered with 7/12 extract and Aadhaar.",
            official_url="https://mahadbt.maharashtra.gov.in/",
            state="Maharashtra", district="All", crops="All Crops",
            target_role="farmer", status="published",
            source_key="mahadbt", source_type="synced",
        )
    ]
    db.add_all(schemes)

    # 10. Warehouses
    warehouses = [
        Warehouse(name="Central Cold Storage Nashik", fpo_id=fpo.id, location="Pimpalgaon, Nashik", capacity_q=5000.0, storage_type="Cold"),
        Warehouse(name="Maharashtra Agro Dry Hub", fpo_id=fpo.id, location="Lasalgaon, Nashik", capacity_q=12000.0, storage_type="Dry"),
        Warehouse(name="Vashi Agri Terminal", fpo_id=fpo.id, location="Navi Mumbai", capacity_q=8000.0, storage_type="Cold")
    ]
    db.add_all(warehouses)
    db.commit()

    print("Demo data seeded successfully with full realistic accounts, tracking, ledgers, and schemes.")
