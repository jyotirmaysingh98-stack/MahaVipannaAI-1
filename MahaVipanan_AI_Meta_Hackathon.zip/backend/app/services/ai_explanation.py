import httpx
from anthropic import Anthropic
from ..schemas.core import OpportunityResponse
from ..config import settings
import logging

logger = logging.getLogger(__name__)

EXPLANATION_TEMPLATES = {
    "SELL": "Buyer {buyer} is recommended because it offers the highest Net Realizable Price "
            "of Rs. {nrp}/q, which is Rs. {delta} more than the next best option after accounting "
            "for all transportation and commission costs."
}


def _try_fireworks_explanation(prompt: str) -> str | None:
    """Synchronous inference via Meta partner Fireworks AI using Meta Llama 3.1."""
    api_key = settings.FIREWORKS_API_KEY
    if not api_key:
        return None
    try:
        url = "https://api.fireworks.ai/inference/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": settings.FIREWORKS_MODEL,
            "messages": [
                {"role": "system", "content": "You are a concise agricultural market advisor."},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 150,
            "temperature": 0.0,
        }
        with httpx.Client(timeout=4.0) as client:
            resp = client.post(url, json=payload, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"Fireworks Meta Llama explanation failed, will fall back: {e}")
    return None


def generate_ai_explanation(top: OpportunityResponse, alt: OpportunityResponse = None) -> str:
    """
    Generates a 3-sentence plain-language explanation of why the top buyer is recommended.
    Uses Meta Llama 3.1 (Fireworks AI) as primary engine, Anthropic as secondary, else falls back to a deterministic template.
    """
    prompt = f"""
You are a concise agricultural market advisor.
Given the following FPO lot and buyer ranking data, explain in exactly 3 sentences why the 
top-ranked buyer is recommended. Use only the numbers provided. Do not invent any values.

Top Buyer (Recommended): {top.buyer.name}, NRP = ₹{top.nrp_per_qt}/q
"""
    if alt:
        prompt += f"Alternative: {alt.buyer.name}, NRP = ₹{alt.nrp_per_qt}/q, Gross = ₹{alt.buyer.gross_price_per_qt}/q\n"
    
    prompt += f"Freight override applied: {top.freight_override_applied}\n"
    prompt += "Explain the recommendation in plain language for an FPO Director in Maharashtra."

    # 1. Primary: Meta Llama 3.1 via Fireworks AI inference
    fireworks_text = _try_fireworks_explanation(prompt)
    if fireworks_text:
        return fireworks_text

    # 2. Secondary: Anthropic Claude if LLM_API_KEY is configured
    if settings.LLM_API_KEY and settings.LLM_API_KEY != "your_anthropic_api_key_here":
        try:
            client = Anthropic(api_key=settings.LLM_API_KEY)
            response = client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=150,
                temperature=0.0,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text
        except Exception as e:
            logger.error(f"AI Explanation failed: {e}")

    # 3. Deterministic fallback
    return _fallback_explanation(top, alt)

def _fallback_explanation(top: OpportunityResponse, alt: OpportunityResponse = None) -> str:
    delta = round(top.nrp_per_qt - alt.nrp_per_qt, 2) if alt else 0.0
    return EXPLANATION_TEMPLATES["SELL"].format(
        buyer=top.buyer.name,
        nrp=top.nrp_per_qt,
        delta=delta
    )
