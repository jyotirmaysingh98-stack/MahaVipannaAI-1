"""AI provider abstraction used by the negotiation assistant and chatbot.

Deterministic logic (prices, meters, eligibility) never depends on this
module — it is only used to produce human-readable *suggestions*. Every
call degrades gracefully: Gemini -> OpenRouter -> a local template, so the
app keeps working with zero keys configured.
"""
import logging
from typing import Optional

import httpx

from ..config import settings

logger = logging.getLogger(__name__)

TIMEOUT = httpx.Timeout(8.0, connect=4.0)


async def _try_fireworks_llama(prompt: str, system: str) -> Optional[str]:
    """Inference via Meta partner Fireworks AI using Meta Llama 3.1."""
    api_key = settings.FIREWORKS_API_KEY
    if not api_key:
        return None
    url = "https://api.fireworks.ai/inference/v1/chat/completions"
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    body = {
        "model": settings.FIREWORKS_MODEL,
        "messages": messages,
        "temperature": 0.3,
        "max_tokens": 300,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            res = await client.post(url, json=body, headers=headers)
            res.raise_for_status()
            data = res.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"Fireworks Meta Llama provider failed, will fall back: {e}")
        return None


async def _try_gemini(prompt: str, system: str) -> Optional[str]:
    if not settings.GEMINI_API_KEY:
        return None
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{settings.GEMINI_MODEL}:generateContent?key={settings.GEMINI_API_KEY}"
    )
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "systemInstruction": {"parts": [{"text": system}]} if system else None,
        "generationConfig": {"temperature": 0.4, "maxOutputTokens": 300},
    }
    body = {k: v for k, v in body.items() if v is not None}
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            res = await client.post(url, json=body)
            res.raise_for_status()
            data = res.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        logger.warning(f"Gemini provider failed, will fall back: {e}")
        return None


async def _try_openrouter(prompt: str, system: str) -> Optional[str]:
    if not settings.OPENROUTER_API_KEY:
        return None
    url = "https://openrouter.ai/api/v1/chat/completions"
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    body = {"model": settings.OPENROUTER_MODEL, "messages": messages, "temperature": 0.4, "max_tokens": 300}
    headers = {"Authorization": f"Bearer {settings.OPENROUTER_API_KEY}"}
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            res = await client.post(url, json=body, headers=headers)
            res.raise_for_status()
            data = res.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"OpenRouter provider failed, will fall back: {e}")
        return None


async def get_ai_text(prompt: str, system: str = "", fallback: str = "") -> dict:
    """Returns {"text": str, "source": "meta-llama-fireworks"|"meta-llama"|"gemini"|"fallback"}."""
    # 1. Primary: Meta Llama via Fireworks AI partner inference
    text = await _try_fireworks_llama(prompt, system)
    if text:
        return {"text": text, "source": "meta-llama-fireworks"}

    # 2. Secondary: Meta Llama via OpenRouter
    text = await _try_openrouter(prompt, system)
    if text:
        return {"text": text, "source": "meta-llama"}

    # 3. Alternative fallback: Gemini
    text = await _try_gemini(prompt, system)
    if text:
        return {"text": text, "source": "gemini"}

    return {"text": fallback, "source": "fallback"}


LANG_NAMES = {"en": "English", "hi": "Hindi", "mr": "Marathi", "te": "Telugu"}


def lang_instruction(lang: str) -> str:
    name = LANG_NAMES.get(lang, "English")
    return f"Reply only in {name}. Keep it concise (2-4 sentences). Do not invent prices, URLs or facts not given to you."
