import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.database import Base, get_db
from app.seed.demo_data import create_demo_data

# Use in-memory SQLite for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(scope="session")
def db_engine():
    Base.metadata.create_all(bind=engine)
    yield engine
    Base.metadata.drop_all(bind=engine)

@pytest.fixture(scope="function")
def db_session(db_engine):
    connection = db_engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)
    
    # Seed data for every test
    create_demo_data(session)
    
    # Create a dummy user for tests that don't explicitly handle auth
    from app.models.core import User, UserRole, generate_uuid, FPO
    fpo = session.query(FPO).first()
    dummy_user = User(
        id=generate_uuid(),
        name="Test FPO User",
        email="test@fpo.com",
        role=UserRole.fpo,
        password_hash="fakehash",
        fpo_id=fpo.id if fpo else None
    )
    session.add(dummy_user)
    session.commit()
    
    yield session
    
    session.close()
    transaction.rollback()
    connection.close()

@pytest.fixture(scope="function")
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass
            
    def override_get_current_user():
        from app.models.core import User
        # Return the dummy user we created in db_session
        return db_session.query(User).filter(User.email == "test@fpo.com").first()

    app.dependency_overrides[get_db] = override_get_db
    from app.deps import get_current_user
    app.dependency_overrides[get_current_user] = override_get_current_user
    
    with TestClient(app) as c:
        yield c
        
    app.dependency_overrides.clear()
