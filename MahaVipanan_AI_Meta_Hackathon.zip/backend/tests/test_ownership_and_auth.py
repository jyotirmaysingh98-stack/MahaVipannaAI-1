import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from app.main import app
from app.models.core import User, ProduceLot, LotStatus, UserRole, generate_uuid, Order, OrderStatus, Crop
from app.auth_utils import create_access_token

@pytest.fixture
def test_client(db_session):
    from app.database import get_db
    def override_get_db():
        try:
            yield db_session
        finally:
            pass
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    # Clean up the override specifically for this test
    app.dependency_overrides.pop(get_db, None)

@pytest.fixture
def auth_headers():
    def _auth(user: User):
        token = create_access_token({"sub": str(user.id)})
        return {"Authorization": f"Bearer {token}"}
    return _auth

def test_ownership_and_auth(test_client, db_session: Session, auth_headers):
    # Setup crop
    crop = Crop(id="mock_crop", name="Mock Crop")
    db_session.add(crop)

    # Setup users
    farmer1 = User(id=generate_uuid(), name="Farmer 1", role=UserRole.farmer, password_hash="hash")
    farmer2 = User(id=generate_uuid(), name="Farmer 2", role=UserRole.farmer, password_hash="hash")
    fpo1 = User(id=generate_uuid(), name="FPO 1", role=UserRole.fpo, password_hash="hash")
    buyer1 = User(id=generate_uuid(), name="Buyer 1", role=UserRole.buyer, password_hash="hash")
    db_session.add_all([farmer1, farmer2, fpo1, buyer1])
    db_session.commit()

    f1_headers = auth_headers(farmer1)
    f2_headers = auth_headers(farmer2)
    fpo1_headers = auth_headers(fpo1)
    b1_headers = auth_headers(buyer1)

    # A. Farmer creates own lot
    lot_f1 = ProduceLot(
        id=generate_uuid(), crop_id="mock_crop", status=LotStatus.draft,
        original_farmer_id=farmer1.id, current_owner_id=farmer1.id,
        expected_price_per_q=5000.0, total_quantity_kg=1000,
        baseline_transport_cost_per_q=200.0,
        fpo_id=fpo1.id
    )
    lot_fpo = ProduceLot(
        id=generate_uuid(), crop_id="mock_crop", status=LotStatus.ready,
        original_farmer_id=farmer2.id, current_owner_id=fpo1.id,
        expected_price_per_q=6000.0, total_quantity_kg=2000,
        fpo_id=fpo1.id
    )
    db_session.add_all([lot_f1, lot_fpo])
    db_session.commit()

    # B. Farmer edits own lot
    resp = test_client.put(f"/api/lots/{lot_f1.id}", json={"expected_price_per_q": 5100.0}, headers=f1_headers)
    assert resp.status_code == 200
    assert resp.json()["data"]["expected_price_per_q"] == 5100.0

    # C. Farmer cannot edit another Farmer's lot
    resp = test_client.put(f"/api/lots/{lot_f1.id}", json={"expected_price_per_q": 5200.0}, headers=f2_headers)
    assert resp.status_code == 403

    # D. Farmer cannot edit FPO-owned lot
    resp = test_client.put(f"/api/lots/{lot_fpo.id}", json={"expected_price_per_q": 6100.0}, headers=f2_headers)
    assert resp.status_code == 403

    # E. FPO edits own lot
    resp = test_client.put(f"/api/lots/{lot_fpo.id}", json={"expected_price_per_q": 6200.0}, headers=fpo1_headers)
    assert resp.status_code == 200

    # F. FPO cannot access unrelated Farmer lots
    resp = test_client.get("/api/lots/fpo/inventory", headers=fpo1_headers)
    assert resp.status_code == 200
    lots = resp.json()["data"]
    assert len(lots) == 1
    assert lots[0]["id"] == lot_fpo.id

    # H. Legitimately offered Farmer lot is visible to intended FPO
    order = Order(
        id=generate_uuid(), lot_id=lot_f1.id, status=OrderStatus.negotiation,
        farmer_user_id=farmer1.id, fpo_user_id=fpo1.id, quantity_q=10.0
    )
    db_session.add(order)
    db_session.commit()

    resp = test_client.get("/api/lots/fpo/offers", headers=fpo1_headers)
    assert resp.status_code == 200
    offers = resp.json()["data"]
    assert len(offers) == 1
    assert offers[0]["id"] == lot_f1.id

    # J, K, L, M. Farmer -> FPO transfer succeeds (mock accept_negotiation)
    from app.models.core import Negotiation, NegotiationStatus
    nego = Negotiation(
        id=generate_uuid(), order_id=order.id, offered_price_per_q=5100.0,
        status=NegotiationStatus.pending, created_by_user_id=farmer1.id, created_by_role="farmer"
    )
    db_session.add(nego)
    db_session.commit()

    # FPO accepts
    resp = test_client.post(f"/api/negotiations/{order.id}/accept", headers=fpo1_headers)
    assert resp.status_code == 200

    # Verify lot state
    db_session.refresh(lot_f1)
    assert lot_f1.current_owner_id == fpo1.id
    assert lot_f1.original_farmer_id == farmer1.id
    assert lot_f1.status == LotStatus.ready

    # N. Farmer mutation after transfer denied
    resp = test_client.put(f"/api/lots/{lot_f1.id}", json={"expected_price_per_q": 5000.0}, headers=f1_headers)
    assert resp.status_code == 403

    # O. FPO mutation after acquisition succeeds
    resp = test_client.put(f"/api/lots/{lot_f1.id}", json={"expected_price_per_q": 5500.0}, headers=fpo1_headers)
    assert resp.status_code == 200

    # Buyer transaction
    order2 = Order(
        id=generate_uuid(), lot_id=lot_fpo.id, status=OrderStatus.negotiation,
        fpo_user_id=fpo1.id, buyer_user_id=buyer1.id, quantity_q=20.0
    )
    db_session.add(order2)
    db_session.commit()
    
    nego2 = Negotiation(
        id=generate_uuid(), order_id=order2.id, offered_price_per_q=6200.0,
        status=NegotiationStatus.pending, created_by_user_id=buyer1.id, created_by_role="buyer"
    )
    db_session.add(nego2)
    db_session.commit()
    
    resp = test_client.post(f"/api/negotiations/{order2.id}/accept", headers=fpo1_headers)
    assert resp.status_code == 200
    
    db_session.refresh(lot_fpo)
    # Buyer does not take ownership of lot -> remains FPO but sold
    assert lot_fpo.current_owner_id == fpo1.id
    assert lot_fpo.status == LotStatus.sold

