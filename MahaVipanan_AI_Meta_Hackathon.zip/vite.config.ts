import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'


// MahaVipanan AI — Vite config.
// Docs (TECH_STACK.md) mandate Vite (explicitly NOT Next.js).
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': '/src_new_ui',
    },
  },
  server: {
    port: 3000,
    host: true,
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
})
