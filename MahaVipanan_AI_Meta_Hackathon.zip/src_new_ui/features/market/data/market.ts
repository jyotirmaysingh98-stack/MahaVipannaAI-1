/**
 * Synthetic market-intelligence dataset for the Market Rates page.
 *
 * Self-contained (like `@/features/agrivault/data`) so the page works offline
 * with no backend. All figures are ₹ per **quintal** to match the rest of the
 * app (`perQt` in `@/lib/format`). Prices are illustrative demo data, seeded to
 * be consistent with the buyer economics in `backend/app/seed/demo_data.py`.
 */

export type BuyerType = 'trader' | 'processor' | 'institutional' | 'exporter' | 'retailer'

export interface Commodity {
  id: string
  name: string
  /** Optional variety / grade note shown under the name. */
  variety?: string
  /** Benchmark market / APMC mandi the modal rate is quoted from. */
  mandi: string
  /** Modal (reference) market rate, ₹/quintal — the live feed walks around this. */
  basePrice: number
  /** Govt Minimum Support Price, ₹/quintal, where one exists. */
  msp?: number
}

export interface BuyerOffer {
  buyerId: string
  buyerName: string
  buyerType: BuyerType
  commodityId: string
  /** Gross offered price, ₹/quintal (before NRP deductions). */
  offeredPrice: number
  location: string
  distanceKm: number
  paymentDays: number
  /** 0–100 reliability, mirroring the buyer model in the radar. */
  reliability: number
}

/** The commodities tracked on the board. Modal rates are demo values. */
export const COMMODITIES: Commodity[] = [
  { id: 'onion',    name: 'Onion',    variety: 'Grade A, medium',   mandi: 'Nashik APMC, MH',      basePrice: 1850 },
  { id: 'tomato',   name: 'Tomato',   variety: 'Hybrid, firm',      mandi: 'Pune APMC, MH',        basePrice: 2100 },
  { id: 'potato',   name: 'Potato',   variety: 'Jyoti, ware',       mandi: 'Agra Mandi, UP',       basePrice: 1420 },
  { id: 'wheat',    name: 'Wheat',    variety: 'Lokwan / Sharbati', mandi: 'Indore Mandi, MP',     basePrice: 2585, msp: 2425 },
  { id: 'soybean',  name: 'Soybean',  variety: 'Yellow, FAQ',       mandi: 'Latur APMC, MH',       basePrice: 4780, msp: 4892 },
  { id: 'cotton',   name: 'Cotton',   variety: 'Medium staple',     mandi: 'Akola APMC, MH',       basePrice: 7250, msp: 7521 },
  { id: 'maize',    name: 'Maize',    variety: 'Yellow, FAQ',       mandi: 'Nizamabad, TS',        basePrice: 2140, msp: 2225 },
  { id: 'turmeric', name: 'Turmeric', variety: 'Finger, polished',  mandi: 'Erode, TN',            basePrice: 14200 },
  { id: 'gram',     name: 'Gram (Chana)', variety: 'Desi, bold',    mandi: 'Bikaner Mandi, RJ',    basePrice: 5420, msp: 5440 },
  { id: 'paddy',    name: 'Paddy',    variety: 'Common, Grade A',   mandi: 'Karnal Mandi, HR',     basePrice: 2280, msp: 2300 },
]

export const COMMODITY_BY_ID: Record<string, Commodity> = Object.fromEntries(
  COMMODITIES.map((c) => [c.id, c]),
)

/**
 * Compact offer spec — `delta` is ₹/qt relative to the commodity's modal rate,
 * so offers stay meaningfully above/below market as the base is tuned. Expanded
 * into concrete `BuyerOffer`s below (deterministic, no randomness).
 */
interface OfferSpec {
  name: string
  type: BuyerType
  delta: number
  location: string
  distanceKm: number
  paymentDays: number
  reliability: number
}

const OFFER_SPECS: Record<string, OfferSpec[]> = {
  onion: [
    { name: 'Local APMC Trader',        type: 'trader',        delta: -50,  location: 'Nashik APMC',   distanceKm: 15,  paymentDays: 2,  reliability: 85 },
    { name: 'Nashik Exports',           type: 'exporter',      delta: +120, location: 'Vashi, Mumbai', distanceKm: 165, paymentDays: 7,  reliability: 95 },
    { name: 'FreshMart Retail DC',      type: 'retailer',      delta: +60,  location: 'Pune',          distanceKm: 210, paymentDays: 15, reliability: 92 },
    { name: 'Sahyadri Processing',      type: 'processor',     delta: -10,  location: 'Nashik',        distanceKm: 22,  paymentDays: 5,  reliability: 90 },
  ],
  tomato: [
    { name: 'Pune Wholesale Trader',    type: 'trader',        delta: -80,  location: 'Pune APMC',     distanceKm: 18,  paymentDays: 1,  reliability: 80 },
    { name: 'KetchupCo Processing',     type: 'processor',     delta: +90,  location: 'Ranjangaon',    distanceKm: 55,  paymentDays: 10, reliability: 93 },
    { name: 'BigBasket DC',             type: 'retailer',      delta: +40,  location: 'Bhiwandi',      distanceKm: 140, paymentDays: 12, reliability: 90 },
  ],
  potato: [
    { name: 'Agra Cold-Store Trader',   type: 'trader',        delta: -30,  location: 'Agra',          distanceKm: 12,  paymentDays: 3,  reliability: 84 },
    { name: 'Balaji Wafers',            type: 'processor',     delta: +110, location: 'Rajkot',        distanceKm: 320, paymentDays: 9,  reliability: 96 },
    { name: 'Reliance Fresh DC',        type: 'retailer',      delta: +25,  location: 'Delhi NCR',     distanceKm: 210, paymentDays: 15, reliability: 91 },
    { name: 'Mid-Day Meal Board',       type: 'institutional', delta: -60,  location: 'Lucknow',       distanceKm: 330, paymentDays: 21, reliability: 98 },
  ],
  wheat: [
    { name: 'Indore Mandi Arhtiya',     type: 'trader',        delta: -40,  location: 'Indore',        distanceKm: 10,  paymentDays: 2,  reliability: 82 },
    { name: 'ITC Foods (Aashirvaad)',   type: 'processor',     delta: +130, location: 'Dewas',         distanceKm: 40,  paymentDays: 7,  reliability: 97 },
    { name: 'FCI Procurement',          type: 'institutional', delta: +5,   location: 'Indore',        distanceKm: 14,  paymentDays: 10, reliability: 99 },
  ],
  soybean: [
    { name: 'Latur Oil Trader',         type: 'trader',        delta: -70,  location: 'Latur',         distanceKm: 8,   paymentDays: 2,  reliability: 83 },
    { name: 'Ruchi Soya Mill',          type: 'processor',     delta: +160, location: 'Nagpur',        distanceKm: 220, paymentDays: 8,  reliability: 95 },
    { name: 'NAFED (MSP window)',       type: 'institutional', delta: +112, location: 'Latur',         distanceKm: 8,   paymentDays: 14, reliability: 99 },
  ],
  cotton: [
    { name: 'Akola Ginning Trader',     type: 'trader',        delta: -120, location: 'Akola',         distanceKm: 12,  paymentDays: 3,  reliability: 81 },
    { name: 'CCI Procurement',          type: 'institutional', delta: +271, location: 'Akola',         distanceKm: 12,  paymentDays: 12, reliability: 99 },
    { name: 'Vardhman Textiles',        type: 'processor',     delta: +90,  location: 'Ludhiana',      distanceKm: 1200,paymentDays: 15, reliability: 96 },
    { name: 'Welspun Exports',          type: 'exporter',      delta: +40,  location: 'Mumbai Port',   distanceKm: 580, paymentDays: 20, reliability: 94 },
  ],
  maize: [
    { name: 'Nizamabad Feed Trader',    type: 'trader',        delta: -55,  location: 'Nizamabad',     distanceKm: 9,   paymentDays: 2,  reliability: 80 },
    { name: 'Suguna Poultry Feed',      type: 'processor',     delta: +75,  location: 'Hyderabad',     distanceKm: 175, paymentDays: 9,  reliability: 94 },
    { name: 'Starch Mill (Sukhjit)',    type: 'processor',     delta: +30,  location: 'Warangal',      distanceKm: 130, paymentDays: 11, reliability: 90 },
  ],
  turmeric: [
    { name: 'Erode Spice Trader',       type: 'trader',        delta: -300, location: 'Erode',         distanceKm: 6,   paymentDays: 3,  reliability: 82 },
    { name: 'MDH / Everest Spices',     type: 'processor',     delta: +650, location: 'Sangli',        distanceKm: 620, paymentDays: 10, reliability: 96 },
    { name: 'Gulf Spice Exporters',     type: 'exporter',      delta: +420, location: 'Chennai Port',  distanceKm: 400, paymentDays: 25, reliability: 92 },
  ],
  gram: [
    { name: 'Bikaner Dal Trader',       type: 'trader',        delta: -60,  location: 'Bikaner',       distanceKm: 11,  paymentDays: 2,  reliability: 83 },
    { name: 'NAFED (MSP window)',       type: 'institutional', delta: +20,  location: 'Bikaner',       distanceKm: 11,  paymentDays: 14, reliability: 99 },
    { name: 'Dal Mill (Rajdhani)',      type: 'processor',     delta: +95,  location: 'Jaipur',        distanceKm: 330, paymentDays: 9,  reliability: 93 },
  ],
  paddy: [
    { name: 'Karnal Mandi Arhtiya',     type: 'trader',        delta: -35,  location: 'Karnal',        distanceKm: 7,   paymentDays: 2,  reliability: 82 },
    { name: 'FCI Procurement',          type: 'institutional', delta: +20,  location: 'Karnal',        distanceKm: 7,   paymentDays: 10, reliability: 99 },
    { name: 'KRBL Basmati Mill',        type: 'processor',     delta: +140, location: 'Ghaziabad',     distanceKm: 130, paymentDays: 12, reliability: 95 },
  ],
}

/** All buyer offers, expanded from the compact specs above. */
export const BUYER_OFFERS: BuyerOffer[] = COMMODITIES.flatMap((commodity) =>
  (OFFER_SPECS[commodity.id] ?? []).map((spec, i) => ({
    buyerId: `${commodity.id}-${i}`,
    buyerName: spec.name,
    buyerType: spec.type,
    commodityId: commodity.id,
    offeredPrice: commodity.basePrice + spec.delta,
    location: spec.location,
    distanceKm: spec.distanceKm,
    paymentDays: spec.paymentDays,
    reliability: spec.reliability,
  })),
)

/** Offers for one commodity, best (highest) offer first. */
export function offersFor(commodityId: string): BuyerOffer[] {
  return BUYER_OFFERS.filter((o) => o.commodityId === commodityId).sort(
    (a, b) => b.offeredPrice - a.offeredPrice,
  )
}

/** Human labels + Badge tones for buyer archetypes. */
export const BUYER_TYPE_LABEL: Record<BuyerType, string> = {
  trader: 'Trader',
  processor: 'Processor',
  institutional: 'Institutional',
  exporter: 'Exporter',
  retailer: 'Retailer',
}
