import { useCallback, useEffect, useRef, useState } from 'react'
import { COMMODITIES } from '@/features/market/data/market'

/** A single commodity's live-simulated rate + intraday context. */
export interface LiveRate {
  commodityId: string
  price: number
  prevPrice: number
  dayOpen: number
  dayHigh: number
  dayLow: number
  changeAbs: number
  changePct: number
  /** Recent prices, oldest → newest, for the sparkline. */
  history: number[]
  /** Synthetic lots traded today. */
  lots: number
  updatedAt: number
}

export interface LiveRatesState {
  rates: Record<string, LiveRate>
  lastUpdated: number
  live: boolean
  toggleLive: () => void
  tickMs: number
}

const HISTORY_LEN = 40
const TICK_MS = 2500
/** Max per-tick move as a fraction of price (±). */
const STEP = 0.004

function prefersReducedMotion(): boolean {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches
  } catch {
    return false
  }
}

/** Bounded random walk one step; keeps price within a sane band of its anchor. */
function walk(price: number, anchor: number): number {
  const drift = (Math.random() * 2 - 1) * STEP
  // Gentle pull back toward the anchor so it never wanders off.
  const meanReversion = (anchor - price) / anchor * 0.15
  const next = price * (1 + drift + meanReversion)
  const lo = anchor * 0.9
  const hi = anchor * 1.12
  return Math.round(Math.min(hi, Math.max(lo, next)))
}

function seed(): Record<string, LiveRate> {
  const out: Record<string, LiveRate> = {}
  for (const c of COMMODITIES) {
    const history: number[] = []
    let p = Math.round(c.basePrice * (0.99 + Math.random() * 0.02))
    const open = p
    for (let i = 0; i < HISTORY_LEN; i++) {
      p = walk(p, c.basePrice)
      history.push(p)
    }
    const price = history[history.length - 1]
    out[c.id] = {
      commodityId: c.id,
      price,
      prevPrice: history[history.length - 2] ?? price,
      dayOpen: open,
      dayHigh: Math.max(...history),
      dayLow: Math.min(...history),
      changeAbs: price - open,
      changePct: (price - open) / open,
      history,
      lots: 200 + Math.floor(Math.random() * 1600),
      updatedAt: Date.now(),
    }
  }
  return out
}

/**
 * Simulated live market feed. There is no real rates API in this prototype, so
 * this mirrors a ticking exchange feed with a bounded, mean-reverting random
 * walk — consistent with the app's synthetic-demo data. Ticks every ~2.5s while
 * `live`; pauses automatically when the reader prefers reduced motion.
 */
export function useLiveRates(): LiveRatesState {
  const [rates, setRates] = useState<Record<string, LiveRate>>(seed)
  const [lastUpdated, setLastUpdated] = useState<number>(() => Date.now())
  const [live, setLive] = useState<boolean>(() => !prefersReducedMotion())
  const timer = useRef<number | null>(null)

  const tick = useCallback(() => {
    setRates((prev) => {
      const next: Record<string, LiveRate> = {}
      for (const c of COMMODITIES) {
        const r = prev[c.id]
        const price = walk(r.price, c.basePrice)
        const history = [...r.history.slice(-(HISTORY_LEN - 1)), price]
        next[c.id] = {
          ...r,
          prevPrice: r.price,
          price,
          dayHigh: Math.max(r.dayHigh, price),
          dayLow: Math.min(r.dayLow, price),
          changeAbs: price - r.dayOpen,
          changePct: (price - r.dayOpen) / r.dayOpen,
          history,
          lots: r.lots + Math.floor(Math.random() * 24),
          updatedAt: Date.now(),
        }
      }
      return next
    })
    setLastUpdated(Date.now())
  }, [])

  useEffect(() => {
    if (!live) return
    timer.current = window.setInterval(tick, TICK_MS)
    return () => {
      if (timer.current !== null) window.clearInterval(timer.current)
      timer.current = null
    }
  }, [live, tick])

  const toggleLive = useCallback(() => setLive((v) => !v), [])

  return { rates, lastUpdated, live, toggleLive, tickMs: TICK_MS }
}
