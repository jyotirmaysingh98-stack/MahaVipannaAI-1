import { useState } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { ArrowDownRight, ArrowUpRight, Clock, MapPin, ShieldCheck } from 'lucide-react'
import { cn } from '@/lib/cn'
import { days, inr, inrCompact, km, pct } from '@/lib/format'
import { Badge } from '@/components/ui/Badge'
import { CHART } from '@/components/charts/theme'
import {
  BUYER_TYPE_LABEL,
  COMMODITIES,
  COMMODITY_BY_ID,
  offersFor,
  type BuyerType,
} from '@/features/market/data/market'
import type { LiveRate } from '@/features/market/lib/useLiveRates'

const TYPE_TONE: Record<BuyerType, 'pine' | 'amber' | 'teal' | 'indigo' | 'clay'> = {
  trader: 'amber',
  processor: 'teal',
  institutional: 'indigo',
  exporter: 'pine',
  retailer: 'clay',
}

interface Row {
  name: string
  offer: number
  premium: number // fraction vs market
  above: boolean
}

function ChartTooltip({
  active,
  payload,
  market,
}: {
  active?: boolean
  payload?: { payload: Row }[]
  market: number
}) {
  if (!active || !payload?.length) return null
  const row = payload[0].payload
  return (
    <div className="rounded-xl border border-line bg-surface/95 p-3 shadow-float backdrop-blur">
      <p className="mb-1.5 text-sm font-semibold text-ink">{row.name}</p>
      <dl className="tnum space-y-1 text-xs">
        <div className="flex items-center justify-between gap-6">
          <dt className="text-ink-2">Offered</dt>
          <dd className="font-medium text-ink">{inr(row.offer)}/qt</dd>
        </div>
        <div className="flex items-center justify-between gap-6">
          <dt className="text-ink-2">Market rate</dt>
          <dd className="font-medium text-ink">{inr(market)}/qt</dd>
        </div>
        <div className="flex items-center justify-between gap-6 border-t border-line pt-1">
          <dt className={cn('font-semibold', row.above ? 'text-pine-700' : 'text-clay-600')}>
            {row.above ? 'Premium' : 'Discount'}
          </dt>
          <dd className={cn('font-semibold', row.above ? 'text-pine-700' : 'text-clay-600')}>
            {row.above ? '+' : '−'}{pct(Math.abs(row.premium))}
          </dd>
        </div>
      </dl>
    </div>
  )
}

/**
 * "Price Comparison" — every buyer's offered price for a commodity against the
 * live market/mandi rate, so a director sees at a glance who is bidding above or
 * below the going rate. The benchmark comes from the page's shared live feed.
 */
export function PriceComparison({ rates }: { rates: Record<string, LiveRate> }) {
  const [commodityId, setCommodityId] = useState(COMMODITIES[0].id)
  const commodity = COMMODITY_BY_ID[commodityId]
  const market = rates[commodityId]?.price ?? commodity.basePrice
  const offers = offersFor(commodityId)

  const rows: Row[] = offers.map((o) => ({
    name: o.buyerName.replace(/\s*\(.*\)/, ''),
    offer: o.offeredPrice,
    premium: (o.offeredPrice - market) / market,
    above: o.offeredPrice >= market,
  }))

  const best = offers[0]
  const avg = offers.length ? Math.round(offers.reduce((s, o) => s + o.offeredPrice, 0) / offers.length) : 0
  const spread = offers.length ? offers[0].offeredPrice - offers[offers.length - 1].offeredPrice : 0

  return (
    <div className="space-y-5">
      {/* Commodity picker */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <label className="text-sm font-medium text-ink-2">
          Compare buyer offers against the market rate for:
        </label>
        <select
          value={commodityId}
          onChange={(e) => setCommodityId(e.target.value)}
          className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink shadow-sm focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30 sm:w-64"
        >
          {COMMODITIES.map((c) => (
            <option key={c.id} value={c.id}>{c.name} — {c.mandi}</option>
          ))}
        </select>
      </div>

      {/* Summary tiles */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <SummaryTile label="Market rate" value={`${inr(market)}/qt`} sub={commodity.mandi} tone="teal" />
        <SummaryTile
          label="Best offer"
          value={`${inr(best.offeredPrice)}/qt`}
          sub={`${best.buyerName} · ${best.offeredPrice >= market ? '+' : '−'}${pct(Math.abs((best.offeredPrice - market) / market))}`}
          tone="pine"
        />
        <SummaryTile label="Average offer" value={`${inr(avg)}/qt`} sub={`${offers.length} buyers`} tone="amber" />
        <SummaryTile label="Spread (high−low)" value={`${inr(spread)}/qt`} sub="across buyers" tone="clay" />
      </div>

      {/* Chart */}
      <div className="rounded-2xl border border-line bg-surface p-4 shadow-card">
        <div className="mb-3 flex flex-wrap items-center gap-4 text-xs text-ink-2">
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-pine-500" /> At / above market
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-clay-500" /> Below market
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-0.5 w-4" style={{ background: CHART.axis }} /> Market rate
          </span>
          {commodity.msp && (
            <span className="flex items-center gap-1.5">
              <span className="inline-block h-0.5 w-4" style={{ background: CHART.indigo }} /> MSP
            </span>
          )}
          <span className="ml-auto text-ink-3">₹/qt</span>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={rows} margin={{ top: 24, right: 8, left: 4, bottom: 4 }} barCategoryGap="26%">
            <CartesianGrid vertical={false} stroke={CHART.grid} />
            <XAxis dataKey="name" tickLine={false} axisLine={false} tick={{ fill: CHART.axis, fontSize: 11 }} interval={0} />
            <YAxis
              tickFormatter={(v) => inrCompact(v)}
              tickLine={false}
              axisLine={false}
              width={54}
              tick={{ fill: CHART.axis, fontSize: 11 }}
              domain={['dataMin - 200', 'dataMax + 200']}
            />
            <Tooltip cursor={{ fill: 'rgba(21,115,79,0.05)' }} content={<ChartTooltip market={market} />} />
            <ReferenceLine
              y={market}
              stroke={CHART.axis}
              strokeDasharray="5 4"
              strokeWidth={1.5}
              label={{ value: `Market ${inr(market)}`, position: 'right', fill: CHART.axis, fontSize: 10 }}
            />
            {commodity.msp && (
              <ReferenceLine y={commodity.msp} stroke={CHART.indigo} strokeDasharray="2 3" strokeWidth={1.5} />
            )}
            <Bar dataKey="offer" radius={[4, 4, 0, 0]} maxBarSize={48} isAnimationActive={false}>
              {rows.map((r) => (
                <Cell key={r.name} fill={r.above ? CHART.net : CHART.clay} />
              ))}
              <LabelList dataKey="offer" position="top" formatter={(v: number) => inr(v)} style={{ fill: CHART.ink, fontSize: 11, fontWeight: 600 }} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Buyer rows */}
      <div className="space-y-2.5">
        {offers.map((o) => {
          const premium = (o.offeredPrice - market) / market
          const above = o.offeredPrice >= market
          return (
            <div
              key={o.buyerId}
              className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4 shadow-card"
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h4 className="font-display text-base font-semibold text-ink">{o.buyerName}</h4>
                  <Badge tone={TYPE_TONE[o.buyerType]}>{BUYER_TYPE_LABEL[o.buyerType]}</Badge>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-3">
                  <span className="inline-flex items-center gap-1"><MapPin size={11} /> {o.location} · {km(o.distanceKm)}</span>
                  <span className="inline-flex items-center gap-1"><Clock size={11} /> Pays in {days(o.paymentDays)}</span>
                  <span className="inline-flex items-center gap-1"><ShieldCheck size={11} /> {o.reliability}% reliable</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="tnum font-display text-lg font-bold text-ink">{inr(o.offeredPrice)}<span className="text-xs font-normal text-ink-3">/qt</span></p>
                  <p className="text-[0.7rem] text-ink-3">offered</p>
                </div>
                <span
                  className={cn(
                    'tnum inline-flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-sm font-semibold ring-1 ring-inset',
                    above ? 'bg-pine-50 text-pine-700 ring-pine-200' : 'bg-clay-50 text-clay-600 ring-clay-100',
                  )}
                  title={above ? 'Above the market rate' : 'Below the market rate'}
                >
                  {above ? <ArrowUpRight size={14} strokeWidth={2.5} /> : <ArrowDownRight size={14} strokeWidth={2.5} />}
                  {above ? '+' : '−'}{pct(Math.abs(premium))}
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function SummaryTile({
  label,
  value,
  sub,
  tone,
}: {
  label: string
  value: string
  sub?: string
  tone: 'pine' | 'amber' | 'teal' | 'clay'
}) {
  const ring: Record<string, string> = {
    pine: 'ring-pine-100',
    amber: 'ring-amber-200',
    teal: 'ring-teal-100',
    clay: 'ring-clay-100',
  }
  return (
    <div className={cn('rounded-2xl border border-line bg-surface p-4 shadow-card ring-1 ring-inset', ring[tone])}>
      <p className="text-xs font-medium text-ink-3">{label}</p>
      <p className="tnum mt-0.5 font-display text-xl font-bold text-ink">{value}</p>
      {sub && <p className="mt-0.5 truncate text-[0.7rem] text-ink-3">{sub}</p>}
    </div>
  )
}
