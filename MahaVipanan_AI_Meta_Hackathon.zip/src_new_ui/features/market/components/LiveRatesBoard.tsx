import { motion } from 'framer-motion'
import {
  ArrowDown,
  ArrowUp,
  Layers,
  Pause,
  Play,
  TrendingDown,
  TrendingUp,
} from 'lucide-react'
import { cn } from '@/lib/cn'
import { inr, num, pct } from '@/lib/format'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { KpiCard } from '@/components/dashboard/KpiCard'
import { AnimatedNumber } from '@/components/ui/AnimatedNumber'
import { COMMODITIES } from '@/features/market/data/market'
import type { LiveRate, LiveRatesState } from '@/features/market/lib/useLiveRates'

/** Tiny inline-SVG sparkline from the rate's recent history. */
function Sparkline({ data, up }: { data: number[]; up: boolean }) {
  const w = 120
  const h = 36
  if (data.length < 2) return <svg width={w} height={h} aria-hidden />
  const min = Math.min(...data)
  const max = Math.max(...data)
  const span = max - min || 1
  const stroke = up ? '#15734F' : '#A8442C' // pine / clay
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w
    const y = h - ((v - min) / span) * (h - 4) - 2
    return [x, y] as const
  })
  const line = pts.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ')
  const area = `${line} L${w},${h} L0,${h} Z`
  const gid = `spark-${up ? 'up' : 'dn'}`
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible" aria-hidden>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={stroke} stopOpacity="0.18" />
          <stop offset="100%" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gid})`} />
      <path d={line} fill="none" stroke={stroke} strokeWidth={1.75} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  )
}

function ChangeChip({ rate }: { rate: LiveRate }) {
  const up = rate.changePct >= 0
  return (
    <span
      className={cn(
        'tnum inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold ring-1 ring-inset',
        up ? 'bg-pine-50 text-pine-700 ring-pine-200' : 'bg-clay-50 text-clay-600 ring-clay-100',
      )}
    >
      {up ? <ArrowUp size={12} strokeWidth={2.5} /> : <ArrowDown size={12} strokeWidth={2.5} />}
      {pct(Math.abs(rate.changePct))}
      <span className="opacity-70">({up ? '+' : '−'}{inr(Math.abs(rate.changeAbs))})</span>
    </span>
  )
}

function RateCard({ rate, commodityId }: { rate: LiveRate; commodityId: string }) {
  const commodity = COMMODITIES.find((c) => c.id === commodityId)!
  const up = rate.changePct >= 0
  return (
    <motion.div
      variants={fadeUp}
      className="rounded-2xl border border-line bg-surface p-4 shadow-card transition-shadow hover:shadow-card-lg"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="font-display text-base font-bold leading-tight text-ink">{commodity.name}</h3>
          <p className="truncate text-xs text-ink-3">{commodity.mandi}</p>
        </div>
        {commodity.msp && (
          <Badge tone="indigo" className="shrink-0">MSP {inr(commodity.msp)}</Badge>
        )}
      </div>

      <div className="mt-3 flex items-end justify-between gap-2">
        <AnimatedNumber
          value={rate.price}
          format={(n) => inr(n)}
          duration={0.6}
          className={cn('font-display text-2xl font-bold tracking-tight', up ? 'text-pine-700' : 'text-clay-600')}
        />
        <div className="pb-0.5"><Sparkline data={rate.history} up={up} /></div>
      </div>

      <div className="mt-2 flex items-center justify-between">
        <ChangeChip rate={rate} />
        <span className="text-[0.7rem] text-ink-3">/qt</span>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 border-t border-line/60 pt-3 text-[0.7rem] text-ink-3">
        <span className="tnum">Day range<br /><span className="font-medium text-ink-2">{inr(rate.dayLow)} – {inr(rate.dayHigh)}</span></span>
        <span className="tnum text-right">Lots traded<br /><span className="font-medium text-ink-2">{num(rate.lots)}</span></span>
      </div>
    </motion.div>
  )
}

/**
 * "Live Trade & Market Rates" board — a KPI strip + a live-updating grid of
 * commodity rate cards with sparklines. Consumes the shared feed from the page.
 */
export function LiveRatesBoard({ feed }: { feed: LiveRatesState }) {
  const { rates, lastUpdated, live, toggleLive } = feed
  const list = COMMODITIES.map((c) => rates[c.id]).filter(Boolean)
  const gainers = list.filter((r) => r.changePct > 0).length
  const losers = list.filter((r) => r.changePct < 0).length
  const avg = list.length ? list.reduce((s, r) => s + r.changePct, 0) / list.length : 0
  const time = new Date(lastUpdated).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })

  return (
    <div>
      {/* KPI strip */}
      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard label="Commodities tracked" value={list.length} icon={Layers} accent="teal" />
        <KpiCard label="Gainers" value={gainers} icon={TrendingUp} accent="pine" />
        <KpiCard label="Losers" value={losers} icon={TrendingDown} accent="clay" />
        <KpiCard
          label="Avg change"
          value={<span className={avg >= 0 ? 'text-pine-700' : 'text-clay-600'}>{avg >= 0 ? '+' : '−'}{pct(Math.abs(avg))}</span>}
          icon={avg >= 0 ? TrendingUp : TrendingDown}
          accent={avg >= 0 ? 'pine' : 'clay'}
        />
      </div>

      {/* Live status bar */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface px-4 py-2.5 shadow-card">
        <div className="flex items-center gap-2.5">
          <span className="relative grid h-2.5 w-2.5 place-items-center">
            <span className={cn('h-2.5 w-2.5 rounded-full', live ? 'animate-pulse-ring bg-teal-500' : 'bg-ink-3')} />
          </span>
          <span className="text-sm font-semibold text-ink">{live ? 'Live' : 'Paused'}</span>
          <span className="tnum text-xs text-ink-3">· updated {time}</span>
        </div>
        <Button variant="secondary" size="sm" onClick={toggleLive}>
          {live ? <><Pause size={14} /> Pause</> : <><Play size={14} /> Resume</>}
        </Button>
      </div>

      {/* Rate cards */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
      >
        {COMMODITIES.map((c) => rates[c.id] && <RateCard key={c.id} commodityId={c.id} rate={rates[c.id]} />)}
      </motion.div>
    </div>
  )
}
