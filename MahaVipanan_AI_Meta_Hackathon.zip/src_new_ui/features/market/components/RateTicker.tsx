import { ArrowDown, ArrowUp } from 'lucide-react'
import { cn } from '@/lib/cn'
import { inr, pct } from '@/lib/format'
import { COMMODITIES } from '@/features/market/data/market'
import type { LiveRate } from '@/features/market/lib/useLiveRates'

/**
 * Seamless scrolling trade ticker — the "tape" across the top of the board.
 * Content is duplicated so the existing `animate-marquee` (-50% translate)
 * loops without a seam. Pauses on hover and under reduced motion.
 */
export function RateTicker({ rates, live }: { rates: Record<string, LiveRate>; live: boolean }) {
  const items = COMMODITIES.map((c) => ({ commodity: c, rate: rates[c.id] })).filter((x) => x.rate)

  return (
    <div className="relative overflow-hidden rounded-2xl border border-line bg-forest-950 py-2.5">
      {/* edge fades */}
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-12 bg-gradient-to-r from-forest-950 to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-12 bg-gradient-to-l from-forest-950 to-transparent" />
      <div
        className={cn(
          'flex w-max gap-8 hover:[animation-play-state:paused]',
          live && 'animate-marquee',
        )}
      >
        {[0, 1].map((dup) => (
          <div key={dup} className="flex shrink-0 items-center gap-8" aria-hidden={dup === 1}>
            {items.map(({ commodity, rate }) => {
              const up = rate.changePct >= 0
              return (
                <span key={commodity.id} className="flex items-center gap-2 whitespace-nowrap text-sm">
                  <span className="font-semibold text-white/90">{commodity.name}</span>
                  <span className="tnum font-semibold text-white">{inr(rate.price)}</span>
                  <span
                    className={cn(
                      'tnum inline-flex items-center gap-0.5 text-xs font-semibold',
                      up ? 'text-lime-400' : 'text-clay-300',
                    )}
                  >
                    {up ? <ArrowUp size={12} /> : <ArrowDown size={12} />}
                    {pct(Math.abs(rate.changePct))}
                  </span>
                </span>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  )
}
