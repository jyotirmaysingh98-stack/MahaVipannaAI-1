/**
 * Ported verbatim from agrivault-ai `data/mockDistricts.ts`. Data and types
 * unchanged; only the file location moved under `@/features/agrivault`.
 */
export type RiskLevel = 'low' | 'medium' | 'high'

export interface District {
  id: string
  name: string
  state: string
  baseRiskLevel: RiskLevel
  lat: number
  lng: number
}

export const mockDistricts: District[] = [
  { id: 'd1', name: 'Nashik', state: 'Maharashtra', baseRiskLevel: 'medium', lat: 19.99, lng: 73.79 },
  { id: 'd2', name: 'Nagpur', state: 'Maharashtra', baseRiskLevel: 'low', lat: 21.15, lng: 79.09 },
  { id: 'd3', name: 'Indore', state: 'Madhya Pradesh', baseRiskLevel: 'low', lat: 22.72, lng: 75.86 },
  { id: 'd4', name: 'Jaipur', state: 'Rajasthan', baseRiskLevel: 'medium', lat: 26.91, lng: 75.79 },
  { id: 'd5', name: 'Lucknow', state: 'Uttar Pradesh', baseRiskLevel: 'high', lat: 26.85, lng: 80.95 },
  { id: 'd6', name: 'Patna', state: 'Bihar', baseRiskLevel: 'high', lat: 25.59, lng: 85.14 },
  { id: 'd7', name: 'Guntur', state: 'Andhra Pradesh', baseRiskLevel: 'medium', lat: 16.30, lng: 80.44 },
  { id: 'd8', name: 'Ludhiana', state: 'Punjab', baseRiskLevel: 'low', lat: 30.90, lng: 75.85 },
]
