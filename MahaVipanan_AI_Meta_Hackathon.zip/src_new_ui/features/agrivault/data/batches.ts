/**
 * Ported verbatim from agrivault-ai `data/mockBatches.ts` (post-harvest
 * feature module). Data and types are unchanged; only the file location moved
 * under `@/features/agrivault`.
 */
export type StorageType = 'ambient' | 'cold'

export interface Batch {
  id: string
  crop: string
  quantityKg: number
  harvestDate: string
  temperatureC: number
  humidityPercent: number
  rainfallMm: number
  storageType: StorageType
  transportDelayDays: number
  storageDelayDays: number
  districtId: string
  pricePerKg: number
}

export const mockBatches: Batch[] = [
  {
    id: 'b1', crop: 'Tomato', quantityKg: 5200, harvestDate: '2026-08-15',
    temperatureC: 34, humidityPercent: 82, rainfallMm: 40,
    storageType: 'ambient', transportDelayDays: 2, storageDelayDays: 1,
    districtId: 'd1', pricePerKg: 18,
  },
  {
    id: 'b2', crop: 'Onion', quantityKg: 12000, harvestDate: '2026-08-10',
    temperatureC: 29, humidityPercent: 60, rainfallMm: 5,
    storageType: 'ambient', transportDelayDays: 1, storageDelayDays: 3,
    districtId: 'd2', pricePerKg: 22,
  },
  {
    id: 'b3', crop: 'Potato', quantityKg: 9000, harvestDate: '2026-08-05',
    temperatureC: 24, humidityPercent: 55, rainfallMm: 0,
    storageType: 'cold', transportDelayDays: 0, storageDelayDays: 0,
    districtId: 'd3', pricePerKg: 15,
  },
  {
    id: 'b4', crop: 'Wheat', quantityKg: 20000, harvestDate: '2026-07-28',
    temperatureC: 31, humidityPercent: 45, rainfallMm: 0,
    storageType: 'ambient', transportDelayDays: 3, storageDelayDays: 5,
    districtId: 'd4', pricePerKg: 24,
  },
  {
    id: 'b5', crop: 'Tomato', quantityKg: 3000, harvestDate: '2026-08-18',
    temperatureC: 37, humidityPercent: 88, rainfallMm: 65,
    storageType: 'ambient', transportDelayDays: 4, storageDelayDays: 2,
    districtId: 'd5', pricePerKg: 18,
  },
  {
    id: 'b6', crop: 'Onion', quantityKg: 7000, harvestDate: '2026-08-12',
    temperatureC: 33, humidityPercent: 78, rainfallMm: 55,
    storageType: 'ambient', transportDelayDays: 5, storageDelayDays: 4,
    districtId: 'd6', pricePerKg: 22,
  },
  {
    id: 'b7', crop: 'Potato', quantityKg: 6500, harvestDate: '2026-08-09',
    temperatureC: 27, humidityPercent: 65, rainfallMm: 20,
    storageType: 'cold', transportDelayDays: 1, storageDelayDays: 1,
    districtId: 'd7', pricePerKg: 15,
  },
  {
    id: 'b8', crop: 'Wheat', quantityKg: 15000, harvestDate: '2026-07-30',
    temperatureC: 22, humidityPercent: 40, rainfallMm: 0,
    storageType: 'cold', transportDelayDays: 0, storageDelayDays: 1,
    districtId: 'd8', pricePerKg: 24,
  },
]
