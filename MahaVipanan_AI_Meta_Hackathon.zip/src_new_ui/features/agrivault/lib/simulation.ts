import type { Batch } from '@/features/agrivault/data/batches'
import type { District, RiskLevel } from '@/features/agrivault/data/districts'

/**
 * Deterministic post-harvest decision engine — ported verbatim from
 * agrivault-ai `lib/simulation.ts`. The formulas are unchanged; this is the
 * "calculated by system" core (no model, fully reproducible).
 *
 * The only edits vs. the original are import paths and renaming two unused
 * `batch` params to `_batch` to satisfy this project's `noUnusedParameters`
 * — the numeric behaviour is identical.
 */
export interface Overrides {
  temperatureC?: number
  humidityPercent?: number
  rainfallMm?: number
  floodSeverity?: 'none' | 'low' | 'medium' | 'high'
  storageDelayDays?: number
  transportDelayDays?: number
}

const floodFactor: Record<string, number> = { none: 0, low: 5, medium: 15, high: 30 }

function eff<K extends keyof Overrides>(batch: any, overrides: Overrides | undefined, key: K, fallbackKey: string) {
  if (overrides && overrides[key] !== undefined) return overrides[key] as number
  return batch[fallbackKey]
}

export function calculateShelfLife(batch: Batch, overrides?: Overrides): number {
  const temp = eff(batch, overrides, 'temperatureC', 'temperatureC') as number
  const humidity = eff(batch, overrides, 'humidityPercent', 'humidityPercent') as number
  const rainfall = eff(batch, overrides, 'rainfallMm', 'rainfallMm') as number
  const storageDelay = eff(batch, overrides, 'storageDelayDays', 'storageDelayDays') as number
  const transportDelay = eff(batch, overrides, 'transportDelayDays', 'transportDelayDays') as number
  const flood = overrides?.floodSeverity ?? 'none'

  // Base shelf life by crop (days at ideal conditions)
  const baseByCrop: Record<string, number> = {
    Tomato: 12, Onion: 60, Potato: 90, Wheat: 180,
  }
  let shelfLife = baseByCrop[batch.crop] ?? 30

  // Cold storage extends shelf life significantly
  if (batch.storageType === 'cold') shelfLife *= 1.6

  // Temperature penalty (above 20C reference)
  const tempPenalty = Math.max(0, temp - 20) * 0.06
  shelfLife *= Math.max(0.15, 1 - tempPenalty)

  // Humidity penalty (above 50% reference)
  const humidityPenalty = Math.max(0, humidity - 50) * 0.005
  shelfLife *= Math.max(0.2, 1 - humidityPenalty)

  // Rainfall penalty
  const rainfallPenalty = Math.min(0.4, rainfall * 0.004)
  shelfLife *= 1 - rainfallPenalty

  // Flood severity penalty
  shelfLife *= 1 - floodFactor[flood] / 100

  // Delays consume shelf life directly
  shelfLife -= storageDelay * 0.6 + transportDelay * 0.8

  return Math.max(0.3, Math.round(shelfLife * 10) / 10)
}

export function calculateRiskScore(batch: Batch, overrides?: Overrides): number {
  const temp = eff(batch, overrides, 'temperatureC', 'temperatureC') as number
  const humidity = eff(batch, overrides, 'humidityPercent', 'humidityPercent') as number
  const rainfall = eff(batch, overrides, 'rainfallMm', 'rainfallMm') as number
  const storageDelay = eff(batch, overrides, 'storageDelayDays', 'storageDelayDays') as number
  const transportDelay = eff(batch, overrides, 'transportDelayDays', 'transportDelayDays') as number
  const flood = overrides?.floodSeverity ?? 'none'

  let score = 0
  score += Math.max(0, temp - 22) * 1.8
  score += Math.max(0, humidity - 50) * 0.7
  score += Math.min(30, rainfall * 0.4)
  score += storageDelay * 3.5
  score += transportDelay * 4
  score += floodFactor[flood] * 1.2

  if (batch.storageType === 'cold') score *= 0.55

  return Math.max(0, Math.min(100, Math.round(score)))
}

export function calculateExpectedLoss(batch: Batch, shelfLife: number, riskScore: number): number {
  const totalValue = batch.quantityKg * batch.pricePerKg
  // Loss fraction driven by risk score, capped at 85%
  const lossFraction = Math.min(0.85, riskScore / 100)
  // Extra loss if shelf life is critically low
  const shelfLifePenalty = shelfLife < 2 ? 0.15 : shelfLife < 5 ? 0.07 : 0
  const finalFraction = Math.min(0.9, lossFraction + shelfLifePenalty)
  return Math.round(totalValue * finalFraction)
}

export function calculateValueRecovered(_batch: Batch, baseLoss: number, optimizedLoss: number): number {
  return Math.max(0, Math.round(baseLoss - optimizedLoss))
}

export type Recommendation = 'SELL NOW' | 'STORE' | 'REROUTE' | 'PROCESS'

export function getRecommendation(_batch: Batch, riskScore: number, shelfLife: number): Recommendation {
  if (shelfLife < 2 || riskScore >= 75) return 'SELL NOW'
  if (riskScore >= 55) return 'PROCESS'
  if (riskScore >= 35) return 'REROUTE'
  return 'STORE'
}

export function getGeographicRiskLevel(district: District, overrides?: Overrides): RiskLevel {
  const base: Record<RiskLevel, number> = { low: 20, medium: 45, high: 70 }
  let score = base[district.baseRiskLevel]
  if (overrides?.floodSeverity) score += floodFactor[overrides.floodSeverity]
  if (overrides?.rainfallMm) score += Math.min(20, overrides.rainfallMm * 0.2)
  if (score >= 65) return 'high'
  if (score >= 35) return 'medium'
  return 'low'
}

export function riskLevelFromScore(score: number): RiskLevel {
  if (score >= 60) return 'high'
  if (score >= 30) return 'medium'
  return 'low'
}

export function fullSimulate(batch: Batch, district: District | undefined, overrides?: Overrides) {
  const shelfLife = calculateShelfLife(batch, overrides)
  const riskScore = calculateRiskScore(batch, overrides)
  const baseShelfLife = calculateShelfLife(batch)
  const baseRiskScore = calculateRiskScore(batch)
  const baseLoss = calculateExpectedLoss(batch, baseShelfLife, baseRiskScore)
  const expectedLoss = calculateExpectedLoss(batch, shelfLife, riskScore)
  const valueRecovered = calculateValueRecovered(batch, baseLoss, expectedLoss)
  const recommendation = getRecommendation(batch, riskScore, shelfLife)
  const geoRisk = district ? getGeographicRiskLevel(district, overrides) : 'medium'

  return {
    shelfLife,
    riskScore,
    expectedLoss,
    valueRecovered,
    recommendation,
    geoRisk,
    riskLevel: riskLevelFromScore(riskScore),
  }
}
