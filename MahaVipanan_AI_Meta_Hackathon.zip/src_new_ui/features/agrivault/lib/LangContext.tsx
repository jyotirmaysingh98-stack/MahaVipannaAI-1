import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { type Lang, t as translate } from '@/features/agrivault/lib/i18n'

/**
 * Language context for the post-harvest feature pages (EN / हिंदी).
 * Ported from agrivault-ai `lib/LangContext.tsx`, rewritten in this project's
 * style. The choice persists in localStorage under the original key so it is
 * remembered across sessions. Only the new feature pages consume this — the
 * existing MahaVipanan screens are unaffected.
 */
interface LangContextType {
  lang: Lang
  setLang: (l: Lang) => void
  t: (key: string) => string
}

const LangContext = createContext<LangContextType>({
  lang: 'en',
  setLang: () => {},
  t: (key: string) => key,
})

const LANG_KEY = 'agrivault_lang'

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      const stored = localStorage.getItem(LANG_KEY)
      return stored === 'en' || stored === 'hi' ? stored : 'en'
    } catch {
      return 'en'
    }
  })

  useEffect(() => {
    try {
      localStorage.setItem(LANG_KEY, lang)
    } catch {
      /* non-fatal */
    }
  }, [lang])

  const setLang = useCallback((l: Lang) => setLangState(l), [])
  const t = useCallback((key: string) => translate(key, lang), [lang])

  const value = useMemo<LangContextType>(() => ({ lang, setLang, t }), [lang, setLang, t])

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>
}

export function useLang() {
  return useContext(LangContext)
}
