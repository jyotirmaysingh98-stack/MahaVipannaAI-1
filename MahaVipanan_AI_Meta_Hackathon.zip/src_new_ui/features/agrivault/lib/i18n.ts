export type Lang = 'en' | 'hi'

/**
 * EN / हिंदी dictionary — ported from agrivault-ai `lib/i18n.ts` (all original
 * keys kept intact) plus a small set of extra keys for the pages rebuilt in the
 * MahaVipanan design language. Unknown keys fall back to the key itself.
 */
const dict: Record<string, { en: string; hi: string }> = {
  appName: { en: 'AgriVault AI', hi: 'एग्रीवॉल्ट एआई' },
  tagline: { en: 'Post-Harvest Decision Intelligence', hi: 'फसल-पश्चात निर्णय बुद्धिमत्ता' },
  farmer: { en: 'Farmer', hi: 'किसान' },
  fpo: { en: 'FPO', hi: 'एफपीओ' },
  govt: { en: 'Govt', hi: 'सरकार' },
  farmerDashboard: { en: 'Farmer Dashboard', hi: 'किसान डैशबोर्ड' },
  fpoDashboard: { en: 'FPO / Warehouse Dashboard', hi: 'एफपीओ / गोदाम डैशबोर्ड' },
  govtDashboard: { en: 'Government Dashboard', hi: 'सरकारी डैशबोर्ड' },
  crop: { en: 'Crop', hi: 'फसल' },
  quantity: { en: 'Quantity', hi: 'मात्रा' },
  harvestDate: { en: 'Harvest Date', hi: 'कटाई की तारीख' },
  temperature: { en: 'Temperature', hi: 'तापमान' },
  humidity: { en: 'Humidity', hi: 'आर्द्रता' },
  rainfall: { en: 'Rainfall', hi: 'वर्षा' },
  shelfLife: { en: 'Shelf Life', hi: 'शेल्फ लाइफ' },
  financialRisk: { en: 'Financial Risk', hi: 'वित्तीय जोखिम' },
  expectedLoss: { en: 'Expected Loss', hi: 'अनुमानित हानि' },
  recommendedAction: { en: 'Recommended Action', hi: 'अनुशंसित कार्रवाई' },
  whatIfSimulation: { en: 'What-If Simulation', hi: 'क्या-अगर सिमुलेशन' },
  map: { en: 'Map', hi: 'मानचित्र' },
  lossHeatmap: { en: 'Loss / Risk Heatmap', hi: 'हानि / जोखिम हीटमैप' },
  low: { en: 'Low', hi: 'कम' },
  medium: { en: 'Medium', hi: 'मध्यम' },
  high: { en: 'High', hi: 'उच्च' },
  sellNow: { en: 'SELL NOW', hi: 'अभी बेचें' },
  store: { en: 'STORE', hi: 'भंडारण करें' },
  reroute: { en: 'REROUTE', hi: 'मार्ग बदलें' },
  process: { en: 'PROCESS', hi: 'प्रसंस्करण करें' },
  totalBatches: { en: 'Total Batches', hi: 'कुल बैच' },
  totalValue: { en: 'Total Value Monitored', hi: 'कुल निगरानी मूल्य' },
  valueAtRisk: { en: 'Value at Risk', hi: 'जोखिम में मूल्य' },
  recoverableValue: { en: 'Recoverable Value', hi: 'पुनर्प्राप्त करने योग्य मूल्य' },
  criticalBatches: { en: 'Critical Batches', hi: 'गंभीर बैच' },
  openSimulation: { en: 'Open What-If Simulation', hi: 'सिमुलेशन खोलें' },
  runSimulation: { en: 'Run Simulation', hi: 'सिमुलेशन चलाएँ' },
  selectBatch: { en: 'Select Batch', hi: 'बैच चुनें' },
  floodSeverity: { en: 'Flood Severity', hi: 'बाढ़ की गंभीरता' },
  storageDelay: { en: 'Storage Delay (days)', hi: 'भंडारण विलंब (दिन)' },
  transportDelay: { en: 'Transport Delay (days)', hi: 'परिवहन विलंब (दिन)' },
  valueRecovered: { en: 'Value Recovered', hi: 'पुनर्प्राप्त मूल्य' },
  geoRisk: { en: 'Affected Geographic Risk', hi: 'प्रभावित भौगोलिक जोखिम' },
  riskScore: { en: 'Risk Score', hi: 'जोखिम स्कोर' },
  none: { en: 'None', hi: 'कोई नहीं' },
  district: { en: 'District', hi: 'जिला' },
  state: { en: 'State', hi: 'राज्य' },
  avgRisk: { en: 'Avg Risk', hi: 'औसत जोखिम' },
  home: { en: 'Home', hi: 'होम' },
  heroDesc: {
    en: 'A batch-level digital twin for Indian agriculture — track shelf life, financial risk, and recommended actions in real time.',
    hi: 'भारतीय कृषि के लिए एक बैच-स्तरीय डिजिटल ट्विन — शेल्फ लाइफ, वित्तीय जोखिम और अनुशंसित कार्रवाइयों को वास्तविक समय में ट्रैक करें।',
  },

  // ── Extra keys for the MahaVipanan-styled feature pages ──
  admin: { en: 'Admin', hi: 'एडमिन' },
  postHarvest: { en: 'Post-Harvest Intelligence', hi: 'फसल-पश्चात बुद्धिमत्ता' },
  coldStorage: { en: 'Cold Storage', hi: 'शीत भंडारण' },
  ambientStorage: { en: 'Ambient Storage', hi: 'सामान्य भंडारण' },
  overview: { en: 'Overview', hi: 'अवलोकन' },
  riskMap: { en: 'Risk Map', hi: 'जोखिम मानचित्र' },
  simulator: { en: 'Simulator', hi: 'सिमुलेटर' },
  allDashboards: { en: 'All Dashboards', hi: 'सभी डैशबोर्ड' },
  openDashboard: { en: 'Open', hi: 'खोलें' },
  myBatches: { en: 'My Batches', hi: 'मेरे बैच' },
  districtRisk: { en: 'District Risk Ledger', hi: 'जिला जोखिम बही' },
  farmerDesc: {
    en: 'Every batch you hold — live shelf life, financial risk, and the recommended action.',
    hi: 'आपके पास मौजूद हर बैच — सजीव शेल्फ लाइफ, वित्तीय जोखिम और अनुशंसित कार्रवाई।',
  },
  fpoDesc: {
    en: 'Cold and ambient storage across your pool, ranked by value at risk.',
    hi: 'आपके पूल में शीत और सामान्य भंडारण, जोखिम में मूल्य के अनुसार क्रमबद्ध।',
  },
  govtDesc: {
    en: 'District-level spoilage risk and value at risk across monitored regions.',
    hi: 'निगरानी क्षेत्रों में जिला-स्तरीय खराबी जोखिम और जोखिम में मूल्य।',
  },
  simDesc: {
    en: 'Adjust conditions and watch shelf life, risk, and expected loss recompute instantly.',
    hi: 'परिस्थितियाँ बदलें और शेल्फ लाइफ, जोखिम व अनुमानित हानि को तुरंत पुनर्गणित होते देखें।',
  },
  adminDesc: {
    en: 'Every dashboard in one place — open any role’s view.',
    hi: 'सभी डैशबोर्ड एक जगह — किसी भी भूमिका का दृश्य खोलें।',
  },
}

export function t(key: string, lang: Lang): string {
  return dict[key]?.[lang] ?? key
}
