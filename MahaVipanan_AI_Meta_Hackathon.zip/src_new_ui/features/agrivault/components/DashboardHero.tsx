import type { ReactNode } from 'react'
import { DemoDataBadge } from '@/components/brand/Provenance'
import { LanguageToggle } from './LanguageToggle'

/**
 * Immersive agriculture photography Unsplash sources, keyed by role/section.
 * All IDs are format-and-crop transformed at 2000px; reused across pages where
 * the mood matches. Kept in one place so the banners stay consistent.
 */
export const HERO_IMAGES = {
  farmer:
    'https://images.unsplash.com/photo-1523741543316-beb7fc7023d8?auto=format&fit=crop&w=2000&q=80',
  commandCentre:
    'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=2000&q=80',
  warehouse:
    'https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&w=2000&q=80',
  gov:
    'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=2000&q=80',
  admin:
    'https://images.unsplash.com/photo-1560493676-04071c5f467b?auto=format&fit=crop&w=2000&q=80',
  simulator:
    'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=2000&q=80',
  market:
    'https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=2000&q=80',
} as const

/**
 * Premium photographic banner that opens every authenticated dashboard.
 * Deep-forest base + full-bleed crop photography under the same scrim language
 * as the public landing/login, with a lime eyebrow and white display title.
 * The data content below stays on the light surface for legibility.
 */
export function DashboardHero({
  image,
  eyebrow,
  title,
  description,
  actions,
  langToggle = true,
}: {
  image: string
  eyebrow?: string
  title: ReactNode
  description?: ReactNode
  actions?: ReactNode
  langToggle?: boolean
}) {
  return (
    <div className="relative mb-8 overflow-hidden rounded-3xl bg-forest-950 shadow-card-lg">
      <img
        src={image}
        alt=""
        className="absolute inset-0 h-full w-full origin-center animate-slow-zoom object-cover"
      />
      <div className="absolute inset-0 bg-banner-scrim" />
      <div className="relative flex flex-col gap-6 p-7 sm:p-9 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-2xl">
          {eyebrow && (
            <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-lime-300">
              {eyebrow}
            </p>
          )}
          <h1 className="mt-2 font-display text-display-md font-bold leading-tight text-white text-shadow-hero">
            {title}
          </h1>
          {description && (
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/80 sm:text-[0.95rem]">
              {description}
            </p>
          )}
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-2.5">
          {actions}
          <DemoDataBadge className="hidden sm:inline-flex" />
          {langToggle && <LanguageToggle />}
        </div>
      </div>
    </div>
  )
}

/** Consistent premium section heading — a small lime tick + display title. */
export function SectionHeading({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-4 flex items-center justify-between gap-3">
      <div className="flex items-center gap-2.5">
        <span className="h-5 w-1 rounded-full bg-lime-500" />
        <h2 className="font-display text-lg font-semibold text-ink">{children}</h2>
      </div>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  )
}
