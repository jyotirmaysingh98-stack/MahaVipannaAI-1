import type { ReactNode } from 'react'
import { PageHeader } from '@/components/layout/PageHeader'
import { DemoDataBadge } from '@/components/brand/Provenance'
import { LanguageToggle } from './LanguageToggle'

/**
 * Shared header for the post-harvest feature pages — the project's PageHeader
 * with the demo-data badge and the EN/हिंदी toggle wired into its actions slot.
 * The language toggle lives only here, so the existing MahaVipanan pages that
 * use PageHeader directly are untouched.
 */
export function FeatureHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string
  title: ReactNode
  description?: ReactNode
  actions?: ReactNode
}) {
  return (
    <PageHeader
      eyebrow={eyebrow}
      title={title}
      description={description}
      actions={
        <>
          {actions}
          <DemoDataBadge className="hidden sm:inline-flex" />
          <LanguageToggle />
        </>
      }
    />
  )
}
