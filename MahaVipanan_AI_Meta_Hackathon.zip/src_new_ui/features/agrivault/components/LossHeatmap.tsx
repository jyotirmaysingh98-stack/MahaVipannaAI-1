import { Card } from '@/components/ui/Card'
import { inrCompact } from '@/lib/format'
import { mockBatches } from '@/features/agrivault/data/batches'
import { mockDistricts, type RiskLevel } from '@/features/agrivault/data/districts'
import { fullSimulate } from '@/features/agrivault/lib/simulation'
import { useLang } from '@/features/agrivault/lib/LangContext'

const CELL: Record<RiskLevel, string> = {
  low: 'bg-pine-500',
  medium: 'bg-amber-500',
  high: 'bg-clay-500',
}

/** District loss/risk heatmap — one cell per district, total expected loss. */
export function LossHeatmap() {
  const { t } = useLang()

  return (
    <Card className="p-5">
      <h3 className="mb-3 font-display text-base font-semibold text-ink">{t('lossHeatmap')}</h3>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {mockDistricts.map((d) => {
          const totalLoss = mockBatches
            .filter((b) => b.districtId === d.id)
            .reduce((sum, b) => sum + fullSimulate(b, d).expectedLoss, 0)
          return (
            <div
              key={d.id}
              className={`flex flex-col justify-between gap-1 rounded-xl p-3 text-white shadow-card ${CELL[d.baseRiskLevel]}`}
            >
              <span className="text-sm font-semibold">{d.name}</span>
              <span className="tnum text-xs font-medium text-white/90">{inrCompact(totalLoss)}</span>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
