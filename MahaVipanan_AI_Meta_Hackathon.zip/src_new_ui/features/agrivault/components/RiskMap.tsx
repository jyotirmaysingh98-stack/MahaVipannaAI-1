import { Card } from '@/components/ui/Card'
import { mockDistricts, type RiskLevel } from '@/features/agrivault/data/districts'
import { useLang } from '@/features/agrivault/lib/LangContext'

const DOT: Record<RiskLevel, string> = {
  low: 'bg-pine-500',
  medium: 'bg-amber-500',
  high: 'bg-clay-500',
}

/**
 * Stylised district scatter — lat/lng normalised into a 0–100 box. Rebuilt on
 * MahaVipanan surfaces; dot colours follow the risk palette.
 */
export function RiskMap() {
  const { t } = useLang()
  const lats = mockDistricts.map((d) => d.lat)
  const lngs = mockDistricts.map((d) => d.lng)
  const minLat = Math.min(...lats)
  const maxLat = Math.max(...lats)
  const minLng = Math.min(...lngs)
  const maxLng = Math.max(...lngs)

  return (
    <Card className="p-5">
      <h3 className="mb-3 font-display text-base font-semibold text-ink">{t('map')}</h3>
      <div className="relative rounded-xl border border-line bg-surface-sunk" style={{ height: 260 }}>
        {mockDistricts.map((d) => {
          const x = ((d.lng - minLng) / (maxLng - minLng || 1)) * 85 + 5
          const y = (1 - (d.lat - minLat) / (maxLat - minLat || 1)) * 85 + 5
          return (
            <div
              key={d.id}
              className="absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center"
              style={{ left: `${x}%`, top: `${y}%` }}
              title={d.name}
            >
              <span className={`h-3.5 w-3.5 rounded-full shadow-card ring-2 ring-surface ${DOT[d.baseRiskLevel]}`} />
              <span className="mt-1 whitespace-nowrap rounded bg-surface/80 px-1 text-[10px] font-medium text-ink-2">
                {d.name}
              </span>
            </div>
          )
        })}
      </div>
      <div className="mt-3 flex flex-wrap gap-4 text-xs text-ink-2">
        <Legend cls="bg-pine-500" label={t('low')} />
        <Legend cls="bg-amber-500" label={t('medium')} />
        <Legend cls="bg-clay-500" label={t('high')} />
      </div>
    </Card>
  )
}

function Legend({ cls, label }: { cls: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={`inline-block h-2.5 w-2.5 rounded-full ${cls}`} />
      {label}
    </span>
  )
}
