import { AlertTriangle, IndianRupee, Layers, ShieldCheck, TrendingDown } from 'lucide-react'
import { KpiCard } from '@/components/dashboard/KpiCard'
import { inrCompact } from '@/lib/format'
import type { Batch } from '@/features/agrivault/data/batches'
import { mockDistricts } from '@/features/agrivault/data/districts'
import { fullSimulate } from '@/features/agrivault/lib/simulation'
import { useLang } from '@/features/agrivault/lib/LangContext'

/**
 * KPI strip aggregating the post-harvest engine across a set of batches.
 * Same figures as agrivault's DashboardStats, rendered with MahaVipanan's
 * KpiCard tiles.
 */
export function BatchStats({ batches }: { batches: Batch[] }) {
  const { t } = useLang()

  let totalValue = 0
  let valueAtRisk = 0
  let recoverable = 0
  let critical = 0

  batches.forEach((b) => {
    const district = mockDistricts.find((d) => d.id === b.districtId)
    const result = fullSimulate(b, district)
    totalValue += b.quantityKg * b.pricePerKg
    valueAtRisk += result.expectedLoss
    recoverable += Math.round(result.expectedLoss * 0.4)
    if (result.riskLevel === 'high') critical += 1
  })

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">
      <KpiCard label={t('totalBatches')} value={batches.length} icon={Layers} accent="pine" />
      <KpiCard label={t('totalValue')} value={inrCompact(totalValue)} icon={IndianRupee} accent="teal" />
      <KpiCard label={t('valueAtRisk')} value={inrCompact(valueAtRisk)} icon={TrendingDown} accent="clay" />
      <KpiCard label={t('recoverableValue')} value={inrCompact(recoverable)} icon={ShieldCheck} accent="pine" />
      <KpiCard label={t('criticalBatches')} value={critical} icon={AlertTriangle} accent="amber" />
    </div>
  )
}
