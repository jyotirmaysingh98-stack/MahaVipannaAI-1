import { Snowflake, Thermometer } from 'lucide-react'
import type { Batch } from '@/features/agrivault/data/batches'
import { mockDistricts } from '@/features/agrivault/data/districts'
import { fullSimulate, type Recommendation } from '@/features/agrivault/lib/simulation'
import { useLang } from '@/features/agrivault/lib/LangContext'
import { Card } from '@/components/ui/Card'
import { inr, num } from '@/lib/format'
import { RiskBadge } from './RiskBadge'

const ACTION_KEY: Record<Recommendation, string> = {
  'SELL NOW': 'sellNow',
  STORE: 'store',
  REROUTE: 'reroute',
  PROCESS: 'process',
}

/** Recommended-action pill colours (design-system semantics). */
const ACTION_CLASS: Record<Recommendation, string> = {
  'SELL NOW': 'bg-clay-500 text-white',
  STORE: 'bg-pine-500 text-white',
  REROUTE: 'bg-teal-500 text-white',
  PROCESS: 'bg-amber-500 text-white',
}

export function BatchCard({ batch }: { batch: Batch }) {
  const { t } = useLang()
  const district = mockDistricts.find((d) => d.id === batch.districtId)
  const result = fullSimulate(batch, district)

  return (
    <Card interactive className="flex flex-col gap-3 p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-lg font-bold text-ink">{batch.crop}</h3>
            <span className="inline-flex items-center gap-1 rounded-md bg-surface-sunk px-1.5 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wide text-ink-2 ring-1 ring-inset ring-line">
              {batch.storageType === 'cold' ? <Snowflake size={10} /> : <Thermometer size={10} />}
              {batch.storageType}
            </span>
          </div>
          <p className="mt-0.5 text-xs text-ink-3">{district ? `${district.name}, ${district.state}` : '—'}</p>
        </div>
        <RiskBadge level={result.riskLevel} label={t(result.riskLevel)} />
      </div>

      <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
        <Stat label={t('quantity')} value={`${num(batch.quantityKg)} kg`} />
        <Stat label={t('harvestDate')} value={batch.harvestDate} />
        <Stat label={t('temperature')} value={`${batch.temperatureC}°C`} />
        <Stat label={t('humidity')} value={`${batch.humidityPercent}%`} />
        <Stat label={t('rainfall')} value={`${batch.rainfallMm} mm`} />
        <Stat label={t('shelfLife')} value={`${result.shelfLife} d`} />
      </dl>

      <div className="mt-auto flex items-end justify-between border-t border-line pt-3">
        <div>
          <p className="text-xs text-ink-3">{t('expectedLoss')}</p>
          <p className="tnum font-display text-lg font-bold text-clay-600">{inr(result.expectedLoss)}</p>
        </div>
        <div className="text-right">
          <p className="mb-1 text-xs text-ink-3">{t('recommendedAction')}</p>
          <span className={`inline-block rounded-lg px-3 py-1 text-xs font-bold shadow-sm ${ACTION_CLASS[result.recommendation]}`}>
            {t(ACTION_KEY[result.recommendation])}
          </span>
        </div>
      </div>
    </Card>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col">
      <dt className="text-ink-3">{label}</dt>
      <dd className="font-medium text-ink">{value}</dd>
    </div>
  )
}
