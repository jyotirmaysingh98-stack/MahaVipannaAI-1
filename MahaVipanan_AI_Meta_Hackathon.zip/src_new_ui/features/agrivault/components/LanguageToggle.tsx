import { SegmentedControl } from '@/components/ui/SegmentedControl'
import { useLang } from '@/features/agrivault/lib/LangContext'
import type { Lang } from '@/features/agrivault/lib/i18n'

/** EN / हिंदी toggle, built from the native SegmentedControl. */
export function LanguageToggle() {
  const { lang, setLang } = useLang()
  return (
    <SegmentedControl<Lang>
      size="sm"
      aria-label="Language"
      value={lang}
      onChange={setLang}
      options={[
        { value: 'en', label: 'EN' },
        { value: 'hi', label: 'हिं' },
      ]}
    />
  )
}
