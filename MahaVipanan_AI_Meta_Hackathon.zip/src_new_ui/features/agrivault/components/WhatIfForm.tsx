import { useMemo, useState } from 'react'
import { type Batch, mockBatches } from '@/features/agrivault/data/batches'
import { mockDistricts } from '@/features/agrivault/data/districts'
import { fullSimulate, type Overrides, type Recommendation } from '@/features/agrivault/lib/simulation'
import { useLang } from '@/features/agrivault/lib/LangContext'
import { Card } from '@/components/ui/Card'
import { Select } from '@/components/ui/Field'
import { inr, num } from '@/lib/format'
import { RiskBadge } from './RiskBadge'

type Flood = 'none' | 'low' | 'medium' | 'high'

const ACTION_KEY: Record<Recommendation, string> = {
  'SELL NOW': 'sellNow',
  STORE: 'store',
  REROUTE: 'reroute',
  PROCESS: 'process',
}

/**
 * What-If simulator. Ported from agrivault's WhatIfForm, rebuilt with native
 * inputs. Results recompute live as the sliders move (no "run" button).
 */
export function WhatIfForm() {
  const { t } = useLang()
  const [batchId, setBatchId] = useState(mockBatches[0].id)
  const batch = mockBatches.find((b) => b.id === batchId) as Batch
  const district = mockDistricts.find((d) => d.id === batch.districtId)

  const [temperatureC, setTemperatureC] = useState(batch.temperatureC)
  const [humidityPercent, setHumidityPercent] = useState(batch.humidityPercent)
  const [rainfallMm, setRainfallMm] = useState(batch.rainfallMm)
  const [floodSeverity, setFloodSeverity] = useState<Flood>('none')
  const [storageDelayDays, setStorageDelayDays] = useState(batch.storageDelayDays)
  const [transportDelayDays, setTransportDelayDays] = useState(batch.transportDelayDays)

  function handleBatchChange(id: string) {
    const b = mockBatches.find((x) => x.id === id) as Batch
    setBatchId(id)
    setTemperatureC(b.temperatureC)
    setHumidityPercent(b.humidityPercent)
    setRainfallMm(b.rainfallMm)
    setStorageDelayDays(b.storageDelayDays)
    setTransportDelayDays(b.transportDelayDays)
    setFloodSeverity('none')
  }

  const result = useMemo(() => {
    const overrides: Overrides = {
      temperatureC,
      humidityPercent,
      rainfallMm,
      floodSeverity,
      storageDelayDays,
      transportDelayDays,
    }
    return fullSimulate(batch, district, overrides)
  }, [batch, district, temperatureC, humidityPercent, rainfallMm, floodSeverity, storageDelayDays, transportDelayDays])

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="space-y-5 p-5">
        <Select
          label={t('selectBatch')}
          value={batchId}
          onChange={(e) => handleBatchChange(e.target.value)}
        >
          {mockBatches.map((b) => {
            const d = mockDistricts.find((x) => x.id === b.districtId)
            return (
              <option key={b.id} value={b.id}>
                {b.crop} — {num(b.quantityKg)} kg{d ? ` (${d.name})` : ''}
              </option>
            )
          })}
        </Select>

        <Slider label={`${t('temperature')} (°C)`} value={temperatureC} min={10} max={45} onChange={setTemperatureC} />
        <Slider label={`${t('humidity')} (%)`} value={humidityPercent} min={20} max={100} onChange={setHumidityPercent} />
        <Slider label={`${t('rainfall')} (mm)`} value={rainfallMm} min={0} max={150} onChange={setRainfallMm} />

        <Select
          label={t('floodSeverity')}
          value={floodSeverity}
          onChange={(e) => setFloodSeverity(e.target.value as Flood)}
        >
          <option value="none">{t('none')}</option>
          <option value="low">{t('low')}</option>
          <option value="medium">{t('medium')}</option>
          <option value="high">{t('high')}</option>
        </Select>

        <Slider label={t('storageDelay')} value={storageDelayDays} min={0} max={15} onChange={setStorageDelayDays} />
        <Slider label={t('transportDelay')} value={transportDelayDays} min={0} max={15} onChange={setTransportDelayDays} />
      </Card>

      <Card className="p-5">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-bold text-ink">{batch.crop}</h3>
            <RiskBadge level={result.riskLevel} label={t(result.riskLevel)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <ResultStat label={t('shelfLife')} value={`${result.shelfLife} d`} />
            <ResultStat label={t('riskScore')} value={`${result.riskScore} / 100`} />
            <ResultStat label={t('expectedLoss')} value={inr(result.expectedLoss)} tone="clay" />
            <ResultStat label={t('valueRecovered')} value={inr(result.valueRecovered)} tone="pine" />
          </div>
          <div className="flex items-end justify-between border-t border-line pt-4">
            <div>
              <p className="mb-1 text-xs text-ink-3">{t('geoRisk')}</p>
              <RiskBadge level={result.geoRisk} label={t(result.geoRisk)} />
            </div>
            <div className="text-right">
              <p className="text-xs text-ink-3">{t('recommendedAction')}</p>
              <p className="font-display text-lg font-bold text-pine-700">{t(ACTION_KEY[result.recommendation])}</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}

function Slider({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  onChange: (v: number) => void
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <label className="font-medium text-ink-2">{label}</label>
        <span className="tnum font-semibold text-pine-600">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-pine-500"
      />
    </div>
  )
}

function ResultStat({ label, value, tone }: { label: string; value: string; tone?: 'clay' | 'pine' }) {
  const color = tone === 'clay' ? 'text-clay-600' : tone === 'pine' ? 'text-pine-600' : 'text-ink'
  return (
    <div>
      <p className="text-xs text-ink-3">{label}</p>
      <p className={`tnum font-display text-xl font-bold ${color}`}>{value}</p>
    </div>
  )
}
