import { Badge } from '@/components/ui/Badge'
import type { RiskLevel } from '@/features/agrivault/data/districts'

/**
 * Risk pill rebuilt on MahaVipanan's Badge. Colour mapping follows the design
 * system's semantics: low → pine (best), medium → amber, high → clay (erosion).
 */
const TONE: Record<RiskLevel, 'pine' | 'amber' | 'clay'> = {
  low: 'pine',
  medium: 'amber',
  high: 'clay',
}

export function RiskBadge({ level, label }: { level: RiskLevel; label: string }) {
  return <Badge tone={TONE[level]}>{label}</Badge>
}
