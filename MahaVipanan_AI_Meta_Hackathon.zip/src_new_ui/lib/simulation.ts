import { Batch, CropProfile } from "./mockData";

export interface SimInputs {
  temperatureC: number;
  humidityPct: number;
  rainfallMm: number;
  floodSeverity: number; // 0-10
  storageDelayDays: number;
  transportDelayDays: number;
}

export type Recommendation = "SELL_NOW" | "STORE" | "REROUTE" | "PROCESS";
export type RiskLevel = "Low" | "Medium" | "High" | "Critical";

export interface SimResult {
  estimatedShelfLifeDays: number;
  riskScore: number; // 0-100
  expectedLossInr: number;
  totalValueInr: number;
  valueRecoveredInr: number;
  recommendation: Recommendation;
  riskLevel: RiskLevel;
  lossFraction: number;
  breakdown: {
    tempStress: number;
    humidityStress: number;
    rainfallStress: number;
    floodStress: number;
    delayStress: number;
  };
}

export function batchToInputs(b: Batch): SimInputs {
  return {
    temperatureC: b.temperatureC,
    humidityPct: b.humidityPct,
    rainfallMm: b.rainfallMm,
    floodSeverity: b.floodSeverity,
    storageDelayDays: b.storageDelayDays,
    transportDelayDays: b.transportDelayDays,
  };
}

export function runSimulation(
  crop: CropProfile,
  quantityKg: number,
  inputs: SimInputs
): SimResult {
  const {
    temperatureC,
    humidityPct,
    rainfallMm,
    floodSeverity,
    storageDelayDays,
    transportDelayDays,
  } = inputs;

  const tempDelta = Math.max(0, temperatureC - crop.idealTempC);
  const humidityDelta = Math.max(0, humidityPct - crop.idealHumidityPct);

  const tempStress = tempDelta * crop.perishability * 0.06;
  const humidityStress = humidityDelta * crop.perishability * 0.025;
  const rainfallStress = Math.min(rainfallMm / 50, 1) * 0.15 * (0.4 + crop.perishability);
  const floodStress = (floodSeverity / 10) * 0.9 * (0.5 + crop.perishability);
  const delayStress =
    (storageDelayDays * 0.03 + transportDelayDays * 0.045) * (0.5 + crop.perishability);

  const totalStress =
    tempStress + humidityStress + rainfallStress + floodStress + delayStress;

  const shelfLifeMultiplier = Math.max(0.04, 1 - totalStress * 0.55);
  const estimatedShelfLifeDays = Math.max(
    0,
    Math.round(crop.baseShelfLifeDays * shelfLifeMultiplier)
  );

  const riskScoreRaw = totalStress * 55;
  const riskScore = Math.min(100, Math.max(0, Math.round(riskScoreRaw)));

  const lossFraction = Math.min(0.95, Math.max(0, (riskScore / 100) * (0.4 + crop.perishability * 0.7)));

  const totalValueInr = quantityKg * crop.pricePerKg;
  const expectedLossInr = Math.round(totalValueInr * lossFraction);
  const valueRecoveredInr = totalValueInr - expectedLossInr;

  let riskLevel: RiskLevel = "Low";
  if (riskScore >= 75) riskLevel = "Critical";
  else if (riskScore >= 50) riskLevel = "High";
  else if (riskScore >= 25) riskLevel = "Medium";

  let recommendation: Recommendation;
  if (estimatedShelfLifeDays <= 2 || riskScore >= 80) {
    recommendation = "SELL_NOW";
  } else if (floodSeverity >= 6 || transportDelayDays >= 4) {
    recommendation = "REROUTE";
  } else if (riskScore >= 45 && crop.perishability >= 0.35) {
    recommendation = "PROCESS";
  } else if (riskScore >= 45) {
    recommendation = "SELL_NOW";
  } else {
    recommendation = "STORE";
  }

  return {
    estimatedShelfLifeDays,
    riskScore,
    expectedLossInr,
    totalValueInr,
    valueRecoveredInr,
    recommendation,
    riskLevel,
    lossFraction,
    breakdown: { tempStress, humidityStress, rainfallStress, floodStress, delayStress },
  };
}

export function formatInr(n: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);
}

export function recommendationLabel(r: Recommendation, hi: boolean): string {
  const map: Record<Recommendation, [string, string]> = {
    SELL_NOW: ["SELL NOW", "अभी बेचें"],
    STORE: ["STORE", "भंडारण करें"],
    REROUTE: ["REROUTE", "मार्ग बदलें"],
    PROCESS: ["PROCESS", "प्रसंस्करण करें"],
  };
  return hi ? map[r][1] : map[r][0];
}

export function riskLevelColor(level: RiskLevel): string {
  switch (level) {
    case "Low":
      return "risk-low";
    case "Medium":
      return "risk-medium";
    case "High":
      return "risk-high";
    case "Critical":
      return "risk-critical";
  }
}
