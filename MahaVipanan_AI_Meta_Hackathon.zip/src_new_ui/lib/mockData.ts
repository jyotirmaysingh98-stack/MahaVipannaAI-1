export type CropKey =
  | "wheat"
  | "rice"
  | "tomato"
  | "onion"
  | "potato"
  | "maize";

export interface CropProfile {
  key: CropKey;
  nameEn: string;
  nameHi: string;
  baseShelfLifeDays: number;
  idealTempC: number;
  idealHumidityPct: number;
  perishability: number; // 0 (hardy) - 1 (very perishable)
  pricePerKg: number; // INR, mandi average
}

export const CROPS: Record<CropKey, CropProfile> = {
  wheat: {
    key: "wheat",
    nameEn: "Wheat",
    nameHi: "गेहूं",
    baseShelfLifeDays: 270,
    idealTempC: 20,
    idealHumidityPct: 55,
    perishability: 0.12,
    pricePerKg: 24,
  },
  rice: {
    key: "rice",
    nameEn: "Rice (Paddy)",
    nameHi: "धान (चावल)",
    baseShelfLifeDays: 200,
    idealTempC: 22,
    idealHumidityPct: 60,
    perishability: 0.18,
    pricePerKg: 21,
  },
  tomato: {
    key: "tomato",
    nameEn: "Tomato",
    nameHi: "टमाटर",
    baseShelfLifeDays: 10,
    idealTempC: 13,
    idealHumidityPct: 85,
    perishability: 0.92,
    pricePerKg: 18,
  },
  onion: {
    key: "onion",
    nameEn: "Onion",
    nameHi: "प्याज",
    baseShelfLifeDays: 90,
    idealTempC: 15,
    idealHumidityPct: 65,
    perishability: 0.45,
    pricePerKg: 22,
  },
  potato: {
    key: "potato",
    nameEn: "Potato",
    nameHi: "आलू",
    baseShelfLifeDays: 120,
    idealTempC: 10,
    idealHumidityPct: 80,
    perishability: 0.4,
    pricePerKg: 16,
  },
  maize: {
    key: "maize",
    nameEn: "Maize",
    nameHi: "मक्का",
    baseShelfLifeDays: 240,
    idealTempC: 21,
    idealHumidityPct: 55,
    perishability: 0.15,
    pricePerKg: 19,
  },
};

export interface Batch {
  id: string;
  farmerName: string;
  farmerNameHi: string;
  crop: CropKey;
  quantityKg: number;
  harvestDate: string; // ISO
  district: string;
  districtHi: string;
  state: string;
  stateHi: string;
  lat: number;
  lng: number;
  temperatureC: number;
  humidityPct: number;
  rainfallMm: number;
  floodSeverity: number; // 0-10
  storageDelayDays: number;
  transportDelayDays: number;
}

export const BATCHES: Batch[] = [
  {
    id: "AV-1001",
    farmerName: "Ramesh Yadav",
    farmerNameHi: "रमेश यादव",
    crop: "tomato",
    quantityKg: 4200,
    harvestDate: "2026-08-19",
    district: "Nashik",
    districtHi: "नासिक",
    state: "Maharashtra",
    stateHi: "महाराष्ट्र",
    lat: 20.0,
    lng: 73.79,
    temperatureC: 32,
    humidityPct: 78,
    rainfallMm: 62,
    floodSeverity: 3,
    storageDelayDays: 2,
    transportDelayDays: 1,
  },
  {
    id: "AV-1002",
    farmerName: "Suresh Patel",
    farmerNameHi: "सुरेश पटेल",
    crop: "onion",
    quantityKg: 8600,
    harvestDate: "2026-08-10",
    district: "Lasalgaon",
    districtHi: "लासलगांव",
    state: "Maharashtra",
    stateHi: "महाराष्ट्र",
    lat: 20.15,
    lng: 74.24,
    temperatureC: 29,
    humidityPct: 60,
    rainfallMm: 12,
    floodSeverity: 0,
    storageDelayDays: 5,
    transportDelayDays: 2,
  },
  {
    id: "AV-1003",
    farmerName: "Harpreet Singh",
    farmerNameHi: "हरप्रीत सिंह",
    crop: "wheat",
    quantityKg: 15000,
    harvestDate: "2026-04-28",
    district: "Ludhiana",
    districtHi: "लुधियाना",
    state: "Punjab",
    stateHi: "पंजाब",
    lat: 30.9,
    lng: 75.85,
    temperatureC: 24,
    humidityPct: 45,
    rainfallMm: 2,
    floodSeverity: 0,
    storageDelayDays: 1,
    transportDelayDays: 0,
  },
  {
    id: "AV-1004",
    farmerName: "Anita Devi",
    farmerNameHi: "अनीता देवी",
    crop: "potato",
    quantityKg: 6100,
    harvestDate: "2026-08-15",
    district: "Hooghly",
    districtHi: "हुगली",
    state: "West Bengal",
    stateHi: "पश्चिम बंगाल",
    lat: 22.9,
    lng: 88.39,
    temperatureC: 34,
    humidityPct: 88,
    rainfallMm: 140,
    floodSeverity: 7,
    storageDelayDays: 3,
    transportDelayDays: 4,
  },
  {
    id: "AV-1005",
    farmerName: "Muthu Kumar",
    farmerNameHi: "முத்து குமார்",
    crop: "rice",
    quantityKg: 12000,
    harvestDate: "2026-08-05",
    district: "Thanjavur",
    districtHi: "தஞ்சாவூர்",
    state: "Tamil Nadu",
    stateHi: "तमिलनाडु",
    lat: 10.79,
    lng: 79.14,
    temperatureC: 31,
    humidityPct: 72,
    rainfallMm: 95,
    floodSeverity: 4,
    storageDelayDays: 2,
    transportDelayDays: 2,
  },
  {
    id: "AV-1006",
    farmerName: "Devendra Sharma",
    farmerNameHi: "देवेन्द्र शर्मा",
    crop: "maize",
    quantityKg: 9000,
    harvestDate: "2026-08-01",
    district: "Davangere",
    districtHi: "दावणगेरे",
    state: "Karnataka",
    stateHi: "कर्नाटक",
    lat: 14.46,
    lng: 75.92,
    temperatureC: 27,
    humidityPct: 58,
    rainfallMm: 30,
    floodSeverity: 1,
    storageDelayDays: 0,
    transportDelayDays: 1,
  },
];

export const DISTRICT_RISK_SEED = BATCHES.map((b, i) => ({
  district: b.district,
  districtHi: b.districtHi,
  state: b.state,
  seedOffset: (i * 13) % 37,
}));
