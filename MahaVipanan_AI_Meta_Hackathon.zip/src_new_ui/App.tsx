import { createBrowserRouter, Navigate } from 'react-router-dom'
import { LandingPage } from './pages/Landing'
import { LoginPage } from './pages/Login'
import { SignupPage } from './pages/Signup'
import { DashboardPage } from './pages/Dashboard'
import { OpportunitiesPage } from './pages/Opportunities'
import { OrdersPage } from './pages/Orders'
import { Tracking } from './pages/Tracking'
import { AppShell } from './components/layout/AppShell'
import { NotFoundPage } from './pages/NotFound'
import { useApp } from './state/AppContext'
import { Skeleton } from './components/ui/Skeleton'
import { GovtDashboard } from './pages/GovtDashboard'
import { SchemesPage } from './pages/Schemes'

import { FarmerDashboard } from './pages/FarmerDashboard'
import { BuyerDashboard } from './pages/BuyerDashboard'
import { DeliveryDashboard } from './pages/DeliveryDashboard'
import { AdminPage } from './pages/Admin'
import { AnalyticsPage } from './pages/Analytics'
import { HistoryPage } from './pages/History'
import { WarehousePage } from './pages/Warehouse'
import { FeedbackPage } from './pages/FeedbackPage'
import { Simulator } from './pages/SimulatorPage'
import { FPOLots } from './pages/FPOLots'
import { FarmerLots } from './pages/FarmerLots'
import { FarmerNegotiations } from './pages/FarmerNegotiations'
import { MarketRatesPage } from './pages/MarketPrices'
import { LangProvider } from './features/agrivault/lib/LangContext'

function Protected({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, fpoLoading } = useApp()
  if (fpoLoading) return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="space-y-3 w-64">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
    </div>
  )
  if (!isAuthenticated) return <Navigate to="/login" replace />
  return <>{children}</>
}

function RoleRedirect() {
  const { role } = useApp()
  if (!role) return <Navigate to="/login" replace />
  if (role === 'farmer') return <Navigate to={`/app/farmer`} replace />
  if (role === 'buyer') return <Navigate to={`/app/buyer`} replace />
  if (role === 'government') return <Navigate to={`/app/government`} replace />
  if (role === 'delivery') return <Navigate to={`/app/delivery`} replace />
  if (role === 'admin') return <Navigate to={`/app/admin`} replace />
  return <Navigate to={`/app/fpo`} replace />
}

export const router = createBrowserRouter([
  { path: '/', element: <LandingPage /> },
  { path: '/login', element: <LoginPage /> },
  { path: '/signup', element: <SignupPage /> },
  
  // Top-level role aliases for direct access
  { path: '/farmer', element: <Navigate to="/app/farmer" replace /> },
  { path: '/buyer', element: <Navigate to="/app/buyer" replace /> },
  { path: '/fpo', element: <Navigate to="/app/fpo" replace /> },
  { path: '/delivery', element: <Navigate to="/app/delivery" replace /> },
  { path: '/government', element: <Navigate to="/app/government" replace /> },
  { path: '/admin', element: <Navigate to="/app/admin" replace /> },
  { path: '/tracking', element: <Navigate to="/app/tracking" replace /> },
  { path: '/feedback', element: <Navigate to="/app/feedback" replace /> },

  {
    path: '/app',
    element: <Protected><AppShell /></Protected>,
    errorElement: <NotFoundPage />,
    children: [
      { index: true, element: <RoleRedirect /> },
      
      // FPO Routes
      { path: 'fpo', element: <DashboardPage /> },
      { path: 'fpo/lots', element: <FPOLots /> },
      { path: 'fpo/lots/:lotId', element: <OpportunitiesPage /> },
      { path: 'fpo/orders', element: <OrdersPage /> },
      { path: 'fpo/negotiations', element: <FarmerNegotiations /> },
      
      // Farmer Routes
      { path: 'farmer', element: <FarmerDashboard /> },
      { path: 'farmer/lots', element: <FarmerLots /> },
      { path: 'farmer/orders', element: <OrdersPage /> },
      { path: 'farmer/negotiations', element: <FarmerNegotiations /> },
      
      // Buyer Routes
      { path: 'buyer', element: <BuyerDashboard /> },
      { path: 'buyer/negotiations', element: <FarmerNegotiations /> },
      
      // Delivery Fleet Routes
      { path: 'delivery', element: <DeliveryDashboard /> },

      // Government Routes
      { path: 'government', element: <GovtDashboard /> },
      { path: 'government/schemes', element: <SchemesPage /> },

      // Admin Routes
      { path: 'admin', element: <AdminPage /> },

      // Feature Routes
      { path: 'tracking', element: <Tracking /> },
      { path: 'tracking/:trackingId', element: <Tracking /> },
      { path: 'analytics', element: <AnalyticsPage /> },
      { path: 'history', element: <HistoryPage /> },
      { path: 'warehouse', element: <WarehousePage /> },
      { path: 'feedback', element: <FeedbackPage /> },
      { path: 'simulator', element: <LangProvider><Simulator /></LangProvider> },
      { path: 'market', element: <MarketRatesPage /> },
    ]
  },
  { path: '*', element: <NotFoundPage /> }
])
