import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api } from '@/api/client'
import type { Fpo } from '@/api/types'
import { ToastProvider } from '@/components/ui/Toast'

export type UserRole = 'farmer' | 'fpo' | 'buyer' | 'government' | 'admin' | 'delivery' | null

interface AppState {
  fpo: Fpo | null
  fpoLoading: boolean
  /** True when running on the bundled synthetic dataset (offline demo). */
  demoMode: boolean
  isAuthenticated: boolean
  role: UserRole
  userId: string | null
  login: (selectedRole: UserRole, token?: string) => void
  logout: () => void
}

const AppContext = createContext<AppState | null>(null)

export function useApp(): AppState {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}

const AUTH_KEY = 'mv.session.v1'
const ROLE_KEY = 'mv.role.v1'

export function AppProvider({ children }: { children: ReactNode }) {
  const [fpo, setFpo] = useState<Fpo | null>(null)
  const [fpoLoading, setFpoLoading] = useState(true)
  
  const [isAuthenticated, setAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(AUTH_KEY) === '1'
    } catch {
      return false
    }
  })

  const [role, setRole] = useState<UserRole>(() => {
    try {
      return (sessionStorage.getItem(ROLE_KEY) as UserRole) || null
    } catch {
      return null
    }
  })

  useEffect(() => {
    // Only FPO users need the FPO dashboard endpoint. Others (government, farmer, buyer)
    // would get 401s, which can interfere with the loading state and the role guard.
    const storedRole = sessionStorage.getItem(ROLE_KEY)
    if (storedRole === 'fpo') {
      let alive = true
      api
        .getDashboard()
        .then((res: any) => {
          if (alive) setFpo(res.data.fpo)
        })
        .catch(console.error)
        .finally(() => alive && setFpoLoading(false))
      return () => { alive = false }
    } else {
      setFpoLoading(false)
    }
  }, [])


  const login = useCallback((selectedRole: UserRole, token?: string) => {
    setAuthenticated(true)
    setRole(selectedRole)
    try {
      sessionStorage.setItem(AUTH_KEY, '1')
      sessionStorage.setItem(ROLE_KEY, selectedRole || 'fpo')
      if (token) {
        sessionStorage.setItem('mv.auth.token', token)
      }
    } catch {
      /* non-fatal */
    }
  }, [])

  const logout = useCallback(() => {
    setAuthenticated(false)
    setRole(null)
    try {
      sessionStorage.removeItem(AUTH_KEY)
      sessionStorage.removeItem(ROLE_KEY)
      sessionStorage.removeItem('mv.auth.token')
    } catch {
      /* non-fatal */
    }
  }, [])

  const value = useMemo<AppState>(
    () => ({
      fpo,
      fpoLoading,
      demoMode: false,
      isAuthenticated,
      role,
      userId: 'mock-user-id', // TODO: Decode from JWT
      login,
      logout,
    }),
    [fpo, fpoLoading, isAuthenticated, role, login, logout],
  )

  return (
    <AppContext.Provider value={value}>
      <ToastProvider>{children}</ToastProvider>
    </AppContext.Provider>
  )
}
