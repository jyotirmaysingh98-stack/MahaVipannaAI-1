import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Tractor, Sprout, HandCoins, TrendingUp, Sparkles, MapPin } from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { api } from '@/api/client'
import { useI18n } from '@/lib/i18n'
import { Button } from '@/components/ui/Button'
import { FeedbackModal } from '@/components/ui/FeedbackModal'

export function FarmerDashboard() {
  const { t } = useI18n()
  const [lotsCount, setLotsCount] = useState(0)
  const [feedbackOpen, setFeedbackOpen] = useState(false)

  useEffect(() => {
    fetchLots()
  }, [])

  const fetchLots = async () => {
    try {
      const res = await api.getLots()
      if (res.success && res.data) setLotsCount(res.data.length)
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">{t('farmer.title')}</h1>
          <p className="mt-1 text-ink-2">{t('farmer.subtitle')}</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Link to="/app/tracking">
            <Button variant="secondary" className="gap-2">
              <MapPin size={16} className="text-pine-600" /> Track Deliveries
            </Button>
          </Link>
          <button
            onClick={() => setFeedbackOpen(true)}
            className="px-3.5 py-2 rounded-xl border border-line bg-surface hover:bg-surface-sunk text-ink text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Sparkles size={14} className="text-amber-500" />
            <span>Send Admin Feedback</span>
          </button>
        </div>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-pine-600/10 text-pine-600">
              <Sprout size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('farmer.activeLots')}</p>
              <p className="text-2xl font-bold text-ink">{lotsCount} {t('farmer.lots')}</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-indigo-600/10 text-indigo-600">
              <HandCoins size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('farmer.ongoingNegotiations')}</p>
              <p className="text-2xl font-bold text-ink">1 {t('farmer.activeCount')}</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-600/10 text-amber-600">
              <Tractor size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-ink-3">{t('farmer.subsidies')}</p>
              <p className="text-2xl font-bold text-ink">2 {t('farmer.schemesCount')}</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <div className="space-y-4">
        <h2 className="font-display text-xl font-semibold text-ink">{t('farmer.alerts')}</h2>
        <div className="rounded-2xl border border-pine-600/20 bg-pine-600/10 p-6 flex gap-4">
          <TrendingUp className="text-pine-600 shrink-0 mt-1" />
          <div>
            <h3 className="font-semibold text-pine-600">{t('farmer.alertTitle')}</h3>
            <p className="text-sm text-ink-2 mt-1">{t('farmer.alertDesc')}</p>
          </div>
        </div>
      </div>

      <FeedbackModal isOpen={feedbackOpen} onClose={() => setFeedbackOpen(false)} fromUserId="demo-farmer-1" />
    </div>
  )
}
