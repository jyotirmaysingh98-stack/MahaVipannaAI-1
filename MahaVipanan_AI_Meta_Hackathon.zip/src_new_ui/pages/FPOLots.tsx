import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowRight, TrendingUp, Wheat, Package, Handshake, Plus, X,
  Edit3, Trash2, Save, AlertCircle, CheckCircle2, Loader2,
  IndianRupee, Scale, Truck, Sparkles
} from 'lucide-react'
import { api } from '@/api/client'
import type { LotResponse } from '@/api/types'
import { qt, inr } from '@/lib/format'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Skeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'

// ─── Helpers ────────────────────────────────────────────────────────────────

type Toast = { id: number; kind: 'success' | 'error'; msg: string }
let _tid = 0

function statusBadge(status: string) {
  const map: Record<string, string> = {
    draft:  'bg-amber-100 text-amber-700',
    ready:  'bg-pine-100 text-pine-700',
    sold:   'bg-surface-sunk text-ink-3',
    held:   'bg-indigo-100 text-indigo-700',
  }
  return map[status] ?? 'bg-surface-sunk text-ink-3'
}

// ─── Create Modal ────────────────────────────────────────────────────────────

function CreateLotModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [cropName, setCropName] = useState('')
  const [quantityKg, setQuantityKg] = useState('')
  const [price, setPrice] = useState('')
  const [transport, setTransport] = useState('')
  const [misc, setMisc] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!cropName.trim() || !quantityKg) { setError('Crop name and quantity are required.'); return }
    setSaving(true); setError(null)
    try {
      await api.createLot({
        crop_name: cropName.trim(),
        expected_price_per_q: price ? parseFloat(price) : undefined,
        baseline_transport_cost_per_q: transport ? parseFloat(transport) : undefined,
        miscellaneous_cost_per_q: misc ? parseFloat(misc) : undefined,
        members: [{ member_name: 'FPO Co-op', quantity_kg: parseFloat(quantityKg), grade: 'Grade A' }]
      } as any)
      onCreated()
      onClose()
    } catch (err: any) {
      setError(err.message || 'Failed to create lot. Please try again.')
    } finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }} transition={{ type: 'spring', damping: 22, stiffness: 280 }}
        className="relative w-full max-w-lg rounded-3xl border border-line bg-paper shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-line bg-gradient-to-r from-pine-600 to-pine-500">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl">
              <Sparkles size={18} className="text-white" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-white">Create New Lot</h2>
              <p className="text-pine-100 text-xs">Add new produce to FPO inventory</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
              <AlertCircle size={15} className="shrink-0" /> {error}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Crop Name *</label>
              <input value={cropName} onChange={e => setCropName(e.target.value)} required
                placeholder="e.g. Onion, Tomato, Wheat"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Quantity (kg) *</label>
              <input type="number" min="1" value={quantityKg} onChange={e => setQuantityKg(e.target.value)} required
                placeholder="e.g. 1000"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Expected Price (₹/qt)</label>
              <input type="number" min="0" value={price} onChange={e => setPrice(e.target.value)}
                placeholder="e.g. 2500"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Transport Cost (₹/qt)</label>
              <input type="number" min="0" value={transport} onChange={e => setTransport(e.target.value)}
                placeholder="e.g. 150"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Misc. Cost (₹/qt)</label>
              <input type="number" min="0" value={misc} onChange={e => setMisc(e.target.value)}
                placeholder="e.g. 50"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={onClose} className="flex-1" disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving} className="flex-1 bg-pine-600 hover:bg-pine-700 text-white">
              {saving ? <><Loader2 size={15} className="mr-2 animate-spin" />Creating...</> : <><Plus size={15} className="mr-2" />Create Lot</>}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}

// ─── Edit Modal ──────────────────────────────────────────────────────────────

function EditLotModal({ lot, onClose, onSaved }: { lot: LotResponse; onClose: () => void; onSaved: () => void }) {
  const [price, setPrice] = useState(lot.expected_price_per_q?.toString() || '')
  const [transport, setTransport] = useState(lot.baseline_transport_cost_per_q?.toString() || '')
  const [misc, setMisc] = useState(lot.miscellaneous_cost_per_q?.toString() || '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true); setError(null)
    try {
      await api.updateLot(lot.id, {
        expected_price_per_q: price ? parseFloat(price) : undefined,
        baseline_transport_cost_per_q: transport ? parseFloat(transport) : undefined,
        miscellaneous_cost_per_q: misc ? parseFloat(misc) : undefined,
      })
      onSaved(); onClose()
    } catch (err: any) {
      setError(err.message || 'Failed to save changes.')
    } finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }} transition={{ type: 'spring', damping: 22, stiffness: 280 }}
        className="relative w-full max-w-md rounded-3xl border border-line bg-paper shadow-2xl overflow-hidden"
      >
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-line bg-gradient-to-r from-amber-500 to-amber-600">
          <div>
            <h2 className="font-display text-lg font-bold text-white">Edit Lot Pricing</h2>
            <p className="text-amber-100 text-xs">{lot.crop_name} · {qt(lot.total_quantity_q)}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
              <AlertCircle size={15} className="shrink-0" /> {error}
            </div>
          )}
          {[
            { label: 'Expected Price (₹/qt)', value: price, onChange: setPrice, placeholder: 'e.g. 2500' },
            { label: 'Transport Cost (₹/qt)', value: transport, onChange: setTransport, placeholder: 'e.g. 150' },
            { label: 'Misc. Cost (₹/qt)', value: misc, onChange: setMisc, placeholder: 'e.g. 50' },
          ].map(f => (
            <div key={f.label}>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">{f.label}</label>
              <input type="number" min="0" value={f.value} onChange={e => f.onChange(e.target.value)}
                placeholder={f.placeholder}
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 outline-none transition-all" />
            </div>
          ))}
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={onClose} className="flex-1" disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving} className="flex-1 bg-amber-500 hover:bg-amber-600 text-white">
              {saving ? <><Loader2 size={15} className="mr-2 animate-spin" />Saving...</> : <><Save size={15} className="mr-2" />Save Changes</>}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}

// ─── Lot Card ────────────────────────────────────────────────────────────────

function LotCard({ lot, type, onEdit, onDelete }: {
  lot: LotResponse; type: 'inventory' | 'offer'
  onEdit: (lot: LotResponse) => void
  onDelete: (lot: LotResponse) => void
}) {
  const isOffer = type === 'offer'

  return (
    <motion.div variants={fadeUp} className="group relative flex flex-col rounded-3xl bg-surface border border-line hover:border-pine-300 hover:shadow-lg transition-all duration-300 overflow-hidden">
      {/* Top accent strip */}
      <div className={`h-1 w-full ${isOffer ? 'bg-gradient-to-r from-amber-400 to-amber-500' : 'bg-gradient-to-r from-pine-500 to-pine-400'}`} />

      <div className="flex-1 p-5">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className={`flex items-center justify-center h-11 w-11 rounded-2xl ${isOffer ? 'bg-amber-50 text-amber-600' : 'bg-pine-50 text-pine-600'} ring-1 ring-inset ${isOffer ? 'ring-amber-500/20' : 'ring-pine-500/20'}`}>
              <Wheat size={22} />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-ink leading-tight">{lot.crop_name}</h3>
              <p className={`text-sm font-semibold ${isOffer ? 'text-amber-600' : 'text-pine-600'}`}>{qt(lot.total_quantity_q)}</p>
            </div>
          </div>
          <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${statusBadge(lot.status)}`}>
            {lot.status}
          </span>
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="flex flex-col items-center p-2.5 rounded-xl bg-surface-sunk border border-line/50">
            <IndianRupee size={12} className="text-ink-3 mb-1" />
            <p className="text-xs font-bold text-ink">{lot.expected_price_per_q ? `₹${lot.expected_price_per_q}` : '—'}</p>
            <p className="text-[9px] text-ink-3 uppercase tracking-wider mt-0.5">Price/qt</p>
          </div>
          <div className="flex flex-col items-center p-2.5 rounded-xl bg-surface-sunk border border-line/50">
            <Truck size={12} className="text-ink-3 mb-1" />
            <p className="text-xs font-bold text-ink">{lot.baseline_transport_cost_per_q ? `₹${lot.baseline_transport_cost_per_q}` : '—'}</p>
            <p className="text-[9px] text-ink-3 uppercase tracking-wider mt-0.5">Transport</p>
          </div>
          <div className="flex flex-col items-center p-2.5 rounded-xl bg-surface-sunk border border-line/50">
            <Scale size={12} className="text-ink-3 mb-1" />
            <p className="text-xs font-bold text-ink">{lot.total_quantity_kg ? `${lot.total_quantity_kg}kg` : '—'}</p>
            <p className="text-[9px] text-ink-3 uppercase tracking-wider mt-0.5">Total Wt.</p>
          </div>
        </div>

        {lot.original_farmer_name && (
          <p className="text-xs text-ink-3 truncate">
            <span className="font-semibold">Farmer:</span> {lot.original_farmer_name}
          </p>
        )}
      </div>

      {/* Actions */}
      <div className="px-5 pb-5 pt-0">
        <div className="flex items-center gap-2 pt-4 border-t border-line">
          {isOffer ? (
            <Link to={`/app/negotiation/${lot.id}`}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-sm font-bold transition-colors">
              Review Offer <ArrowRight size={14} />
            </Link>
          ) : (
            <Link to={`/app/fpo/lots/${lot.id}`}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-pine-600 hover:bg-pine-700 text-white text-sm font-bold transition-colors">
              Find Buyers <ArrowRight size={14} />
            </Link>
          )}
          <button onClick={() => onEdit(lot)}
            className="p-2 rounded-xl border border-line text-ink-2 hover:text-amber-600 hover:border-amber-300 hover:bg-amber-50 transition-colors" title="Edit Pricing">
            <Edit3 size={15} />
          </button>
          <button onClick={() => onDelete(lot)}
            className="p-2 rounded-xl border border-line text-ink-2 hover:text-red-600 hover:border-red-300 hover:bg-red-50 transition-colors" title="Delete Lot">
            <Trash2 size={15} />
          </button>
        </div>
      </div>
    </motion.div>
  )
}

// ─── Toast ───────────────────────────────────────────────────────────────────

function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-2 pointer-events-none">
      <AnimatePresence>
        {toasts.map(t => (
          <motion.div key={t.id} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 40 }}
            className={`pointer-events-auto flex items-center gap-2 px-4 py-3 rounded-2xl shadow-lg text-sm font-semibold ${t.kind === 'success' ? 'bg-pine-600 text-white' : 'bg-red-600 text-white'}`}>
            {t.kind === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
            {t.msg}
            <button onClick={() => onDismiss(t.id)} className="ml-2 opacity-70 hover:opacity-100"><X size={14} /></button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}

// ─── Delete Confirm ──────────────────────────────────────────────────────────

function DeleteConfirm({ lot, onConfirm, onClose, deleting }: {
  lot: LotResponse; onConfirm: () => void; onClose: () => void; deleting: boolean
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-sm rounded-3xl border border-red-200 bg-paper shadow-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 bg-red-100 rounded-2xl text-red-600"><Trash2 size={20} /></div>
          <div>
            <h3 className="font-bold text-ink">Delete this lot?</h3>
            <p className="text-xs text-ink-3">{lot.crop_name} · {qt(lot.total_quantity_q)}</p>
          </div>
        </div>
        <p className="text-sm text-ink-2 mb-6">This action cannot be undone. The lot will be permanently removed.</p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={onClose} className="flex-1" disabled={deleting}>Cancel</Button>
          <Button onClick={onConfirm} disabled={deleting} className="flex-1 bg-red-600 hover:bg-red-700 text-white">
            {deleting ? <><Loader2 size={14} className="mr-1.5 animate-spin" />Deleting…</> : 'Yes, Delete'}
          </Button>
        </div>
      </motion.div>
    </div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export function FPOLots() {
  const [inventory, setInventory] = useState<LotResponse[]>([])
  const [offers, setOffers] = useState<LotResponse[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'inventory' | 'offers'>('inventory')
  const [showCreate, setShowCreate] = useState(false)
  const [editLot, setEditLot] = useState<LotResponse | null>(null)
  const [deleteLot, setDeleteLot] = useState<LotResponse | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [toasts, setToasts] = useState<Toast[]>([])

  const toast = (kind: Toast['kind'], msg: string) => {
    const id = ++_tid
    setToasts(p => [...p, { id, kind, msg }])
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 4000)
  }

  const fetchData = () => {
    setLoading(true)
    Promise.all([api.getFpoInventory(), api.getFpoOffers()])
      .then(([invRes, offRes]) => {
        if (invRes.success) setInventory(invRes.data || [])
        if (offRes.success) setOffers(offRes.data || [])
      })
      .catch(() => toast('error', 'Failed to load lots.'))
      .finally(() => setLoading(false))
  }

  useEffect(() => { fetchData() }, [])

  const handleDelete = async () => {
    if (!deleteLot) return
    setDeleting(true)
    try {
      await api.deleteLot(deleteLot.id)
      toast('success', 'Lot deleted successfully.')
      setDeleteLot(null)
      fetchData()
    } catch (err: any) {
      toast('error', err.message || 'Failed to delete lot.')
    } finally { setDeleting(false) }
  }

  const displayed = activeTab === 'inventory' ? inventory : offers

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">

      {/* ── Header ─────────────────────────────────────────────── */}
      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={fadeUp} className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="font-display text-4xl font-black tracking-tight text-ink bg-clip-text text-transparent bg-gradient-to-r from-pine-700 to-pine-500">
              FPO Command Centre
            </h1>
            <p className="mt-1.5 text-ink-2 font-medium">Manage inventory and review farmer offers in real time.</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="shrink-0 bg-pine-600 hover:bg-pine-700 text-white shadow-lg">
            <Plus size={16} className="mr-2" /> New Lot
          </Button>
        </motion.div>

        {/* Stats bar */}
        <motion.div variants={fadeUp} className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {[
            { label: 'Total Inventory', value: inventory.length, icon: Package, color: 'pine' },
            { label: 'Pending Offers', value: offers.length, icon: Handshake, color: 'amber' },
            {
              label: 'Total Stock (qt)',
              value: qt(inventory.reduce((s, l) => s + l.total_quantity_q, 0)),
              icon: Scale, color: 'indigo'
            },
            {
              label: 'Avg. Asking Price',
              value: inventory.length
                ? inr(inventory.reduce((s, l) => s + (l.expected_price_per_q || 0), 0) / inventory.length)
                : '—',
              icon: IndianRupee, color: 'teal'
            },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="glass rounded-2xl p-4 border border-line">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-2 bg-${color}-50 text-${color}-600`}>
                <Icon size={16} />
              </div>
              <p className="font-display text-xl font-bold text-ink">{value}</p>
              <p className="text-xs text-ink-3 font-medium mt-0.5">{label}</p>
            </div>
          ))}
        </motion.div>

        {/* Tab switcher */}
        <motion.div variants={fadeUp} className="flex p-1 bg-surface-sunk rounded-2xl border border-line w-fit shadow-inner">
          {(['inventory', 'offers'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`relative px-5 py-2 rounded-xl text-sm font-bold transition-all duration-200 flex items-center gap-2 ${activeTab === tab ? 'text-white' : 'text-ink-2 hover:text-ink'}`}>
              {activeTab === tab && (
                <motion.div layoutId="fpo-tab"
                  className={`absolute inset-0 rounded-xl ${tab === 'inventory' ? 'bg-gradient-to-br from-pine-500 to-pine-600' : 'bg-gradient-to-br from-amber-500 to-amber-600'} shadow-md`} />
              )}
              <span className="relative z-10">{tab === 'inventory' ? <Package size={15} /> : <Handshake size={15} />}</span>
              <span className="relative z-10 capitalize">{tab} ({tab === 'inventory' ? inventory.length : offers.length})</span>
            </button>
          ))}
        </motion.div>
      </motion.div>

      {/* ── Content ────────────────────────────────────────────── */}
      {loading ? (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {[0,1,2].map(i => <Skeleton key={i} className="h-64 rounded-3xl" />)}
        </div>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div key={activeTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
            {displayed.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 rounded-3xl border border-dashed border-line text-center">
                <div className="p-6 bg-surface-sunk rounded-full mb-4 text-ink-3">
                  {activeTab === 'inventory' ? <Package size={40} /> : <Handshake size={40} />}
                </div>
                <h3 className="text-xl font-bold text-ink mb-2">
                  {activeTab === 'inventory' ? 'No Active Inventory' : 'No Pending Offers'}
                </h3>
                <p className="text-ink-2 text-sm max-w-xs">
                  {activeTab === 'inventory'
                    ? 'Create your first lot to start managing FPO inventory.'
                    : 'Farmer offers directed to your FPO will appear here.'}
                </p>
                {activeTab === 'inventory' && (
                  <Button onClick={() => setShowCreate(true)} className="mt-6 bg-pine-600 hover:bg-pine-700 text-white">
                    <Plus size={15} className="mr-2" /> Create First Lot
                  </Button>
                )}
              </div>
            ) : (
              <motion.div variants={staggerContainer} initial="hidden" animate="show"
                className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {displayed.map((lot) => (
                  <LotCard key={lot.id} lot={lot} type={activeTab === 'inventory' ? 'inventory' : 'offer'}
                    onEdit={setEditLot} onDelete={setDeleteLot} />
                ))}
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      )}

      {/* ── Radar promo banner ─────────────────────────────────── */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
        className="mt-14 rounded-3xl border border-pine-500/30 bg-gradient-to-br from-pine-900 to-pine-700 overflow-hidden relative shadow-2xl">
        <div className="relative p-8 flex flex-col md:flex-row items-center gap-6">
          <div className="p-4 bg-pine-500/20 rounded-2xl border border-pine-500/40 backdrop-blur-md">
            <TrendingUp size={32} className="text-pine-300" />
          </div>
          <div className="flex-1 text-center md:text-left">
            <h3 className="text-2xl font-display font-bold text-white mb-2">Market Opportunity Radar</h3>
            <p className="text-pine-200 text-sm leading-relaxed max-w-3xl">
              Match your inventory with top institutional buyers. Optimize for Net Realization Price across India — powered by live market data and AI.
            </p>
          </div>
        </div>
      </motion.div>

      {/* ── Modals ─────────────────────────────────────────────── */}
      <AnimatePresence>
        {showCreate && (
          <CreateLotModal onClose={() => setShowCreate(false)} onCreated={() => { fetchData(); toast('success', 'Lot created successfully!') }} />
        )}
        {editLot && (
          <EditLotModal lot={editLot} onClose={() => setEditLot(null)} onSaved={() => { fetchData(); toast('success', 'Lot updated successfully!') }} />
        )}
        {deleteLot && (
          <DeleteConfirm lot={deleteLot} onClose={() => setDeleteLot(null)} onConfirm={handleDelete} deleting={deleting} />
        )}
      </AnimatePresence>

      <Toasts toasts={toasts} onDismiss={id => setToasts(p => p.filter(t => t.id !== id))} />
    </div>
  )
}
