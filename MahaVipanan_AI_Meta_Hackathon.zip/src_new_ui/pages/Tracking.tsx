import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useApp } from '@/state/AppContext'
import { LiveOrderMap } from '@/components/map/LiveOrderMap'
import { api } from '@/api/client'
import { Truck, Package, Clock, CheckCircle2 } from 'lucide-react'
import { motion } from 'framer-motion'
import { fadeUp, staggerContainer } from '@/lib/motion'

export function Tracking() {
  const { trackingId } = useParams<{ trackingId?: string }>()
  const { role } = useApp()
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadOrders()
  }, [])

  const loadOrders = async () => {
    try {
      setLoading(true)
      const res = await api.getOrders()
      if (res.success && res.data) {
        setOrders(res.data)
      }
    } catch (e) {
      console.error('Failed to fetch orders for tracking page', e)
    } finally {
      setLoading(false)
    }
  }

  const activeCount = orders.filter(o => o.status === 'in_transit').length
  const pickupCount = orders.filter(o => o.status === 'pickup').length
  const deliveredCount = orders.filter(o => o.status === 'delivered').length

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 space-y-8">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-pine-100 text-pine-800 border border-pine-200 dark:bg-pine-900/40 dark:text-pine-300 dark:border-pine-800">
            Demo Delivery Simulation Corridor
          </span>
          <span className="text-xs text-ink-3 uppercase tracking-wider font-semibold">Role: {role || 'FPO'}</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-ink">Live Delivery & Logistics Tracking</h1>
        <p className="mt-1 text-ink-2">Real-time GPS corridor tracking, route coordination, and buyer delivery instructions.</p>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="show"
        className="grid gap-6 md:grid-cols-3"
      >
        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm border border-line">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
              <Truck size={24} />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-ink-3">In Transit Shipments</p>
              <p className="text-2xl font-bold text-ink">{loading ? '...' : (activeCount || 1)} Active</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm border border-line">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-ink-3">Ready for Pickup</p>
              <p className="text-2xl font-bold text-ink">{loading ? '...' : (pickupCount || 1)} Pending</p>
            </div>
          </div>
        </motion.div>

        <motion.div variants={fadeUp} className="rounded-2xl glass p-6 shadow-sm border border-line">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-ink-3">Delivered to Terminal</p>
              <p className="text-2xl font-bold text-ink">{loading ? '...' : (deliveredCount || 1)} Completed</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Real Live Order Satellite Map */}
      <div className="space-y-4">
        <h2 className="font-display text-xl font-bold text-ink flex items-center gap-2">
          <Truck className="text-pine-600" size={22} />
          <span>Satellite GPS Route Corridor</span>
        </h2>
        <LiveOrderMap orderId={trackingId} userRole={role as any} onOrderUpdated={loadOrders} />
      </div>

      {/* Active Logistics Manifest Table */}
      {orders.length > 0 && (
        <div className="space-y-4">
          <h2 className="font-display text-xl font-bold text-ink flex items-center gap-2">
            <Package className="text-pine-600" size={22} />
            <span>Active Logistics Orders</span>
          </h2>
          <div className="rounded-3xl border border-line bg-surface overflow-hidden shadow-card">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-line bg-surface-sunk/60 text-xs uppercase tracking-wider text-ink-3">
                  <tr>
                    <th className="px-5 py-3.5 font-bold">Tracking #</th>
                    <th className="px-5 py-3.5 font-bold">Crop & Quantity</th>
                    <th className="px-5 py-3.5 font-bold">Pickup Origin</th>
                    <th className="px-5 py-3.5 font-bold">Destination & Recipient</th>
                    <th className="px-5 py-3.5 font-bold">Special Instructions</th>
                    <th className="px-5 py-3.5 font-bold text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {orders.map((o) => (
                    <tr key={o.id} className="hover:bg-surface-sunk/30 transition-colors">
                      <td className="px-5 py-4 font-mono font-bold text-xs text-pine-700 dark:text-pine-400">
                        {o.tracking_number}
                      </td>
                      <td className="px-5 py-4">
                        <div className="font-bold text-ink">{o.crop_name}</div>
                        <div className="text-xs text-ink-3">{o.quantity_q} Quintals</div>
                      </td>
                      <td className="px-5 py-4 text-xs text-ink-2 max-w-[180px]">
                        {o.pickup_location}
                      </td>
                      <td className="px-5 py-4">
                        <div className="text-xs font-semibold text-ink">{o.delivery_location}</div>
                        <div className="text-xs text-pine-600 font-medium">{o.recipient_name} ({o.recipient_phone})</div>
                      </td>
                      <td className="px-5 py-4 text-xs italic text-amber-900 dark:text-amber-200 bg-amber-50/40 dark:bg-amber-950/30 rounded-xl max-w-[220px]">
                        "{o.special_instructions || 'Standard handled cargo'}"
                      </td>
                      <td className="px-5 py-4 text-right">
                        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold ${
                          o.status === 'delivered' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                          o.status === 'in_transit' ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300' :
                          'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {o.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
