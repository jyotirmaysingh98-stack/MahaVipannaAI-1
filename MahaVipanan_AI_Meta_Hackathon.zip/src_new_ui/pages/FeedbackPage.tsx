import { useState, useEffect } from 'react'
import { Star, MessageSquare } from 'lucide-react'
import { api } from '@/api/client'
import { Skeleton } from '@/components/ui/Skeleton'

export function FeedbackPage() {
  const [feedback, setFeedback] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getFeedback().then(res => {
      setFeedback(res.data || [])
    }).finally(() => setLoading(false))
  }, [])

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">Feedback & Reviews</h1>
        <p className="mt-1 text-ink-2">See what buyers and farmers are saying.</p>
      </div>

      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-32 w-full rounded-2xl" />
          <Skeleton className="h-32 w-full rounded-2xl" />
        </div>
      ) : feedback.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-line bg-surface p-12 text-center">
          <MessageSquare size={48} className="mx-auto mb-4 text-ink-3 opacity-50" />
          <p className="text-lg font-semibold text-ink">No feedback yet</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {feedback.map(item => (
            <div key={item.id} className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-2">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star 
                    key={star} 
                    size={20} 
                    className={star <= item.rating ? 'fill-amber-400 text-amber-400' : 'text-line-strong'} 
                  />
                ))}
              </div>
              {item.comments && (
                <p className="text-ink-2 mt-2">{item.comments}</p>
              )}
              <div className="mt-4 text-sm text-ink-3">
                {new Date(item.created_at).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
