import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Plus, X, Edit3, Trash2, Save, Loader2, AlertCircle, CheckCircle2,
  Wheat, IndianRupee, Truck, Scale, Package, Sparkles, TrendingUp
} from 'lucide-react'
import { fadeUp, staggerContainer } from '@/lib/motion'
import { Button } from '@/components/ui/Button'
import { api } from '@/api/client'
import type { FarmerLot } from '@/api/types'
import { useI18n } from '@/lib/i18n'
import { Skeleton } from '@/components/ui/Skeleton'

// ─── Helpers ────────────────────────────────────────────────────────────────

type Toast = { id: number; kind: 'success' | 'error'; msg: string }
let _tid = 0

function statusBadge(status: string) {
  const map: Record<string, string> = {
    draft:  'bg-amber-100 text-amber-700',
    ready:  'bg-pine-100 text-pine-700',
    sold:   'bg-surface-sunk text-ink-3',
    held:   'bg-indigo-100 text-indigo-700',
  }
  return map[status] ?? 'bg-surface-sunk text-ink-3'
}

// ─── Create Modal ────────────────────────────────────────────────────────────

function CreateLotModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [cropName, setCropName] = useState('')
  const [quantityKg, setQuantityKg] = useState('')
  const [price, setPrice] = useState('')
  const [transport, setTransport] = useState('')
  const [misc, setMisc] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!cropName.trim() || !quantityKg) { setError('Crop name and quantity are required.'); return }
    setSaving(true); setError(null)
    try {
      await api.createLot({
        crop_name: cropName.trim(),
        expected_price_per_q: price ? parseFloat(price) : undefined,
        baseline_transport_cost_per_q: transport ? parseFloat(transport) : undefined,
        miscellaneous_cost_per_q: misc ? parseFloat(misc) : undefined,
        members: [{ member_name: 'Self', quantity_kg: parseFloat(quantityKg), grade: 'Grade A' }]
      } as any)
      onCreated()
      onClose()
    } catch (err: any) {
      setError(err.message || 'Failed to create lot. Please try again.')
    } finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }} transition={{ type: 'spring', damping: 22, stiffness: 280 }}
        className="relative w-full max-w-lg rounded-3xl border border-line bg-paper shadow-2xl overflow-hidden">

        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-line bg-gradient-to-r from-pine-600 to-pine-500">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl"><Sparkles size={18} className="text-white" /></div>
            <div>
              <h2 className="font-display text-lg font-bold text-white">Register New Lot</h2>
              <p className="text-pine-100 text-xs">Add your produce to the marketplace</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
              <AlertCircle size={15} className="shrink-0" /> {error}
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Crop Name *</label>
              <input value={cropName} onChange={e => setCropName(e.target.value)} required
                placeholder="e.g. Onion, Tomato, Wheat"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Quantity (kg) *</label>
              <input type="number" min="1" value={quantityKg} onChange={e => setQuantityKg(e.target.value)} required
                placeholder="e.g. 500"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Expected Price (₹/qt)</label>
              <input type="number" min="0" value={price} onChange={e => setPrice(e.target.value)}
                placeholder="e.g. 2500"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Transport Cost (₹/qt)</label>
              <input type="number" min="0" value={transport} onChange={e => setTransport(e.target.value)}
                placeholder="e.g. 150"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
            <div>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">Misc. Cost (₹/qt)</label>
              <input type="number" min="0" value={misc} onChange={e => setMisc(e.target.value)}
                placeholder="e.g. 50"
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-pine-400 focus:ring-2 focus:ring-pine-400/20 outline-none transition-all" />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={onClose} className="flex-1" disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving} className="flex-1 bg-pine-600 hover:bg-pine-700 text-white">
              {saving ? <><Loader2 size={15} className="mr-2 animate-spin" />Creating...</> : <><Plus size={15} className="mr-2" />Register Lot</>}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}

// ─── Edit Modal ──────────────────────────────────────────────────────────────

function EditLotModal({ lot, onClose, onSaved }: { lot: FarmerLot; onClose: () => void; onSaved: () => void }) {
  const [price, setPrice] = useState(lot.expected_price_per_q?.toString() || '')
  const [transport, setTransport] = useState(lot.baseline_transport_cost_per_q?.toString() || '')
  const [misc, setMisc] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true); setError(null)
    try {
      await api.updateLot(lot.id, {
        expected_price_per_q: price ? parseFloat(price) : undefined,
        baseline_transport_cost_per_q: transport ? parseFloat(transport) : undefined,
        miscellaneous_cost_per_q: misc ? parseFloat(misc) : undefined,
      })
      onSaved(); onClose()
    } catch (err: any) {
      setError(err.message || 'Failed to save changes.')
    } finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }} transition={{ type: 'spring', damping: 22, stiffness: 280 }}
        className="relative w-full max-w-md rounded-3xl border border-line bg-paper shadow-2xl overflow-hidden">

        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-line bg-gradient-to-r from-amber-500 to-amber-600">
          <div>
            <h2 className="font-display text-lg font-bold text-white">Edit Lot Pricing</h2>
            <p className="text-amber-100 text-xs">{lot.crop_name} · {lot.quantity_q} qt</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
              <AlertCircle size={15} className="shrink-0" /> {error}
            </div>
          )}
          {[
            { label: 'Expected Price (₹/qt)', value: price, onChange: setPrice, placeholder: 'e.g. 2500' },
            { label: 'Transport Cost (₹/qt)', value: transport, onChange: setTransport, placeholder: 'e.g. 150' },
            { label: 'Misc. Cost (₹/qt)', value: misc, onChange: setMisc, placeholder: 'e.g. 50' },
          ].map(f => (
            <div key={f.label}>
              <label className="block text-xs font-bold text-ink-3 uppercase tracking-wider mb-1.5">{f.label}</label>
              <input type="number" min="0" value={f.value} onChange={e => f.onChange(e.target.value)}
                placeholder={f.placeholder}
                className="w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 outline-none transition-all" />
            </div>
          ))}
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={onClose} className="flex-1" disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving} className="flex-1 bg-amber-500 hover:bg-amber-600 text-white">
              {saving ? <><Loader2 size={15} className="mr-2 animate-spin" />Saving...</> : <><Save size={15} className="mr-2" />Save Changes</>}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  )
}

// ─── Delete Confirm ──────────────────────────────────────────────────────────

function DeleteConfirm({ lot, onConfirm, onClose, deleting }: {
  lot: FarmerLot; onConfirm: () => void; onClose: () => void; deleting: boolean
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-sm rounded-3xl border border-red-200 bg-paper shadow-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 bg-red-100 rounded-2xl text-red-600"><Trash2 size={20} /></div>
          <div>
            <h3 className="font-bold text-ink">Delete this lot?</h3>
            <p className="text-xs text-ink-3">{lot.crop_name} · {lot.quantity_q} qt</p>
          </div>
        </div>
        <p className="text-sm text-ink-2 mb-6">This action cannot be undone. The lot will be permanently removed.</p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={onClose} className="flex-1" disabled={deleting}>Cancel</Button>
          <Button onClick={onConfirm} disabled={deleting} className="flex-1 bg-red-600 hover:bg-red-700 text-white">
            {deleting ? <><Loader2 size={14} className="mr-1.5 animate-spin" />Deleting…</> : 'Yes, Delete'}
          </Button>
        </div>
      </motion.div>
    </div>
  )
}

// ─── Toast ───────────────────────────────────────────────────────────────────

function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-2 pointer-events-none">
      <AnimatePresence>
        {toasts.map(t => (
          <motion.div key={t.id} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 40 }}
            className={`pointer-events-auto flex items-center gap-2 px-4 py-3 rounded-2xl shadow-lg text-sm font-semibold ${t.kind === 'success' ? 'bg-pine-600 text-white' : 'bg-red-600 text-white'}`}>
            {t.kind === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
            {t.msg}
            <button onClick={() => onDismiss(t.id)} className="ml-2 opacity-70 hover:opacity-100"><X size={14} /></button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}

// ─── Lot Card ────────────────────────────────────────────────────────────────

function LotCard({ lot, isActive, onEdit, onDelete }: {
  lot: FarmerLot; isActive: boolean
  onEdit: (lot: FarmerLot) => void
  onDelete: (lot: FarmerLot) => void
}) {
  return (
    <motion.div variants={fadeUp}
      className={`group relative flex flex-col rounded-3xl border transition-all duration-300 overflow-hidden ${isActive ? 'bg-surface border-line hover:border-pine-300 hover:shadow-lg' : 'bg-surface-sunk border-line/50 opacity-70'}`}>
      <div className={`h-1 w-full ${isActive ? 'bg-gradient-to-r from-pine-500 to-pine-400' : 'bg-gradient-to-r from-surface-sunk to-line'}`} />

      <div className="flex-1 p-5">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className={`flex items-center justify-center h-11 w-11 rounded-2xl ring-1 ring-inset ${isActive ? 'bg-pine-50 text-pine-600 ring-pine-500/20' : 'bg-surface text-ink-3 ring-line'}`}>
              <Wheat size={22} />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-ink leading-tight">{lot.crop_name}</h3>
              <p className={`text-sm font-semibold ${isActive ? 'text-pine-600' : 'text-ink-3'}`}>{lot.quantity_q} qt</p>
            </div>
          </div>
          <span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${statusBadge(lot.status)}`}>
            {lot.status}
          </span>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="flex flex-col items-center p-2.5 rounded-xl bg-surface-sunk border border-line/50">
            <IndianRupee size={12} className="text-ink-3 mb-1" />
            <p className="text-xs font-bold text-ink">{lot.expected_price_per_q ? `₹${lot.expected_price_per_q}` : '—'}</p>
            <p className="text-[9px] text-ink-3 uppercase tracking-wider mt-0.5">Price/qt</p>
          </div>
          <div className="flex flex-col items-center p-2.5 rounded-xl bg-surface-sunk border border-line/50">
            <Truck size={12} className="text-ink-3 mb-1" />
            <p className="text-xs font-bold text-ink">{lot.baseline_transport_cost_per_q ? `₹${lot.baseline_transport_cost_per_q}` : '—'}</p>
            <p className="text-[9px] text-ink-3 uppercase tracking-wider mt-0.5">Transport</p>
          </div>
          <div className="flex flex-col items-center p-2.5 rounded-xl bg-surface-sunk border border-line/50">
            <Scale size={12} className="text-ink-3 mb-1" />
            <p className="text-xs font-bold text-ink">{lot.quantity_q} qt</p>
            <p className="text-[9px] text-ink-3 uppercase tracking-wider mt-0.5">Quantity</p>
          </div>
        </div>
      </div>

      <div className="px-5 pb-5">
        <div className={`flex items-center gap-2 pt-4 border-t border-line ${!isActive ? 'opacity-50 pointer-events-none' : ''}`}>
          <button onClick={() => onEdit(lot)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl border border-line text-ink-2 hover:text-amber-600 hover:border-amber-300 hover:bg-amber-50 transition-colors text-sm font-semibold">
            <Edit3 size={14} /> Edit Pricing
          </button>
          <button onClick={() => onDelete(lot)}
            className="p-2 rounded-xl border border-line text-ink-2 hover:text-red-600 hover:border-red-300 hover:bg-red-50 transition-colors" title="Delete Lot">
            <Trash2 size={15} />
          </button>
        </div>
        {!isActive && (
          <p className="text-xs text-ink-3 text-center pt-3">Ownership transferred or lot sold</p>
        )}
      </div>
    </motion.div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export function FarmerLots() {
  const { t } = useI18n()
  const [lots, setLots] = useState<FarmerLot[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const [editLot, setEditLot] = useState<FarmerLot | null>(null)
  const [deleteLot, setDeleteLot] = useState<FarmerLot | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [toasts, setToasts] = useState<Toast[]>([])

  const toast = (kind: Toast['kind'], msg: string) => {
    const id = ++_tid
    setToasts(p => [...p, { id, kind, msg }])
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 4000)
  }

  const fetchLots = async () => {
    try {
      const res = await api.getFarmerLots()
      if (res.success) setLots(res.data || [])
    } catch { toast('error', 'Failed to load lots.') }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchLots() }, [])

  const activeLots = lots.filter(l => l.is_active)
  const historyLots = lots.filter(l => !l.is_active)

  const handleDelete = async () => {
    if (!deleteLot) return
    setDeleting(true)
    try {
      await api.deleteLot(deleteLot.id)
      toast('success', 'Lot deleted successfully.')
      setDeleteLot(null)
      fetchLots()
    } catch (err: any) {
      toast('error', err.message || 'Failed to delete lot.')
    } finally { setDeleting(false) }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">

      {/* ── Header ────────────────────────────────────────────── */}
      <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mb-8">
        <motion.div variants={fadeUp} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="font-display text-4xl font-black tracking-tight text-ink bg-clip-text text-transparent bg-gradient-to-r from-pine-700 to-pine-500">
              {t('farmer.myLots')}
            </h1>
            <p className="mt-1.5 text-ink-2 font-medium">Register, price and manage your produce inventory.</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="shrink-0 bg-pine-600 hover:bg-pine-700 text-white shadow-lg">
            <Plus size={16} className="mr-2" /> Register Lot
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div variants={fadeUp} className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {[
            { label: 'Active Lots', value: activeLots.length, icon: Package, color: 'pine' },
            { label: 'Sold / Transferred', value: historyLots.length, icon: TrendingUp, color: 'amber' },
            { label: 'Total Qty (qt)', value: lots.reduce((s, l) => s + (l.quantity_q || 0), 0).toFixed(1), icon: Scale, color: 'indigo' },
            {
              label: 'Avg Asking Price',
              value: activeLots.length
                ? `₹${(activeLots.reduce((s, l) => s + (l.expected_price_per_q || 0), 0) / activeLots.length).toFixed(0)}`
                : '—',
              icon: IndianRupee, color: 'teal'
            },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="glass rounded-2xl p-4 border border-line">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-2 bg-${color}-50 text-${color}-600`}>
                <Icon size={16} />
              </div>
              <p className="font-display text-xl font-bold text-ink">{value}</p>
              <p className="text-xs text-ink-3 font-medium mt-0.5">{label}</p>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* ── Content ───────────────────────────────────────────── */}
      {loading ? (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {[0,1,2].map(i => <Skeleton key={i} className="h-64 rounded-3xl" />)}
        </div>
      ) : (
        <div className="space-y-12">
          {/* Active */}
          <section>
            <div className="flex items-center gap-3 mb-5">
              <h2 className="font-display text-2xl font-bold text-ink">Active Inventory</h2>
              <span className="rounded-full bg-pine-100 text-pine-700 px-3 py-0.5 text-sm font-bold">{activeLots.length}</span>
            </div>
            {activeLots.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 rounded-3xl border border-dashed border-line text-center">
                <div className="p-6 bg-surface-sunk rounded-full mb-4 text-ink-3"><Package size={36} /></div>
                <h3 className="text-lg font-bold text-ink mb-2">No Active Lots</h3>
                <p className="text-ink-2 text-sm mb-6">Register your first lot to start selling on the marketplace.</p>
                <Button onClick={() => setShowCreate(true)} className="bg-pine-600 hover:bg-pine-700 text-white">
                  <Plus size={15} className="mr-2" /> Register First Lot
                </Button>
              </div>
            ) : (
              <motion.div variants={staggerContainer} initial="hidden" animate="show"
                className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {activeLots.map(lot => (
                  <LotCard key={lot.id} lot={lot} isActive onEdit={setEditLot} onDelete={setDeleteLot} />
                ))}
              </motion.div>
            )}
          </section>

          {/* History */}
          {historyLots.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-5">
                <h2 className="font-display text-2xl font-bold text-ink">Transferred / Sold</h2>
                <span className="rounded-full bg-surface-sunk text-ink-2 px-3 py-0.5 text-sm font-bold">{historyLots.length}</span>
              </div>
              <motion.div variants={staggerContainer} initial="hidden" animate="show"
                className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {historyLots.map(lot => (
                  <LotCard key={lot.id} lot={lot} isActive={false} onEdit={setEditLot} onDelete={setDeleteLot} />
                ))}
              </motion.div>
            </section>
          )}
        </div>
      )}

      {/* ── Modals ────────────────────────────────────────────── */}
      <AnimatePresence>
        {showCreate && (
          <CreateLotModal onClose={() => setShowCreate(false)} onCreated={() => { fetchLots(); toast('success', 'Lot registered successfully!') }} />
        )}
        {editLot && (
          <EditLotModal lot={editLot} onClose={() => setEditLot(null)} onSaved={() => { fetchLots(); toast('success', 'Lot updated successfully!') }} />
        )}
        {deleteLot && (
          <DeleteConfirm lot={deleteLot} onClose={() => setDeleteLot(null)} onConfirm={handleDelete} deleting={deleting} />
        )}
      </AnimatePresence>

      <Toasts toasts={toasts} onDismiss={id => setToasts(p => p.filter(t => t.id !== id))} />
    </div>
  )
}
