import { useEffect, useState } from 'react'
import { ArrowRight, History as HistoryIcon } from 'lucide-react'
import { api } from '@/api/client'
import { useApp } from '@/state/AppContext'
import { Skeleton } from '@/components/ui/Skeleton'
import type { HistoryItem } from '@/api/types'

export function HistoryPage() {
  const { role } = useApp()
  const [items, setItems] = useState<HistoryItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetcher = role === 'farmer' ? api.getFarmerHistory() : api.getFpoHistory()
    fetcher
      .then(res => setItems(res.data || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [role])

  return (
    <div className="pb-24 max-w-[1000px] mx-auto">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">History</h1>
          <p className="mt-2 text-ink-3">Past transactions and ownership transfers</p>
        </div>
      </div>

      <div className="rounded-2xl border border-line bg-surface overflow-hidden shadow-sm">
        <div className="p-5 border-b border-line bg-surface-sunk/30">
          <h3 className="font-semibold text-ink flex items-center gap-2"><HistoryIcon size={18} className="text-ink-3" /> Transaction Timeline</h3>
        </div>
        <div className="divide-y divide-line">
          {loading ? (
            <div className="p-8 space-y-4">
               <Skeleton className="h-12 w-full" />
               <Skeleton className="h-12 w-full" />
            </div>
          ) : items.length === 0 ? (
            <div className="p-12 text-center text-ink-3">No history found.</div>
          ) : (
            items.map(item => (
              <div key={item.id} className="p-5 flex items-center justify-between hover:bg-surface-sunk/50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${item.status === 'accepted' || item.status === 'delivered' ? 'bg-pine-50 text-pine-600' : 'bg-surface-sunk text-ink-3'}`}>
                    <ArrowRight size={20} className={item.status === 'delivered' ? 'rotate-45' : ''} />
                  </div>
                  <div>
                    <p className="font-semibold text-ink text-sm capitalize">{item.type.toLowerCase()} {item.status}</p>
                    <p className="text-xs text-ink-3 mt-1">{new Date(item.date).toLocaleString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-pine-600 text-sm">₹{item.price_per_q.toLocaleString()}/q</p>
                  <p className="text-xs text-ink-3 font-mono mt-1">{item.quantity_q} q</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
