import { useEffect, useState } from 'react'
import { api } from '@/api/client'
import { Skeleton } from '@/components/ui/Skeleton'
import type { WarehouseItem } from '@/api/types'

export function WarehousePage() {
  const [warehouseItems, setWarehouseItems] = useState<WarehouseItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getFpoWarehouse()
      .then(res => setWarehouseItems(res.data || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="pb-24 max-w-[1200px] mx-auto">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink">Warehouse Management</h1>
          <p className="mt-2 text-ink-3">Manage inventory and track lot ownership</p>
        </div>
      </div>
      
      <div className="rounded-3xl border border-line bg-surface overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-surface-sunk text-ink-3 uppercase text-xs font-semibold tracking-wider">
              <tr>
                <th className="px-6 py-4">Lot ID</th>
                <th className="px-6 py-4">Farmer</th>
                <th className="px-6 py-4">Crop</th>
                <th className="px-6 py-4">Quantity</th>
                <th className="px-6 py-4">Grade</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Stored Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/50">
              {loading ? (
                <tr><td colSpan={7} className="p-8 text-center"><Skeleton className="h-8 w-1/2 mx-auto" /></td></tr>
              ) : warehouseItems.length === 0 ? (
                <tr><td colSpan={7} className="p-8 text-center text-ink-3">No inventory found in warehouse.</td></tr>
              ) : (
                warehouseItems.map(item => (
                  <tr key={`${item.lot_id}-${item.farmer_id}`} className="hover:bg-surface-sunk/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-xs text-ink-2">{item.lot_id.substring(0,8)}</td>
                    <td className="px-6 py-4 font-medium text-ink">{item.farmer_name}</td>
                    <td className="px-6 py-4 text-ink-2">{item.crop}</td>
                    <td className="px-6 py-4 font-semibold text-pine-600">{item.quantity_kg} kg</td>
                    <td className="px-6 py-4">
                      <span className="inline-block bg-line/50 px-2 py-0.5 rounded text-xs font-bold text-ink-2">{item.grade || 'FAQ'}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-bold uppercase ring-1 ring-inset ${
                        item.status === 'ready' ? 'bg-pine-100 text-pine-800 ring-pine-300' : 'bg-amber-100 text-amber-800 ring-amber-300'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-ink-3">{new Date(item.stored_date).toLocaleDateString()}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
