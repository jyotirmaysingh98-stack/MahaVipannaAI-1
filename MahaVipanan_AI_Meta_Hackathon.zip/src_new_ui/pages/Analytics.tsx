import { useEffect, useState } from 'react'

import { TrendingUp, Box, Layers } from 'lucide-react'
import { api } from '@/api/client'
import { useApp } from '@/state/AppContext'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Skeleton } from '@/components/ui/Skeleton'
import type { AnalyticsData } from '@/api/types'

export function AnalyticsPage() {
  const { role } = useApp()
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetcher = role === 'farmer' ? api.getFarmerAnalytics() : api.getFpoAnalytics()
    fetcher
      .then(res => setData(res.data || null))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [role])

  return (
    <div className="pb-24 max-w-[1000px] mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">Analytics</h1>
        <p className="mt-2 text-ink-3">Performance overview and revenue trends</p>
      </div>

      {loading ? (
        <div className="space-y-6">
          <Skeleton className="h-32 w-full rounded-2xl" />
          <Skeleton className="h-80 w-full rounded-2xl" />
        </div>
      ) : (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="rounded-2xl border border-line bg-surface p-6 shadow-sm flex items-center gap-4">
              <div className="p-4 rounded-xl bg-pine-50 text-pine-600"><TrendingUp size={24}/></div>
              <div>
                <p className="text-sm font-medium text-ink-3">Total Revenue</p>
                <p className="text-2xl font-display font-bold text-ink">₹{data?.total_revenue?.toLocaleString() || 0}</p>
              </div>
            </div>
            <div className="rounded-2xl border border-line bg-surface p-6 shadow-sm flex items-center gap-4">
              <div className="p-4 rounded-xl bg-teal-50 text-teal-600"><Box size={24}/></div>
              <div>
                <p className="text-sm font-medium text-ink-3">Sold Lots</p>
                <p className="text-2xl font-display font-bold text-ink">{data?.sold_lots || 0}</p>
              </div>
            </div>
            <div className="rounded-2xl border border-line bg-surface p-6 shadow-sm flex items-center gap-4">
              <div className="p-4 rounded-xl bg-indigo-50 text-indigo-600"><Layers size={24}/></div>
              <div>
                <p className="text-sm font-medium text-ink-3">Active Lots</p>
                <p className="text-2xl font-display font-bold text-ink">{data?.active_lots || 0}</p>
              </div>
            </div>
          </div>
          
          <div className="rounded-2xl border border-line bg-surface p-6 shadow-sm">
            <h3 className="font-semibold text-ink mb-6">Revenue Trend</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data?.chart_data || []}>
                  <defs>
                    <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dx={-10} tickFormatter={(v) => `₹${v/1000}k`} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Revenue']}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
