import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowLeft, Check, ChevronDown, Clock, Crown, MapPin, Sparkles, Wheat, Loader2, Save, PenTool
} from 'lucide-react'
import { useRadar } from '@/state/useRadar'
import { days, inr, inrCompact, km, perQt, qt } from '@/lib/format'
import type { OpportunityResponse } from '@/api/types'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/States'
import { Button } from '@/components/ui/Button'

import { NrpBreakdownModal } from '@/components/radar/NrpBreakdownModal'
import { RecordDecisionModal } from '@/components/radar/RecordDecisionModal'
import { AnimatedNumber } from '@/components/ui/AnimatedNumber'
import { fadeUp, staggerContainer, rankLayout } from '@/lib/motion'
import { cn } from '@/lib/cn'
import { useI18n } from '@/lib/i18n'
import { api } from '@/api/client'

export function OpportunitiesPage() {
  const { t } = useI18n()
  const { lotId } = useParams<{ lotId: string }>()
  const navigate = useNavigate()
  const { lot, radar, loading, error, reload } = useRadar(lotId)

  const [breakdown, setBreakdown] = useState<OpportunityResponse | null>(null)
  const [recordOpen, setRecordOpen] = useState(false)
  const [recorded, setRecorded] = useState<any | null>(null)

  if (loading) return <RadarSkeleton />
  if (error) return <ErrorState onRetry={reload} />
  if (!lot || !radar) return <ErrorState title={t('opps.lotNotFound')} description={t('opps.noBuyers')} onRetry={reload} />

  const { recommendation, opportunities } = radar
  const best = opportunities.find(o => o.rank === 1)
  
  const actionConfigs: Record<string, { label: string; color: string }> = {
    sell: { label: `✅ ${t('opps.sellNow')}`, color: 'from-pine-500/10 to-pine-500/5 border-pine-300 text-pine-700' },
    hold: { label: `⏳ ${t('opps.hold')}`, color: 'from-amber-500/10 to-amber-500/5 border-amber-300 text-amber-700' },
    redirect: { label: `🔀 ${t('opps.redirect')}`, color: 'from-indigo-500/10 to-indigo-500/5 border-indigo-300 text-indigo-700' },
  }
  const currentAction = actionConfigs[recommendation.action] ?? actionConfigs.redirect
  const actionLabel = currentAction.label
  const actionColor = currentAction.color

  return (
    <div className="mx-auto max-w-5xl space-y-8 pb-16">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-ink-2 hover:text-ink font-medium transition-colors">
        <ArrowLeft size={16} /> Back
      </button>

      {/* ── Header ── */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-pine-50 text-pine-600 ring-1 ring-inset ring-pine-500/20 shadow-inner">
            <Wheat size={28} />
          </div>
          <div>
            <h1 className="font-display text-3xl font-black text-ink bg-clip-text text-transparent bg-gradient-to-r from-pine-700 to-pine-500">{lot.crop_name}</h1>
            <p className="mt-1 text-ink-2 font-medium">Market Analysis & Opportunities • {qt(lot.total_quantity_q)}</p>
          </div>
        </div>
      </div>

      <div className="space-y-8">
        <section>
          <StepLabel number={1} label="AI Recommendation" />
          <motion.div layout className={`mt-4 rounded-3xl border bg-gradient-to-br ${actionColor} p-6 shadow-sm`}>
            <p className="text-2xl font-black">{actionLabel}</p>
            {recommendation.recommended_buyer_name && (
              <p className="mt-1 font-medium text-ink/80">Sell to <span className="font-bold text-ink">{recommendation.recommended_buyer_name}</span></p>
            )}

            {best && (
              <div className="mt-6 flex flex-wrap items-end gap-8 bg-white/40 p-5 rounded-2xl border border-white/50 max-w-2xl">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-ink-3 mb-1">Money you keep</p>
                  <AnimatedNumber value={best.nrp_per_qt} format={perQt} className="font-display text-4xl font-black" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-ink-3 mb-1">Total Pool Collects</p>
                  <p className="font-display text-3xl font-black">{inrCompact(best.total_nrp)}</p>
                </div>
              </div>
            )}

            <div className="mt-6 rounded-2xl border border-white/50 bg-white/40 p-4 max-w-3xl">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider">
                <Sparkles size={14} /> AI Rationale
              </p>
              <p className="text-sm font-medium leading-relaxed">{recommendation.ai_explanation}</p>
            </div>

            <div className="mt-6 flex items-center justify-between gap-3 pt-6 border-t border-black/5 max-w-3xl">
              {recorded ? (
                <p className="flex items-center gap-2 text-sm font-bold"><Check size={16} /> Recorded: {recorded.buyerName}</p>
              ) : (
                <p className="text-sm font-medium opacity-80">Finalize your decision.</p>
              )}
              <Button onClick={() => setRecordOpen(true)} className="bg-black/90 hover:bg-black text-white shadow-lg">
                {recorded ? 'Update Decision' : 'Record Decision'}
              </Button>
            </div>
          </motion.div>
        </section>

        <section>
          <StepLabel number={2} label="Compare Buyers" />
          <motion.div variants={staggerContainer} initial="hidden" animate="show" className="mt-4 grid md:grid-cols-2 gap-4">
            {opportunities.map((o, i) => (
              <BuyerCard 
                key={o.buyer.id} 
                lot={lot}
                opportunity={o} 
                index={i} 
                isRecommended={o.buyer.id === recommendation.recommended_buyer_id} 
                onSaved={reload} 
              />
            ))}
          </motion.div>
        </section>
      </div>

      <NrpBreakdownModal opportunity={breakdown} open={!!breakdown} onClose={() => setBreakdown(null)} />
      <RecordDecisionModal open={recordOpen} onClose={() => setRecordOpen(false)} lot={lot} opportunities={opportunities} recommendation={recommendation} onRecorded={setRecorded} />
    </div>
  )
}

function StepLabel({ number, label }: { number: number; label: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-pine-500 text-sm font-black text-white shadow-inner">
        {number}
      </span>
      <h2 className="font-display text-xl font-bold text-ink">{label}</h2>
    </div>
  )
}

function BuyerCard({ lot, opportunity: o, index, isRecommended, onSaved }: { lot: any; opportunity: OpportunityResponse; index: number; isRecommended?: boolean; onSaved: () => void }) {
  const [open, setOpen] = useState(false)
  const leader = o.rank === 1
  const d = o.breakdown

  // Inline editing state
  const [isEditing, setIsEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    transport: d.transport_cost,
    loading: d.loading_cost,
    misc: d.misc_cost,
  })

  // Sync form when backend data changes
  useEffect(() => {
    setForm({
      transport: d.transport_cost,
      loading: d.loading_cost,
      misc: d.misc_cost,
    })
  }, [d])

  const handleSaveCosts = async () => {
    setSaving(true)
    try {
      await api.updateLot(lot.id, {
        baseline_transport_cost_per_q: form.transport,
        loading_cost_per_q: form.loading,
        miscellaneous_cost_per_q: form.misc,
      } as any)
      setIsEditing(false)
      onSaved()
    } catch (e) {
      alert("Failed to save costs")
    } finally {
      setSaving(false)
    }
  }

  return (
    <motion.div layout variants={fadeUp} custom={index} transition={{ ...rankLayout, delay: index * 0.04 }}
      className={cn('relative overflow-hidden rounded-3xl border bg-surface transition-all duration-300', leader ? 'border-pine-300 shadow-xl ring-1 ring-pine-500/10' : 'border-line shadow-sm hover:shadow-md hover:border-pine-200')}>
      {leader && <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-pine-400 to-pine-600" />}

      {isRecommended && (
        <div className="bg-pine-50 px-5 py-2 text-xs font-bold text-pine-700 uppercase tracking-wider flex items-center gap-2 border-b border-pine-100">
          <Sparkles size={14} /> AI Top Recommendation
        </div>
      )}

      <div className="p-5">
        <div className="flex items-start gap-4">
          <span className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl text-sm font-black shadow-inner', leader ? 'bg-pine-500 text-white' : 'bg-surface-sunk text-ink-3 ring-1 ring-inset ring-line')}>
            {leader ? <Crown size={16} /> : o.rank}
          </span>
          <div className="flex-1">
            <h3 className="font-display text-xl font-black text-ink">{o.buyer.name}</h3>
            <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs font-medium text-ink-3">
              <span className="inline-flex items-center gap-1"><MapPin size={13} /> {o.buyer.location} · {km(o.buyer.distance_km)}</span>
              <span className="inline-flex items-center gap-1"><Clock size={13} /> Pays in {days(o.buyer.payment_terms_days ?? 0)}</span>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-4">
          <div className="rounded-2xl bg-surface-sunken p-4 text-center border border-line/50">
            <p className="text-xs font-bold uppercase tracking-wider text-ink-3 mb-1">They Quote</p>
            <p className="font-display text-xl font-bold text-ink-3 line-through decoration-red-400 decoration-2">{perQt(o.breakdown.gross_price)}</p>
          </div>
          <div className={cn('rounded-2xl p-4 text-center border', leader ? 'bg-pine-50/50 border-pine-200 shadow-inner' : 'bg-surface border-line shadow-sm')}>
            <p className={cn('text-xs font-bold uppercase tracking-wider mb-1', leader ? 'text-pine-600' : 'text-ink-3')}>You Keep</p>
            <AnimatedNumber value={o.nrp_per_qt} format={perQt} className={cn('font-display text-2xl font-black tracking-tight', leader ? 'text-pine-700' : 'text-ink')} />
          </div>
        </div>

        <button onClick={() => setOpen(!open)} className="mt-4 flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-semibold text-ink-2 bg-surface-sunk hover:bg-surface-sunken transition-colors">
          View Calculation Breakdown
          <ChevronDown size={16} className={cn('transition-transform duration-300', open && 'rotate-180')} />
        </button>

        <AnimatePresence>
          {open && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="mt-2 rounded-2xl border border-line bg-white p-4">
                
                <div className="flex items-center justify-between mb-3 border-b border-line pb-2">
                  <span className="text-sm font-bold text-ink">Cost Breakdown</span>
                  {!isEditing ? (
                    <button onClick={() => setIsEditing(true)} className="flex items-center gap-1 text-xs font-bold text-pine-600 hover:text-pine-700 bg-pine-50 px-2 py-1 rounded-md">
                      <PenTool size={12} /> Edit Costs
                    </button>
                  ) : (
                    <button onClick={handleSaveCosts} disabled={saving} className="flex items-center gap-1 text-xs font-bold text-white bg-pine-600 hover:bg-pine-700 px-3 py-1 rounded-md transition-colors">
                      {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Save
                    </button>
                  )}
                </div>

                <table className="w-full text-sm font-medium">
                  <tbody className="divide-y divide-line/50">
                    <tr>
                      <td className="py-2.5 text-ink-2">Gross Price</td>
                      <td className="tnum py-2.5 text-right text-ink">{perQt(d.gross_price)}</td>
                    </tr>
                    
                    {/* Editable Transport */}
                    <tr>
                      <td className="py-2.5 text-ink-3">− Transport / Freight</td>
                      <td className="py-2.5 text-right text-red-600/80 tnum">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1 text-ink">
                            <span>₹</span>
                            <input 
                              type="number" 
                              value={form.transport} 
                              onChange={e => setForm(p => ({...p, transport: Number(e.target.value)}))}
                              className="w-16 rounded border-line px-1 py-0.5 text-right text-sm focus:border-pine-400 focus:ring-pine-400/20" 
                            />
                            <span className="text-xs text-ink-3">/qt</span>
                          </div>
                        ) : (
                          `− ${inr(d.transport_cost)}/qt`
                        )}
                      </td>
                    </tr>

                    {/* Editable Loading */}
                    <tr>
                      <td className="py-2.5 text-ink-3">− Loading & handling</td>
                      <td className="py-2.5 text-right text-red-600/80 tnum">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1 text-ink">
                            <span>₹</span>
                            <input 
                              type="number" 
                              value={form.loading} 
                              onChange={e => setForm(p => ({...p, loading: Number(e.target.value)}))}
                              className="w-16 rounded border-line px-1 py-0.5 text-right text-sm focus:border-pine-400 focus:ring-pine-400/20" 
                            />
                            <span className="text-xs text-ink-3">/qt</span>
                          </div>
                        ) : (
                          `− ${inr(d.loading_cost)}/qt`
                        )}
                      </td>
                    </tr>

                    {/* Non-editable Commission (computed dynamically) */}
                    {d.commission_amount > 0 && (
                      <tr>
                        <td className="py-2.5 text-ink-3">− Commission / Mandi fee</td>
                        <td className="tnum py-2.5 text-right text-red-600/80">− {inr(d.commission_amount)}/qt</td>
                      </tr>
                    )}
                    
                    {/* Non-editable Quality Deduction */}
                    {d.quality_deduction > 0 && (
                      <tr>
                        <td className="py-2.5 text-ink-3">− Quality deduction</td>
                        <td className="tnum py-2.5 text-right text-red-600/80">− {inr(d.quality_deduction)}/qt</td>
                      </tr>
                    )}

                    {/* Editable Misc Cost */}
                    <tr>
                      <td className="py-2.5 text-ink-3">− Other costs (Misc)</td>
                      <td className="py-2.5 text-right text-red-600/80 tnum">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1 text-ink">
                            <span>₹</span>
                            <input 
                              type="number" 
                              value={form.misc} 
                              onChange={e => setForm(p => ({...p, misc: Number(e.target.value)}))}
                              className="w-16 rounded border-line px-1 py-0.5 text-right text-sm focus:border-pine-400 focus:ring-pine-400/20" 
                            />
                            <span className="text-xs text-ink-3">/qt</span>
                          </div>
                        ) : (
                          `− ${inr(d.misc_cost)}/qt`
                        )}
                      </td>
                    </tr>

                    <tr className="border-t border-line font-black">
                      <td className="pt-3 text-pine-700">Net Realizable Price</td>
                      <td className="tnum pt-3 text-right text-pine-700">{perQt(o.nrp_per_qt)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}

function RadarSkeleton() {
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <Skeleton className="h-24 w-full rounded-3xl" />
      <Skeleton className="h-64 w-full rounded-3xl" />
      <div className="grid md:grid-cols-2 gap-4">
        <Skeleton className="h-64 w-full rounded-3xl" />
        <Skeleton className="h-64 w-full rounded-3xl" />
      </div>
    </div>
  )
}
