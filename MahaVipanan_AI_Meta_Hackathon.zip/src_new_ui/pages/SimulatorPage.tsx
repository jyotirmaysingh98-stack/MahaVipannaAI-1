import { useLang } from '@/features/agrivault/lib/LangContext'
import { DashboardHero, HERO_IMAGES } from '@/features/agrivault/components/DashboardHero'
import { WhatIfForm } from '@/features/agrivault/components/WhatIfForm'

/** What-If simulator page — shared across all roles. */
export function Simulator() {
  const { t } = useLang()
  return (
    <div>
      <DashboardHero
        image={HERO_IMAGES.simulator}
        eyebrow={t('postHarvest')}
        title={t('whatIfSimulation')}
        description={t('simDesc')}
      />
      <WhatIfForm />
    </div>
  )
}
