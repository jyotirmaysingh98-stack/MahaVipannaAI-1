import { useState } from 'react'
import { TrendingUp } from 'lucide-react'
import { NegotiationMeter } from '@/components/radar/NegotiationMeter'
import { Field } from '@/components/ui/Field'
import { useI18n } from '@/lib/i18n'

export function FarmerNegotiations() {
  const { t } = useI18n()
  const [msp, setMsp] = useState(1800)
  const [isp, setIsp] = useState(1950)
  const currentOffer = 1750
  
  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-ink">{t('nav.negotiations') || 'Negotiations'}</h1>
        <p className="mt-1 text-ink-2">Manage your ongoing negotiations and set price thresholds.</p>
      </div>

      <div className="space-y-4 rounded-2xl glass p-6 shadow-sm border border-line">
        <h2 className="font-display text-xl font-semibold text-ink">{t('farmer.activeNegotiation')}</h2>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <Field 
            label={t('farmer.msp')}
            type="number" 
            value={msp} 
            onChange={(e) => setMsp(Number(e.target.value) || 0)} 
          />
          <Field 
            label={t('farmer.isp')}
            type="number"
            value={isp} 
            onChange={(e) => setIsp(Number(e.target.value) || 0)} 
          />
        </div>
        
        <div className="mt-8">
          <NegotiationMeter currentOffer={currentOffer} minimumSellingPrice={msp} idealSellingPrice={isp} />
        </div>
        
      </div>
      
      <div className="mt-8 space-y-4">
        <h2 className="font-display text-xl font-semibold text-ink">{t('farmer.alerts')}</h2>
        <div className="rounded-2xl border border-pine-600/20 bg-pine-600/10 p-6 flex gap-4">
          <TrendingUp className="text-pine-600 shrink-0 mt-1" />
          <div>
            <h3 className="font-semibold text-pine-600">{t('farmer.alertTitle')}</h3>
            <p className="text-sm text-ink-2 mt-1">{t('farmer.alertDesc')}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
