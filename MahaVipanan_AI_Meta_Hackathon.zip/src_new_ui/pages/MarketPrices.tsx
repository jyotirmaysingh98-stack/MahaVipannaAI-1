import { DashboardHero, HERO_IMAGES, SectionHeading } from '@/features/agrivault/components/DashboardHero'
import { RateTicker } from '@/features/market/components/RateTicker'
import { LiveRatesBoard } from '@/features/market/components/LiveRatesBoard'
import { PriceComparison } from '@/features/market/components/PriceComparison'
import { useLiveRates } from '@/features/market/lib/useLiveRates'

/**
 * Market Rates — a single hub with two sections:
 *   1. Live Trade & Market Rates (a ticking board of mandi/APMC rates)
 *   2. Price Comparison (each buyer's offer vs the live market rate)
 * One shared live feed powers both so they stay in sync.
 */
export function MarketRatesPage() {
  const feed = useLiveRates()

  return (
    <div>
      <DashboardHero
        image={HERO_IMAGES.market}
        eyebrow="Market Intelligence"
        title="Live Market Rates"
        description="Live mandi & APMC rates across key commodities — and how every buyer's offer compares to the going market price."
        langToggle={false}
      />

      <div className="mb-8">
        <RateTicker rates={feed.rates} live={feed.live} />
      </div>

      <SectionHeading>Live Trade &amp; Market Rates</SectionHeading>
      <div className="mb-10">
        <LiveRatesBoard feed={feed} />
      </div>

      <SectionHeading>Price Comparison — Market vs Buyer Offers</SectionHeading>
      <PriceComparison rates={feed.rates} />
    </div>
  )
}
