import { apiClient } from './client'
import { TrackDeliveryResponse } from './types'

export const deliveryApi = {
  trackDelivery: async (trackingId: string) => {
    return apiClient<TrackDeliveryResponse>(`/delivery/track/${trackingId}`, { method: 'GET' })
  },
  
  updateStatus: async (trackingId: string, status: string, note?: string) => {
    return apiClient<any>(`/delivery/${trackingId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, note })
    })
  }
}
