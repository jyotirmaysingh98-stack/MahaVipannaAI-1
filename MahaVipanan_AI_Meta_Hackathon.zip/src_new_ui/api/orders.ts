import { apiClient } from './client'
import { OrderCreatePayload, OrderWithTracking } from './types'

export const ordersApi = {
  createOrder: async (payload: OrderCreatePayload) => {
    return apiClient<{ data: any, tracking_id: string }>('/orders/', {
      method: 'POST',
      body: JSON.stringify(payload)
    })
  },

  getOrders: async () => {
    return apiClient<OrderWithTracking[]>('/orders/', { method: 'GET' })
  },
}
