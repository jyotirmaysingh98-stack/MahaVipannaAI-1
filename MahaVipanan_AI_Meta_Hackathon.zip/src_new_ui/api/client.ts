import {
  ApiEnvelope,
  FpoDashboard,
  LotResponse,
  LotCreatePayload,
  OpportunitiesData,
  RecalculatePayload,
  WarehouseItem,
  AnalyticsData,
  HistoryItem,
  FarmerLot,
  Counterparty,
  NegotiationOrder,
  NegotiationAiSuggestion,
  GovernmentScheme,
  SchemeSource,
  OrderSummary,
  OrderTrackingPoint
} from './types'

// Use environment variable or fallback to localhost for development
const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000'

class ApiError extends Error {
  constructor(public message: string, public status?: number) {
    super(message)
    this.name = 'ApiError'
  }
}

export async function apiClient<T>(endpoint: string, options?: RequestInit): Promise<ApiEnvelope<T>> {
  const url = `${BASE_URL}${endpoint}`
  
  try {
    const token = sessionStorage.getItem('mv.auth.token')

    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        ...(options?.headers || {})
      }
    })

    const data = await response.json()

    if (!response.ok || !data.success) {
      throw new ApiError(data.error || 'An error occurred', response.status)
    }

    return data as ApiEnvelope<T>
  } catch (error) {
    if (error instanceof ApiError) throw error
    throw new ApiError('Network error or backend unavailable')
  }
}

export const api = {
  getDashboard: () => apiClient<FpoDashboard>('/api/fpo/dashboard'),
  
  getFpoWarehouse: () => apiClient<WarehouseItem[]>('/api/fpo/warehouse'),
  getFpoAnalytics: () => apiClient<AnalyticsData>('/api/fpo/analytics'),
  getFpoHistory: () => apiClient<HistoryItem[]>('/api/fpo/history'),

  submitFeedback: (payload: { from_user_id: string; order_id?: string; rating: number; comments?: string }) =>
    apiClient<{ id: string; rating: number; comments: string; created_at: string }>('/api/feedback', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  getFeedback: (userId?: string, orderId?: string) => {
    const params = new URLSearchParams()
    if (userId) params.append('user_id', userId)
    if (orderId) params.append('order_id', orderId)
    return apiClient<any[]>(`/api/feedback?${params.toString()}`)
  },

  getFarmerLots: () => apiClient<FarmerLot[]>('/api/farmer/lots'),
  getFarmerAnalytics: () => apiClient<AnalyticsData>('/api/farmer/analytics'),
  getFarmerHistory: () => apiClient<HistoryItem[]>('/api/farmer/history'),
  
  getLots: () => apiClient<LotResponse[]>('/api/lots/'),
  
  getLot: (id: string) => apiClient<LotResponse>(`/api/lots/${id}`),
  
  createLot: (payload: LotCreatePayload) => 
    apiClient<LotResponse>('/api/lots/', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
    
  updateLot: (id: string, payload: { expected_price_per_q?: number, baseline_transport_cost_per_q?: number, loading_cost_per_q?: number, miscellaneous_cost_per_q?: number }) =>
    apiClient<LotResponse>(`/api/lots/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    }),
    
  getFpoInventory: () => apiClient<LotResponse[]>('/api/lots/fpo/inventory'),
  getFpoOffers: () => apiClient<LotResponse[]>('/api/lots/fpo/offers'),
    
  getOpportunities: (lotId: string) => 
    apiClient<OpportunitiesData>(`/api/opportunities/${lotId}`),
    
  recalculateFreight: (lotId: string, payload: RecalculatePayload) =>
    apiClient<OpportunitiesData>(`/api/opportunities/${lotId}/recalculate`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),



  login: (payload: any) => apiClient<any>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),

  signup: (payload: any) => apiClient<any>('/api/auth/signup', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),

  deleteLot: (id: string) => apiClient<any>(`/api/lots/${id}`, { method: 'DELETE' }),

  sendMessage: (message: string, lang?: string) => apiClient<{reply: string}>('/api/chat/message', {
    method: 'POST',
    body: JSON.stringify({ message, lang })
  }),

  // --- Negotiations ---
  listNegotiations: () => apiClient<NegotiationOrder[]>('/api/negotiations'),
  getNegotiation: (id: string) => apiClient<NegotiationOrder>(`/api/negotiations/${id}`),
  listCounterparties: (role: string) => apiClient<Counterparty[]>(`/api/negotiations/counterparties?role=${role}`),
  createNegotiation: (payload: { counterparty_user_id: string; crop_name: string; quantity_q: number; offer_price_per_q: number }) =>
    apiClient<NegotiationOrder>('/api/negotiations', { method: 'POST', body: JSON.stringify(payload) }),
  counterNegotiation: (orderId: string, payload: { price_per_q: number; message?: string }) =>
    apiClient<NegotiationOrder>(`/api/negotiations/${orderId}/counter`, { method: 'POST', body: JSON.stringify(payload) }),
  acceptNegotiation: (orderId: string) => apiClient<NegotiationOrder>(`/api/negotiations/${orderId}/accept`, { method: 'POST' }),
  rejectNegotiation: (orderId: string) => apiClient<NegotiationOrder>(`/api/negotiations/${orderId}/reject`, { method: 'POST' }),
  aiAssistNegotiation: (orderId: string, payload: { minimum_selling_price?: number; ideal_selling_price?: number; lang?: string }) =>
    apiClient<NegotiationAiSuggestion>(`/api/negotiations/${orderId}/ai-assist`, { method: 'POST', body: JSON.stringify(payload) }),

  // --- Government schemes ---
  listSchemes: (params?: { state?: string; crop?: string }) => {
    const qs = new URLSearchParams(params as any).toString()
    return apiClient<GovernmentScheme[]>(`/api/schemes/${qs ? `?${qs}` : ''}`)
  },
  createScheme: (payload: Partial<GovernmentScheme>) => apiClient<GovernmentScheme>('/api/schemes/', { method: 'POST', body: JSON.stringify(payload) }),
  updateScheme: (id: string, payload: Partial<GovernmentScheme>) => apiClient<GovernmentScheme>(`/api/schemes/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  getSchemeSources: () => apiClient<SchemeSource[]>('/api/schemes/sources'),
  syncSchemeSources: () => apiClient<{ sources: any[]; synced_at: string | null }>('/api/schemes/sync', { method: 'POST' }),

  // --- Orders / tracking ---
  listOrders: () => apiClient<OrderSummary[]>('/api/orders/'),
  getOrders: () => apiClient<any[]>('/api/orders/'),
  getOrderById: (orderId: string) => apiClient<any>(`/api/orders/${orderId}`),
  updateOrderInstructions: (orderId: string, special_instructions: string) =>
    apiClient<any>(`/api/orders/${orderId}/instructions`, {
      method: 'PUT',
      body: JSON.stringify({ special_instructions })
    }),
  updateOrderStatus: (orderId: string, payload: { status: string; location_name?: string; latitude?: number; longitude?: number; notes?: string }) =>
    apiClient<any>(`/api/orders/${orderId}/status`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  getOrderTracking: (orderId: string) => apiClient<OrderTrackingPoint[]>(`/api/orders/${orderId}/tracking`),
  advanceDemoTracking: (orderId: string) => apiClient<OrderTrackingPoint>(`/api/orders/${orderId}/tracking/advance-demo`, { method: 'POST' })
}
