import { LayoutDashboard, Layers, Menu, LogOut, X, Truck, Moon, Sun, Package, BarChart3, History, MessageSquare, Activity, Handshake, Landmark, MapPin } from 'lucide-react'

import { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { cn } from '@/lib/cn'
import { useApp, type UserRole } from '@/state/AppContext'
import { useI18n } from '@/lib/i18n'
import { useTheme } from '@/state/ThemeProvider'
import { Logo } from '@/components/brand/Logo'
import { Button } from '@/components/ui/Button'
import { LanguageSelector } from '@/components/ui/LanguageSelector'

const getRoleNav = (role: UserRole) => {
  switch (role) {
    case 'farmer':
      return [
        { to: '/app/farmer', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/farmer/lots', labelKey: 'nav.lots', icon: Layers, end: false },
        { to: '/app/tracking', labelKey: 'nav.deliveries', icon: MapPin, end: false },
        { to: '/app/farmer/negotiations', labelKey: 'nav.negotiations', icon: Handshake, end: false },
        { to: '/app/market', labelKey: 'nav.marketPrices', icon: Activity, end: false },
        { to: '/app/simulator', labelKey: 'nav.simulator', icon: Activity, end: false },
        { to: '/app/analytics', labelKey: 'nav.analytics', icon: BarChart3, end: false },
        { to: '/app/history', labelKey: 'nav.history', icon: History, end: false },
        { to: '/app/feedback', labelKey: 'nav.feedback', icon: MessageSquare, end: false },
      ]
    case 'buyer':
      return [
        { to: '/app/buyer', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/tracking', labelKey: 'nav.deliveries', icon: MapPin, end: false },
        { to: '/app/buyer/negotiations', labelKey: 'nav.negotiations', icon: Handshake, end: false },
        { to: '/app/market', labelKey: 'nav.marketPrices', icon: Activity, end: false },
      ]
    case 'delivery':
      return [
        { to: '/app/delivery', labelKey: 'nav.dashboard', icon: Truck, end: true },
        { to: '/app/tracking', labelKey: 'nav.deliveries', icon: MapPin, end: false },
      ]
    case 'admin':
      return [
        { to: '/app/admin', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/tracking', labelKey: 'nav.deliveries', icon: MapPin, end: false },
        { to: '/app/feedback', labelKey: 'nav.feedback', icon: MessageSquare, end: false },
      ]
    case 'government':
      return [
        { to: '/app/government', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/government/schemes', labelKey: 'nav.schemes', icon: Landmark, end: false },
        { to: '/app/market', labelKey: 'nav.marketPrices', icon: Activity, end: false },
      ]
    case 'fpo':
    default:
      return [
        { to: '/app/fpo', labelKey: 'nav.dashboard', icon: LayoutDashboard, end: true },
        { to: '/app/fpo/lots', labelKey: 'nav.lots', icon: Layers, end: false },
        { to: '/app/fpo/orders', labelKey: 'nav.deliveries', icon: Truck, end: false },
        { to: '/app/tracking', labelKey: 'nav.tracking', icon: MapPin, end: false },
        { to: '/app/fpo/negotiations', labelKey: 'nav.negotiations', icon: Handshake, end: false },
        { to: '/app/warehouse', labelKey: 'nav.warehouse', icon: Package, end: false },
        { to: '/app/market', labelKey: 'nav.marketPrices', icon: Activity, end: false },
        { to: '/app/simulator', labelKey: 'nav.simulator', icon: Activity, end: false },
        { to: '/app/analytics', labelKey: 'nav.analytics', icon: BarChart3, end: false },
        { to: '/app/history', labelKey: 'nav.history', icon: History, end: false },
        { to: '/app/feedback', labelKey: 'nav.feedback', icon: MessageSquare, end: false },
      ]
  }
}


function NavItem({ to, labelKey, icon: Icon, end }: any) {
  const { t } = useI18n()
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'group relative shrink-0 flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors',
          isActive ? 'text-pine-700' : 'text-ink-2 hover:text-ink',
        )
      }
    >
      {({ isActive }) => (
        <>
          <Icon size={18} strokeWidth={2} className={cn('shrink-0', isActive ? 'text-pine-500' : 'text-ink-3')} />
          <span className="inline-block">{t(labelKey as any)}</span>
          {isActive && <span className="absolute inset-x-2 -bottom-[13px] h-0.5 rounded-full bg-pine-500" />}
        </>
      )}
    </NavLink>
  )
}

export function TopNav() {
  const { fpo, role, logout } = useApp()
  const { t } = useI18n()
  const { theme, setTheme } = useTheme()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  const navItems = getRoleNav(role)

  const onLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="sticky top-0 z-40 border-b border-line/80 bg-paper/80 backdrop-blur-xl">
      <div className="mx-auto flex min-h-16 items-center justify-between gap-4 px-4 sm:px-6 max-w-[1400px]">
        <NavLink to={`/app/${role || 'fpo'}`} className="shrink-0" aria-label="MahaVipanan AI — Dashboard">
          <Logo size={38} />
        </NavLink>

        <nav className="hidden flex-1 items-center justify-start gap-1 md:flex overflow-x-auto whitespace-nowrap px-2 no-scrollbar">
          {navItems.map((item) => (
            <NavItem key={item.to} {...item} />
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <LanguageSelector className="hidden md:block" />

          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="hidden h-10 w-10 place-items-center rounded-xl text-ink-3 transition-colors hover:bg-black/5 hover:text-ink md:grid"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          <div className="hidden text-right lg:block">
            <p className="text-sm font-semibold leading-tight text-ink uppercase tracking-wider">{role || 'FPO'}</p>
            <p className="text-xs leading-tight text-ink-3">
              {role === 'fpo' && fpo ? fpo.name : 'MahaVipanan AI'}
            </p>
          </div>
          <button
            onClick={onLogout}
            className="hidden h-10 w-10 place-items-center rounded-xl text-ink-3 transition-colors hover:bg-black/5 hover:text-ink md:grid"
            aria-label="Sign out"
            title="Sign out"
          >
            <LogOut size={18} />
          </button>
          <button
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-xl text-ink-2 hover:bg-black/5 md:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-paper px-4 py-3 md:hidden">
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium',
                    isActive ? 'bg-pine-50 text-pine-700' : 'text-ink-2',
                  )
                }
              >
                <item.icon size={17} />
                {t(item.labelKey as any)}
              </NavLink>
            ))}
            <div className="flex gap-2 mt-2">
              <Button variant="ghost" className="justify-start flex-1" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
                {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />} Theme
              </Button>
              <Button variant="ghost" className="justify-start flex-1" onClick={onLogout}>
                <LogOut size={17} /> {t('nav.logout')}
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
