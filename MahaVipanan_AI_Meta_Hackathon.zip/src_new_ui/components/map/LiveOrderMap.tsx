import { useState, useEffect, useRef } from 'react'
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import {
  Phone, CheckCircle2, Clock,
  FileText, Save, RefreshCw, Play, Pause, RotateCcw, FastForward, Timer, Package, Truck, ShieldCheck
} from 'lucide-react'
import { api } from '@/api/client'

// Custom Leaflet DivIcons
const createCustomIcon = (colorBg: string, iconSymbol: string, pulse: boolean = false) => {
  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div style="
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        ${pulse ? `<div style="
          position: absolute;
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: ${colorBg};
          opacity: 0.35;
          animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
        "></div>` : ''}
        <div style="
          background: ${colorBg};
          color: white;
          width: 38px;
          height: 38px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 14px rgba(0,0,0,0.35);
          border: 2px solid white;
          font-weight: bold;
          font-size: 16px;
          position: relative;
          z-index: 10;
        ">
          ${iconSymbol}
        </div>
      </div>
    `,
    iconSize: [38, 38],
    iconAnchor: [19, 19],
    popupAnchor: [0, -20]
  })
}

const pickupIcon = createCustomIcon('#059669', '🌾')
const transitIcon = createCustomIcon('#2563eb', '🚚', true)
const destinationIcon = createCustomIcon('#dc2626', '📍')

export interface OrderData {
  id: string
  crop_name: string
  status: string
  agreed_price_per_q: number
  quantity_q: number
  total_value: number
  tracking_number: string
  special_instructions?: string
  pickup_location: string
  delivery_location: string
  pickup_lat: number
  pickup_lng: number
  delivery_lat: number
  delivery_lng: number
  recipient_name: string
  recipient_phone: string
  verification_tier: string
  verification_status: string
  farmer_name?: string
  buyer_name?: string
}

const DEMO_ORDER_DEFAULT: OrderData = {
  id: 'order-demo-001',
  tracking_number: 'MV-DEMO-001',
  crop_name: 'Grade A Nashik Onions',
  quantity_q: 100,
  agreed_price_per_q: 1850,
  total_value: 185000,
  status: 'in_transit',
  pickup_location: 'Nashik Farmer Co-op Warehouse Hub, Maharashtra',
  delivery_location: 'Vashi APMC Produce Terminal, Navi Mumbai',
  pickup_lat: 20.0063,
  pickup_lng: 73.7902,
  delivery_lat: 19.0760,
  delivery_lng: 72.9984,
  recipient_name: 'Shri Suresh Mehta (Mumbai Wholesale Corp)',
  recipient_phone: '+91 98200 44552',
  verification_tier: 'verified_fpo',
  verification_status: 'verified',
  farmer_name: 'Shri Ramesh Patil (Nashik FPO)',
  buyer_name: 'Mumbai Wholesale Corp',
  special_instructions: 'Unload at Bay 3. Handle ventilated crates carefully. Verify moisture sensor seal on arrival.'
}

const TIMELINE_STAGES = [
  { key: 'CONFIRMED', label: 'Order Confirmed', icon: FileText, threshold: 0 },
  { key: 'PICKUP_SCHEDULED', label: 'Pickup Scheduled', icon: Clock, threshold: 0.1 },
  { key: 'PICKED_UP', label: 'Picked Up from Warehouse', icon: Package, threshold: 0.25 },
  { key: 'IN_TRANSIT', label: 'In Transit along Route Corridor', icon: Truck, threshold: 0.5 },
  { key: 'NEAR_DESTINATION', label: 'Near Destination Terminal', icon: ShieldCheck, threshold: 0.85 },
  { key: 'DELIVERED', label: 'Delivered & Accepted', icon: CheckCircle2, threshold: 1.0 },
]

// Fixed deterministic route coordinates: Nashik -> Igatpuri -> Kasara -> Thane -> Vashi
const FIXED_ROUTE_POINTS: [number, number][] = [
  [20.0063, 73.7902],
  [19.7042, 73.5532],
  [19.5312, 73.4839],
  [19.2183, 72.9781],
  [19.0760, 72.9984]
]

interface LiveOrderMapProps {
  orderId?: string
  userRole?: 'delivery' | 'buyer' | 'farmer' | 'fpo' | 'admin' | null
  onOrderUpdated?: () => void
}

function MapBoundsFitter({ points }: { points: [number, number][] }) {
  const map = useMap()
  const fittedRef = useRef(false)

  useEffect(() => {
    if (points.length > 0 && !fittedRef.current) {
      fittedRef.current = true
      try {
        const bounds = L.latLngBounds(points.map(p => L.latLng(p[0], p[1])))
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 12 })
      } catch (e) {
        console.error('Error fitting bounds', e)
      }
    }
  }, [points, map])
  return null
}

export function LiveOrderMap({ orderId, userRole = 'farmer', onOrderUpdated }: LiveOrderMapProps) {
  const [orders, setOrders] = useState<OrderData[]>([])
  const [selectedOrder, setSelectedOrder] = useState<OrderData>(DEMO_ORDER_DEFAULT)
  const [loading, setLoading] = useState(true)
  const [instructionsInput, setInstructionsInput] = useState('')
  const [isSavingInstructions, setIsSavingInstructions] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)

  // Simulation Controls & State
  const [isSimulating, setIsSimulating] = useState(false)
  const [simProgress, setSimProgress] = useState(0.4) // 0.0 to 1.0
  const [speedKmh, setSpeedKmh] = useState(45)
  const simTimerRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    loadOrders()
  }, [orderId])

  // Timer lifecycle management — cleanly clears interval on unmount or pause
  useEffect(() => {
    const clearTimer = () => {
      if (simTimerRef.current) {
        clearInterval(simTimerRef.current)
        simTimerRef.current = null
      }
    }
    if (isSimulating) {
      simTimerRef.current = setInterval(() => {
        setSimProgress((prev) => {
          if (prev >= 0.98) {
            setIsSimulating(false)
            return 1.0
          }
          setSpeedKmh(Math.floor(40 + Math.random() * 8))
          return Math.min(1.0, prev + 0.02)
        })
      }, 800)
    } else {
      clearTimer()
    }
    return clearTimer
  }, [isSimulating])

  const loadOrders = async () => {
    try {
      setLoading(true)
      const res = await api.getOrders()
      const orderList: OrderData[] = (res.success && Array.isArray(res.data)) ? res.data : []
      const target = orderList.length > 0
        ? (orderId ? orderList.find((o: OrderData) => o.id === orderId) || orderList[0] : orderList[0])
        : DEMO_ORDER_DEFAULT
      if (orderList.length > 0) setOrders(orderList)
      setSelectedOrder(target)
      setInstructionsInput(target.special_instructions || DEMO_ORDER_DEFAULT.special_instructions!)
    } catch (e) {
      console.error('Failed to load orders for map', e)
      setSelectedOrder(DEMO_ORDER_DEFAULT)
      setInstructionsInput(DEMO_ORDER_DEFAULT.special_instructions!)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveInstructions = async () => {
    if (!selectedOrder) return
    try {
      setIsSavingInstructions(true)
      await api.updateOrderInstructions(selectedOrder.id, instructionsInput)
      setSaveSuccess(true)
      setTimeout(() => setSaveSuccess(false), 3000)
      if (onOrderUpdated) onOrderUpdated()
    } catch (e) {
      console.error('Failed to save instructions', e)
    } finally {
      setIsSavingInstructions(false)
    }
  }

  const handleStartSimulation = () => {
    if (simProgress >= 1.0) setSimProgress(0.0)
    setIsSimulating(true)
  }

  const handlePauseSimulation = () => {
    setIsSimulating(false)
  }

  const handleResetSimulation = () => {
    setIsSimulating(false)
    setSimProgress(0.0)
    setSpeedKmh(45)
  }

  const handleNextStep = () => {
    setSimProgress((prev) => {
      if (prev < 0.25) return 0.25
      if (prev < 0.5) return 0.5
      if (prev < 0.85) return 0.85
      return 1.0
    })
  }

  if (loading) {
    return (
      <div className="rounded-3xl border border-line bg-surface p-12 text-center shadow-card">
        <RefreshCw size={32} className="mx-auto text-pine-600 animate-spin mb-3" />
        <p className="text-sm font-semibold text-ink">Loading simulated tracking route...</p>
      </div>
    )
  }

  const pickupCoords: [number, number] = [selectedOrder.pickup_lat || FIXED_ROUTE_POINTS[0][0], selectedOrder.pickup_lng || FIXED_ROUTE_POINTS[0][1]]
  const deliveryCoords: [number, number] = [selectedOrder.delivery_lat || FIXED_ROUTE_POINTS[4][0], selectedOrder.delivery_lng || FIXED_ROUTE_POINTS[4][1]]

  // Interpolate current vehicle coordinates along deterministic route
  const currentTransitCoords: [number, number] = [
    pickupCoords[0] + (deliveryCoords[0] - pickupCoords[0]) * simProgress,
    pickupCoords[1] + (deliveryCoords[1] - pickupCoords[1]) * simProgress
  ]

  const totalDistanceKm = 145
  const remainingDistanceKm = Math.max(0, Math.round(totalDistanceKm * (1 - simProgress) * 10) / 10)
  const remainingMinutes = Math.max(0, Math.round((remainingDistanceKm / (speedKmh || 45)) * 60))

  const arrivalTime = new Date()
  arrivalTime.setMinutes(arrivalTime.getMinutes() + remainingMinutes)
  const formattedArrivalTime = arrivalTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

  const routePolyline: [number, number][] = [
    pickupCoords,
    currentTransitCoords,
    deliveryCoords
  ]

  // Determine active stage label
  const activeStageLabel = [...TIMELINE_STAGES].reverse().find(s => simProgress >= s.threshold)?.label || 'Order Confirmed'

  return (
    <div className="rounded-3xl border border-line bg-surface shadow-card overflow-hidden">
      {/* Simulation Header & Controls */}
      <div className="border-b border-line bg-surface-sunk/40 p-4 sm:p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
              Demo Delivery Simulation
            </span>
            <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800">
              [DEMO SIMULATION]
            </span>
          </div>
          <h2 className="mt-1 font-display text-xl font-bold text-ink flex items-center gap-2">
            <span>{selectedOrder.tracking_number}</span>
            <span className="text-sm font-normal text-ink-3">({selectedOrder.crop_name} — {selectedOrder.quantity_q} Quintals)</span>
          </h2>
        </div>

        {/* Simulation Controls: Start / Pause / Reset / Next Step */}
        <div className="flex flex-wrap items-center gap-2">
          {!isSimulating ? (
            <button
              onClick={handleStartSimulation}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-1.5"
            >
              <Play size={14} />
              <span>{simProgress >= 1.0 ? 'Replay Simulation' : 'Start Simulation'}</span>
            </button>
          ) : (
            <button
              onClick={handlePauseSimulation}
              className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-1.5 animate-pulse"
            >
              <Pause size={14} />
              <span>Pause</span>
            </button>
          )}

          <button
            onClick={handleNextStep}
            disabled={simProgress >= 1.0}
            className="px-3 py-2 rounded-xl bg-surface border border-line hover:bg-surface-sunk text-ink text-xs font-semibold shadow-sm transition-all flex items-center gap-1 disabled:opacity-50"
            title="Advance to next status stage"
          >
            <FastForward size={14} />
            <span>Next Step</span>
          </button>

          <button
            onClick={handleResetSimulation}
            className="px-3 py-2 rounded-xl bg-surface border border-line hover:bg-surface-sunk text-ink-2 text-xs font-semibold shadow-sm transition-all flex items-center gap-1"
            title="Reset simulation to origin"
          >
            <RotateCcw size={14} />
            <span>Reset</span>
          </button>

          {orders.length > 1 && (
            <div className="flex items-center gap-1.5 ml-2">
              <select
                value={selectedOrder.id}
                onChange={(e) => {
                  const found = orders.find(o => o.id === e.target.value)
                  if (found) {
                    setSelectedOrder(found)
                    setInstructionsInput(found.special_instructions || '')
                    setSimProgress(found.status === 'delivered' ? 1.0 : (found.status === 'pickup' ? 0.05 : 0.4))
                  }
                }}
                className="text-xs font-medium rounded-xl border border-line bg-surface px-3 py-2 text-ink outline-none focus:border-pine-500"
              >
                {orders.map(o => (
                  <option key={o.id} value={o.id}>
                    {o.tracking_number} ({o.crop_name})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Dynamic Simulation Metrics Banner */}
      <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center text-white shrink-0 border border-white/20">
            <Timer size={24} className="animate-spin-slow" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-100">
              Estimated Delivery Arrival (Simulated)
            </span>
            <div className="text-xl sm:text-2xl font-display font-extrabold flex items-center gap-2 text-white">
              <span>{simProgress >= 1 ? '🎉 Arrived & Delivered' : `Arriving in ~${remainingMinutes} mins`}</span>
              {simProgress < 1 && (
                <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-white/20 text-emerald-50">
                  (by {formattedArrivalTime})
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div className="text-right">
            <span className="text-[10px] text-emerald-100 uppercase tracking-wider block">Status</span>
            <span className="font-bold text-sm text-white">{activeStageLabel}</span>
          </div>
          <div className="h-8 w-px bg-white/20" />
          <div className="text-right">
            <span className="text-[10px] text-emerald-100 uppercase tracking-wider block">Distance Remaining</span>
            <span className="font-bold text-base text-white">{simProgress >= 1 ? '0.0 km' : `~${remainingDistanceKm} km`}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Leaflet Map & Simulated Order Tracking Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
        {/* Leaflet Simulated Route Map */}
        <div className="lg:col-span-7 h-[400px] sm:h-[480px] relative z-10 border-b lg:border-b-0 lg:border-r border-line">
          <MapContainer
            center={currentTransitCoords}
            zoom={8}
            scrollWheelZoom={false}
            className="h-full w-full"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            <MapBoundsFitter points={[pickupCoords, deliveryCoords]} />

            {/* Pickup Marker */}
            <Marker position={pickupCoords} icon={pickupIcon}>
              <Popup>
                <div className="p-1">
                  <strong className="text-emerald-700 block text-xs uppercase font-bold">🌾 Origin (Pickup Warehouse)</strong>
                  <p className="text-xs text-slate-800 font-medium mt-0.5">{selectedOrder.pickup_location}</p>
                  <p className="text-[11px] text-slate-500">Shipper: {selectedOrder.farmer_name || 'Nashik Farmer Co-op'}</p>
                </div>
              </Popup>
            </Marker>

            {/* Simulated Vehicle Courier Marker */}
            <Marker position={currentTransitCoords} icon={transitIcon}>
              <Popup>
                <div className="p-1">
                  <strong className="text-blue-700 block text-xs uppercase font-bold">🚚 MahaVipanan Demo Courier</strong>
                  <p className="text-xs text-slate-800 font-medium mt-0.5">
                    {simProgress >= 1 ? 'Delivered' : `Simulated Position (~${remainingDistanceKm} km remaining)`}
                  </p>
                  <p className="text-[11px] text-slate-500">Speed: {speedKmh} km/h (Demo Simulation)</p>
                </div>
              </Popup>
            </Marker>

            {/* Destination Marker */}
            <Marker position={deliveryCoords} icon={destinationIcon}>
              <Popup>
                <div className="p-1">
                  <strong className="text-red-700 block text-xs uppercase font-bold">📍 Destination (Terminal)</strong>
                  <p className="text-xs text-slate-800 font-medium mt-0.5">{selectedOrder.delivery_location}</p>
                  <p className="text-[11px] text-slate-500">Recipient: {selectedOrder.recipient_name}</p>
                </div>
              </Popup>
            </Marker>

            {/* Simulated Polyline Route */}
            <Polyline
              positions={routePolyline}
              color="#059669"
              weight={4}
              opacity={0.8}
              dashArray="6, 8"
            />
          </MapContainer>
        </div>

        {/* Order Tracking Information Panel & Timeline Checklist */}
        <div className="lg:col-span-5 p-5 sm:p-6 space-y-4 bg-surface flex flex-col justify-between overflow-y-auto">
          <div className="space-y-4">
            {/* Demo Simulation Badge */}
            <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 p-3 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-300">
                <ShieldCheck size={16} className="text-amber-600" />
                <span>Demo Delivery Simulation</span>
              </div>
              <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-amber-200 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200">
                SIH Demo
              </span>
            </div>

            {/* Order Details Breakdown */}
            <div className="rounded-2xl border border-line bg-surface-sunk/50 p-4 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-ink-3">Order Number:</span>
                <span className="font-mono font-bold text-ink">{selectedOrder.tracking_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-3">Product:</span>
                <span className="font-bold text-ink">{selectedOrder.crop_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-3">Quantity:</span>
                <span className="font-semibold text-ink">{selectedOrder.quantity_q} Quintals ({selectedOrder.quantity_q * 100} kg)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-3">From:</span>
                <span className="font-medium text-ink text-right max-w-[200px] truncate">{selectedOrder.pickup_location}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-3">To:</span>
                <span className="font-medium text-ink text-right max-w-[200px] truncate">{selectedOrder.delivery_location}</span>
              </div>
            </div>

            {/* Status Timeline Checklist */}
            <div className="rounded-2xl border border-line bg-surface p-4 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-ink-3 mb-2">Delivery Progression Timeline</h4>
              <div className="space-y-2.5">
                {TIMELINE_STAGES.map((stage, idx) => {
                  const isPassed = simProgress >= stage.threshold
                  const nextThreshold = TIMELINE_STAGES[idx + 1]?.threshold ?? 1.1
                  const isCurrent = isPassed && (stage.threshold === 1.0 ? simProgress === 1.0 : simProgress < nextThreshold)
                  const StageIcon = stage.icon

                  return (
                    <div key={stage.key} className="flex items-center gap-3 text-xs">
                      <div className={`h-6 w-6 rounded-full flex items-center justify-center shrink-0 ${
                        isPassed
                          ? 'bg-emerald-600 text-white'
                          : isCurrent
                          ? 'bg-blue-600 text-white animate-pulse'
                          : 'bg-surface-sunk text-ink-3 border border-line'
                      }`}>
                        {isPassed ? <CheckCircle2 size={13} /> : <StageIcon size={12} />}
                      </div>
                      <div className="flex-1 flex items-center justify-between">
                        <span className={`font-semibold ${isPassed ? 'text-ink' : 'text-ink-3'}`}>
                          {stage.label}
                        </span>
                        {isPassed && <span className="text-[10px] text-emerald-600 font-bold">✓</span>}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Buyer Delivery Instructions */}
            <div className="rounded-2xl border border-line bg-surface p-4 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-ink">Special Delivery Instructions</span>
                {userRole === 'buyer' && (
                  <button
                    onClick={handleSaveInstructions}
                    disabled={isSavingInstructions}
                    className="text-[11px] font-bold text-pine-600 hover:underline flex items-center gap-1"
                  >
                    <Save size={12} />
                    <span>{isSavingInstructions ? 'Saving...' : 'Save'}</span>
                  </button>
                )}
              </div>

              {userRole === 'buyer' ? (
                <textarea
                  value={instructionsInput}
                  onChange={(e) => setInstructionsInput(e.target.value)}
                  placeholder="e.g. Unload at Bay 3, verify moisture sensor seal..."
                  rows={2}
                  className="w-full text-xs rounded-xl border border-line bg-surface-sunk p-2 text-ink outline-none focus:border-pine-500"
                />
              ) : (
                <p className="text-ink-2 italic bg-surface-sunk/50 rounded-xl p-2 border border-line">
                  "{selectedOrder.special_instructions || DEMO_ORDER_DEFAULT.special_instructions}"
                </p>
              )}

              {saveSuccess && (
                <p className="text-[11px] font-semibold text-emerald-600">Instructions saved for logistics partner.</p>
              )}
            </div>
          </div>

          {/* Contact Details Footer */}
          <div className="pt-3 border-t border-line flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] uppercase text-ink-3 block font-bold">Recipient Contact</span>
              <span className="font-bold text-ink">{selectedOrder.recipient_name}</span>
            </div>
            <a
              href={`tel:${selectedOrder.recipient_phone.replace(/\s+/g, '')}`}
              className="px-3 py-1.5 rounded-xl bg-pine-600 hover:bg-pine-700 text-white text-xs font-bold transition-all flex items-center gap-1 shadow-sm"
            >
              <Phone size={12} />
              <span>Contact</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
