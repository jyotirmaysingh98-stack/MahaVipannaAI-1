import { cn } from '@/lib/cn'

/**
 * MahaVipanan mark — "The Ledger & The Field": a leaf (the field) whose stem
 * steps down to a baseline (the ledger / gross→net waterfall). The signature
 * glyph, echoing the product's one idea: what you keep, not what you're quoted.
 */
export function LogoMark({ size = 36, className }: { size?: number; className?: string }) {
  return (
    <span
      className={cn('inline-grid place-items-center overflow-hidden rounded-xl bg-white shadow-glow-pine', className)}
      style={{ width: size, height: size }}
      aria-hidden
    >
      <img src="/logo.jpg" alt="MahaVipanan AI Logo" className="w-full h-full object-cover" />
    </span>
  )
}

export function Logo({
  size = 36,
  showWord = true,
  className,
}: {
  size?: number
  showWord?: boolean
  className?: string
}) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <LogoMark size={size} />
      {showWord && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[1.05rem] font-semibold tracking-tight text-ink">
            MahaVipanan<span className="text-pine-500"> AI</span>
          </span>
          <span className="mt-0.5 text-[0.62rem] font-medium uppercase tracking-[0.14em] text-ink-3">
            Sell on what you keep
          </span>
        </span>
      )}
    </span>
  )
}
