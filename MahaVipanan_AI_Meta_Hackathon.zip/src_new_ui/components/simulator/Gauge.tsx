"use client";

interface GaugeProps {
  valueDays: number;
  maxDays: number;
  colorHex: string;
  label: string;
  sublabel: string;
}

export default function Gauge({ valueDays, maxDays, colorHex, label, sublabel }: GaugeProps) {
  const pct = Math.min(1, Math.max(0, maxDays > 0 ? valueDays / maxDays : 0));
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const dash = circumference * pct;
  const size = 140;
  const center = size / 2;

  return (
    <div className="relative flex h-[140px] w-[140px] items-center justify-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="#EDF3EE"
          strokeWidth={10}
        />
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke={colorHex}
          strokeWidth={10}
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circumference}`}
          style={{ transition: "stroke-dasharray 500ms ease, stroke 400ms ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center text-center">
        <span className="font-display text-2xl font-extrabold text-ink">{valueDays}</span>
        <span className="text-[11px] font-medium leading-tight text-ink-2">{label}</span>
        <span className="mt-0.5 text-[10px] leading-tight text-ink-3">{sublabel}</span>
      </div>
    </div>
  );
}
