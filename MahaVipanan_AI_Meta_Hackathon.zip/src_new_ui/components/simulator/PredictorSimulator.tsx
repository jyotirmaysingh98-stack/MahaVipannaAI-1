import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Droplets, Thermometer, CloudRain, ShieldAlert, Activity } from 'lucide-react'
import { CROPS, Batch } from '@/lib/mockData'
import { runSimulation, batchToInputs, SimInputs, SimResult, formatInr } from '@/lib/simulation'
import Gauge from './Gauge'

const sliderDefs: {
  key: keyof SimInputs;
  label: string;
  min: number;
  max: number;
  step: number;
  unit: string;
  icon: any;
}[] = [
  { key: "temperatureC", label: "Temperature", min: 0, max: 50, step: 1, unit: "°C", icon: Thermometer },
  { key: "humidityPct", label: "Humidity", min: 10, max: 100, step: 1, unit: "%", icon: Droplets },
  { key: "rainfallMm", label: "Rainfall", min: 0, max: 300, step: 5, unit: "mm", icon: CloudRain },
  { key: "floodSeverity", label: "Flood Risk", min: 0, max: 10, step: 1, unit: "/10", icon: CloudRain },
  { key: "storageDelayDays", label: "Storage Delay", min: 0, max: 15, step: 1, unit: " days", icon: Activity },
  { key: "transportDelayDays", label: "Transport Delay", min: 0, max: 15, step: 1, unit: " days", icon: Activity },
];

export function PredictorSimulator() {
  const cropProfiles = Object.values(CROPS);
  const defaultCrop = cropProfiles[0];
  const [selectedCropKey, setSelectedCropKey] = useState(defaultCrop.key);
  const selectedCrop = cropProfiles.find(c => c.key === selectedCropKey) || defaultCrop;

  const mockBatch: Batch = {
    id: "LOT-9999",
    crop: selectedCrop.key,
    farmerName: "Test Farmer",
    farmerNameHi: "टेस्ट किसान",
    quantityKg: 1000,
    harvestDate: new Date().toISOString().split('T')[0],
    state: "Maharashtra",
    stateHi: "महाराष्ट्र",
    district: "Nashik",
    districtHi: "नाशिक",
    lat: 20.0,
    lng: 73.79,
    temperatureC: selectedCrop.idealTempC,
    humidityPct: selectedCrop.idealHumidityPct,
    rainfallMm: 0,
    floodSeverity: 0,
    storageDelayDays: 0,
    transportDelayDays: 0,
  };

  const [inputs, setInputs] = useState<SimInputs>(batchToInputs(mockBatch));

  useEffect(() => {
    setInputs({
      temperatureC: selectedCrop.idealTempC,
      humidityPct: selectedCrop.idealHumidityPct,
      rainfallMm: 0,
      floodSeverity: 0,
      storageDelayDays: 0,
      transportDelayDays: 0,
    });
  }, [selectedCropKey])

  const result: SimResult = runSimulation(selectedCrop, mockBatch.quantityKg, inputs);

  const riskHexMap: Record<SimResult["riskLevel"], string> = {
    Low: "#10b981", // emerald-500
    Medium: "#f59e0b", // amber-500
    High: "#f97316", // orange-500
    Critical: "#ef4444", // red-500
  };

  const riskHex = riskHexMap[result.riskLevel];

  return (
    <div className="relative w-full max-w-5xl mx-auto rounded-3xl overflow-hidden shadow-2xl bg-surface border border-line">
      <div className="relative p-8 z-10 flex flex-col lg:flex-row gap-8">
        
        {/* Left Column: WhatIf Simulator Sliders */}
        <div className="flex-1 space-y-8">
          <div>
            <h2 className="text-2xl font-semibold text-ink flex items-center gap-3">
              Interactive Digital Twin Simulator
            </h2>
            <p className="mt-2 text-ink-3 text-sm">
              Adjust environmental conditions to simulate the impact on shelf life and risk.
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-ink-2">Select Crop</label>
              <select
                value={selectedCropKey}
                onChange={(e) => setSelectedCropKey(e.target.value as any)}
                className="w-full bg-surface-sunk border border-line rounded-xl px-4 py-3 text-ink focus:outline-none focus:ring-2 focus:ring-pine-500 transition-all"
              >
                {cropProfiles.map(c => (
                  <option key={c.key} value={c.key}>{c.nameEn}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6 pt-4 border-t border-line/50">
              {sliderDefs.map((def) => {
                const Icon = def.icon;
                return (
                  <div key={def.key} className="p-4 rounded-2xl bg-surface-sunk border border-line">
                    <div className="mb-2 flex items-center justify-between text-sm font-semibold text-ink-2">
                      <span className="flex items-center gap-2"><Icon size={16} className="text-pine-500"/> {def.label}</span>
                      <span className="rounded bg-paper px-2 py-1 text-xs font-bold text-ink">
                        {inputs[def.key]}{def.unit}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={def.min}
                      max={def.max}
                      step={def.step}
                      value={inputs[def.key]}
                      onChange={(e) =>
                        setInputs({ ...inputs, [def.key]: Number(e.target.value) })
                      }
                      className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-full bg-line accent-pine-600"
                    />
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Real-time Output */}
        <div className="w-full lg:w-80 shrink-0">
          <motion.div
            className="h-full rounded-3xl bg-surface-sunk border border-line p-6 flex flex-col gap-8 relative overflow-hidden"
          >
            <div className="text-center">
              <h3 className="text-lg font-medium text-ink mb-1">Simulated Outcome</h3>
              <p className="text-xs text-ink-3">Live prediction for 1,000 kg of {selectedCrop.nameEn}</p>
            </div>

            <div className="flex justify-center">
              <Gauge
                valueDays={result.estimatedShelfLifeDays}
                maxDays={selectedCrop.baseShelfLifeDays}
                colorHex={riskHex}
                label="Shelf Life"
                sublabel="Days remaining"
              />
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-surface border border-line flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-medium text-ink-2">
                  <ShieldAlert size={16} style={{ color: riskHex }} />
                  Risk Level
                </span>
                <span className="px-2 py-1 rounded-md text-xs font-bold uppercase tracking-wide" style={{ backgroundColor: riskHex + '20', color: riskHex }}>
                  {result.riskLevel}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-surface border border-line space-y-1">
                <div className="text-xs text-ink-3 font-medium uppercase tracking-wider">Estimated Loss</div>
                <div className="text-2xl font-semibold" style={{ color: riskHex }}>
                  {formatInr(result.expectedLossInr)}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-surface border border-line space-y-1">
                <div className="text-xs text-ink-3 font-medium uppercase tracking-wider">Total Value</div>
                <div className="text-xl font-medium text-ink">
                  {formatInr(result.totalValueInr)}
                </div>
              </div>

              <div className="pt-4 text-center">
                <span className="text-xs text-ink-3 uppercase tracking-wider block mb-2">Recommendation</span>
                <div className="inline-block px-4 py-2 rounded-full border border-line font-bold text-sm tracking-wide text-ink bg-surface shadow-sm">
                  {result.recommendation.replace('_', ' ')}
                </div>
              </div>
            </div>

          </motion.div>
        </div>
      </div>
    </div>
  )
}
