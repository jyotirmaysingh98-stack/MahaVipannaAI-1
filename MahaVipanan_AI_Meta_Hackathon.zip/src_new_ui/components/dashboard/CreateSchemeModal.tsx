import { useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Field } from '@/components/ui/Field'
import { Button } from '@/components/ui/Button'
import { api } from '@/api/client'
import { GovernmentScheme } from '@/api/types'

interface CreateSchemeModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: () => void
}

export function CreateSchemeModal({ isOpen, onClose, onSave }: CreateSchemeModalProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [benefits, setBenefits] = useState('')
  const [eligibility, setEligibility] = useState('')
  const [deadline, setDeadline] = useState('')
  const [officialUrl, setOfficialUrl] = useState('')
  const [state, setState] = useState('')
  const [targetRole, setTargetRole] = useState('')

  const handleSave = async () => {
    if (!title || !description || !benefits || !eligibility) {
      setError('Title, Description, Benefits, and Eligibility are required.')
      return
    }

    setLoading(true)
    setError(null)
    try {
      const payload: Partial<GovernmentScheme> = {
        title,
        description,
        benefits,
        eligibility,
        deadline: deadline || undefined,
        official_url: officialUrl || undefined,
        state: state || undefined,
        target_role: targetRole || undefined
      }

      await api.createScheme(payload)
      
      // Reset form
      setTitle('')
      setDescription('')
      setBenefits('')
      setEligibility('')
      setDeadline('')
      setOfficialUrl('')
      setState('')
      setTargetRole('')

      onSave()
      onClose()
    } catch (err: any) {
      setError(err.message || 'Failed to create scheme')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal open={isOpen} onClose={onClose} title="Create Government Scheme">
      <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
        {error && <div className="text-red-500 text-sm bg-red-50 p-2 rounded">{error}</div>}
        
        <Field
          label="Title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. PM-KISAN"
        />
        
        <Field
          label="Description"
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        
        <Field
          label="Benefits"
          type="text"
          value={benefits}
          onChange={(e) => setBenefits(e.target.value)}
        />
        
        <Field
          label="Eligibility"
          type="text"
          value={eligibility}
          onChange={(e) => setEligibility(e.target.value)}
        />

        <div className="grid grid-cols-2 gap-4">
          <Field
            label="Deadline (Optional)"
            type="date"
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
          />
          <Field
            label="Target Role (Optional)"
            type="text"
            value={targetRole}
            onChange={(e) => setTargetRole(e.target.value)}
            placeholder="e.g. farmer, fpo, all"
          />
        </div>
        
        <Field
          label="State (Optional)"
          type="text"
          value={state}
          onChange={(e) => setState(e.target.value)}
          placeholder="e.g. Maharashtra"
        />
        
        <Field
          label="Official URL (Optional)"
          type="text"
          value={officialUrl}
          onChange={(e) => setOfficialUrl(e.target.value)}
          placeholder="e.g. https://pmkisan.gov.in"
        />

        <div className="flex justify-end gap-3 mt-6">
          <Button variant="secondary" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={loading}>
            Create Scheme
          </Button>
        </div>
      </div>
    </Modal>
  )
}
