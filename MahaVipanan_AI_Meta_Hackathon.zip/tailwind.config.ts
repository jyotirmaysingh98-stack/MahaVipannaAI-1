import type { Config } from 'tailwindcss'

/**
 * MahaVipanan AI — design tokens: "The Ledger & The Field".
 *
 * Light-first, projector-legible premium B2B surface (UI_UX.md warns against
 * dark/government aesthetics). Colour is SEMANTIC, validated for colour-blind
 * safety via the dataviz palette validator — do not add chart series hues here
 * without re-validating:
 *   amber  = gross / quoted price (the seductive headline number)
 *   pine   = net realizable price / the best real option
 *   clay   = deductions / value erosion
 *   teal   = system intelligence (calculated-by-engine UI accent, never a chart
 *            series adjacent to pine)
 *   indigo = 3rd categorical chart series only
 */
export default {
  darkMode: 'class',
  content: ['./index.html', './src_new_ui/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAFAF7',
        surface: {
          DEFAULT: '#FFFFFF',
          sunk: '#F4F4EF',
          raised: '#FFFFFF',
        },
        line: {
          DEFAULT: '#E7E7DE',
          strong: '#D8D8CC',
        },
        ink: {
          DEFAULT: '#1A2419',
          2: '#4A5348',
          3: '#767E70',
        },
        pine: {
          50: '#EEF5EF',
          100: '#D6E7DA',
          200: '#AECFB6',
          300: '#7FB18C',
          400: '#4B9066',
          500: '#15734F',
          600: '#0F5C3F',
          700: '#0C4A33',
          900: '#0F2E1D',
        },
        amber: {
          50: '#FBF3E2',
          100: '#F6E4BE',
          200: '#EFCE86',
          300: '#E8B94F',
          400: '#E0A32E',
          500: '#C6871A',
          600: '#B87817',
          700: '#8F5E12',
        },
        clay: {
          50: '#F7E7E1',
          100: '#F0D1C6',
          300: '#D08C74',
          500: '#A8442C',
          600: '#8F3A25',
          700: '#73301F',
        },
        teal: {
          50: '#E4F1F2',
          100: '#D3EBEE',
          300: '#7FC2C9',
          500: '#0E7C86',
          600: '#0B646C',
          700: '#094F56',
        },
        indigo: {
          100: '#DEE2F5',
          500: '#3A4FB0',
          600: '#2E3F8C',
        },
        /* ── Redesign 2026: immersive agriculture marketing surfaces ──
           Additive only — existing chart hues above are unchanged so the
           colour-blind-validated dataviz palette stays valid. */
        forest: {
          950: '#04120B',
          900: '#071C11',
          800: '#0B2A19',
          700: '#0E3A22',
          600: '#12492B',
        },
        lime: {
          300: '#D6F27E',
          400: '#B8E357',
          500: '#98C93D',
          600: '#79A72C',
        },
        cream: '#F5F1E6',
      },
      fontFamily: {
        display: ['"Space Grotesk Variable"', '"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['"Inter Variable"', 'Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display-2xl': ['clamp(3rem, 7vw, 6.75rem)', { lineHeight: '0.95', letterSpacing: '-0.035em' }],
        'display-xl': ['clamp(2.75rem, 5vw, 4.25rem)', { lineHeight: '1.02', letterSpacing: '-0.03em' }],
        'display-lg': ['clamp(2.25rem, 3.6vw, 3.25rem)', { lineHeight: '1.05', letterSpacing: '-0.025em' }],
        'display-md': ['clamp(1.75rem, 2.4vw, 2.25rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
      },
      boxShadow: {
        card: '0 1px 2px rgba(26,36,25,0.04), 0 8px 24px -14px rgba(26,36,25,0.14)',
        'card-lg': '0 2px 4px rgba(26,36,25,0.05), 0 28px 56px -28px rgba(26,36,25,0.22)',
        float: '0 12px 40px -12px rgba(26,36,25,0.24)',
        'glow-pine': '0 0 0 1px rgba(21,115,79,0.18), 0 8px 30px -8px rgba(21,115,79,0.35)',
        'glow-amber': '0 0 0 1px rgba(224,163,46,0.25), 0 8px 30px -8px rgba(224,163,46,0.4)',
        'glow-teal': '0 0 0 1px rgba(14,124,134,0.2), 0 6px 24px -8px rgba(14,124,134,0.35)',
        'inset-line': 'inset 0 0 0 1px rgba(231,231,222,0.9)',
      },
      borderRadius: {
        xl: '0.875rem',
        '2xl': '1.125rem',
        '3xl': '1.5rem',
      },
      backgroundImage: {
        'field-mesh':
          'radial-gradient(60% 50% at 0% 0%, rgba(21,115,79,0.06), transparent 60%), radial-gradient(55% 45% at 100% 0%, rgba(224,163,46,0.07), transparent 55%), radial-gradient(45% 60% at 85% 100%, rgba(14,124,134,0.045), transparent 60%)',
        /* Vertical scrim: darkens only the top (nav) and bottom (stats band),
           leaving the middle of the photograph almost clear. */
        'hero-scrim':
          'linear-gradient(180deg, rgba(4,18,11,0.42) 0%, rgba(4,18,11,0.05) 26%, rgba(4,18,11,0.10) 52%, rgba(4,18,11,0.68) 100%)',
        /* Horizontal veil: darkens the left where the headline sits, clears the
           right two-thirds so the field imagery reads clearly. */
        'hero-veil':
          'linear-gradient(90deg, rgba(4,18,11,0.72) 0%, rgba(4,18,11,0.36) 36%, rgba(4,18,11,0.06) 68%, rgba(4,18,11,0) 100%)',
        'forest-glow':
          'radial-gradient(70% 60% at 50% -5%, rgba(152,201,61,0.14), transparent 70%)',
        'cta-scrim':
          'linear-gradient(90deg, rgba(4,18,11,0.9) 0%, rgba(4,18,11,0.68) 45%, rgba(4,18,11,0.28) 100%)',
        /* Dashboard hero banner: shorter, text-dense — stronger on the left,
           still lets the right of the photo show through. */
        'banner-scrim':
          'linear-gradient(90deg, rgba(4,18,11,0.93) 0%, rgba(4,18,11,0.76) 40%, rgba(4,18,11,0.46) 72%, rgba(4,18,11,0.32) 100%)',
      },
      transitionTimingFunction: {
        spring: 'cubic-bezier(0.22, 1, 0.36, 1)',
        'out-quart': 'cubic-bezier(0.25, 1, 0.5, 1)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '100%': { transform: 'translateX(100%)' },
        },
        'pulse-ring': {
          '0%': { boxShadow: '0 0 0 0 rgba(14,124,134,0.35)' },
          '70%': { boxShadow: '0 0 0 8px rgba(14,124,134,0)' },
          '100%': { boxShadow: '0 0 0 0 rgba(14,124,134,0)' },
        },
        'slow-zoom': {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.08)' },
        },
        'marquee': {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.5s var(--ease-spring, cubic-bezier(0.22,1,0.36,1)) both',
        shimmer: 'shimmer 1.6s infinite',
        'pulse-ring': 'pulse-ring 2.2s ease-out infinite',
        'slow-zoom': 'slow-zoom 18s ease-out forwards',
        marquee: 'marquee 32s linear infinite',
        float: 'float 6s ease-in-out infinite',
      },
    },
  },
  plugins: [],
} satisfies Config
