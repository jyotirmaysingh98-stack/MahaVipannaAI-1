import requests
import sqlite3

conn = sqlite3.connect('backend/mahavipanan.db')
c = conn.cursor()
c.execute("SELECT id FROM user WHERE email='farm@test.local'")
res = c.fetchone()
if not res:
    print('User not found')
    exit(1)
user_id = res[0]
conn.close()

# get token
res = requests.post('http://localhost:8000/api/auth/login', json={'email': 'farm@test.local', 'password': 'testpass'})
if res.status_code != 200 or not res.json().get('success'):
    print('Login failed', res.text)
    exit(1)
token = res.json().get('token')

res = requests.post('http://localhost:8000/api/farmer/lots', 
    json={'crop_name': 'Wheat', 'total_quantity_q': 500, 'grade_summary': 'Grade A', 'expected_price_per_q': 2200},
    headers={'Authorization': f'Bearer {token}'}
)
print('Response:', res.status_code, res.text)
