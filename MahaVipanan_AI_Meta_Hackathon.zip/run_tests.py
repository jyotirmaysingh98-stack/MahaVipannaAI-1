import os
import sys

# Add backend to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "backend")))

import pytest

if __name__ == "__main__":
    sys.exit(pytest.main(["-v", "backend/tests/test_ownership_and_auth.py"]))
